// vue.config.js
let Timestamp = new Date().getTime();
const target = 'https://dt.gdhchina.com/';
module.exports = {
  publicPath: "./",
  outputDir: "dist",
  productionSourceMap: false,
  lintOnSave: false, //去掉代码检查
  configureWebpack: {
    output: {
      filename: `[name].${Timestamp}.js`,
      chunkFilename: `[name].${Timestamp}.js`
    }
  },
  devServer: {
    open: true,
    port: 8080,
    proxy: {
      'gdh-com-hk-digital-':{
        target,
        // 允许跨域
        changeOrigin: true,
      },
    },
    disableHostCheck: true
  },
};
