import Vue from 'vue'
import App from './App.vue'
import router from "./router";
import '@/assets/style/common.scss'
import '@/assets/style/init.scss'
import '@/assets/style/main.scss'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import api from "./api/index"
Vue.prototype.$api = api;
import methods from './utils/methods'
Vue.prototype.$methods = methods;
Vue.use(ElementUI)
import storage from 'good-storage'
Vue.prototype.$storage = storage;
import filters from './utils/filters'
Object.keys(filters).forEach(k => {
  Vue.filter(k, filters[k])
})
import Video from 'video.js'
import 'video.js/dist/video-js.css'
Vue.prototype.$video = Video
import VuewechatTitle from 'vue-wechat-title'
Vue.use(VuewechatTitle)
import VWechatAuth from 'v-wechat-auth'
Vue.use(VWechatAuth)
import echarts from 'echarts'
Vue.prototype.$echarts = echarts

import { PullRefresh } from 'vant';

Vue.use(PullRefresh);

import { List } from 'vant';

Vue.use(List);
import { Popup, Picker, DatetimePicker, Swipe, SwipeItem, Field, Icon } from 'vant';

Vue.use(Popup);
Vue.use(Picker);
Vue.use(DatetimePicker);
Vue.use(Swipe);
Vue.use(SwipeItem);
Vue.use(Field);
Vue.use(Icon);

// // 引入vue-amap
// import AMap from 'vue-amap';
// Vue.use(AMap);
// // 初始化vue-amap
// AMap.initAMapApiLoader({
//   // 高德的key
//   key: 'f7bfe3503ab1f83f92091b023704b726',
//   // 插件集合
//   plugin: ['AMap.Autocomplete', 'AMap.PlaceSearch', 'AMap.Scale', 'AMap.OverView', 'AMap.ToolBar', 'AMap.MapType', 'AMap.PolyEditor', 'AMap.CircleEditor'],
//   // 高德 sdk 版本，默认为 1.4.4
//   v: '1.4.4'
// });

Vue.prototype.$echarts = echarts
new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
