import config from '../utils/config'
export default {
    currency(value, currency, decimals) {
        const digitsRE = /(\d{3})(?=\d)/g
        var newValue = value ? value.toString() : ''
        if (escape(newValue).indexOf("%u") != -1 || newValue.indexOf('%') != -1 || newValue == '- -') return value
        // value = parseFloat(value / 10000)
        // value = parseFloat(value)
        if (!isFinite(value) || (!value && value !== 0)) return ''
        currency = currency != null ? currency : ''
        decimals = decimals != null ? decimals : 0
        var stringified = Math.abs(value).toFixed(decimals)
        var _int = decimals ?
            stringified.slice(0, -1 - decimals) :
            stringified
        var i = _int.length % 3
        var head = i > 0 ?
            (_int.slice(0, i) + (_int.length > 3 ? ',' : '')) :
            ''
        var _float = decimals ?
            stringified.slice(-1 - decimals) :
            ''
        var sign = value < 0 ? '-' : ''
        return sign + currency + head +
            _int.slice(i).replace(digitsRE, '$1,') +
            _float
    },

    orderStateClass(state) {
        switch (state) {
            case "new_creation":
                return 'text-blue';
            case 'dealing':
                return 'text-yellow';
            case 'for_comfirm':
                return 'text-darkBlue';
            case 'for_feedback':
                return 'text-purple';
            case 'return_visiting':
                return 'text-green';
            case 'return_order':
                return 'text-orange';
            case 'waiting_order':
                return 'text-pink';
            case 'closed':
                return 'text-main';
        }
    },
    // 项目阶段
    projectPeriod(state) {
        switch (state) {
            case 0:
                return '前期阶段';
            case 1:
                return '建设阶段';
            case 2:
                return '已完成';
        }
    },
    returnState(state) {
        switch (state) {
            case "callcenter_rs_unrecall":
                return '未回访'; //待接单
            case "callcenter_rs_recalling":
                return '回访中';
            case "callcenter_rs_recalled":
                return '已回访';
            case "callcenter_rs_closed":
                return '已关闭';
            case "callcenter_cor_success":
                return '回访成功';
            default:
                return '暂无状态';

        }
    },
    returnResult(state) {
        switch (state) {
            case "callcenter_cor_success":
                return '成功'; //待接单
            case "callcenter_cor_busy":
                return '占线';
            case "callcenter_cor_busytone":
                return '忙音';
            case "callcenter_cor_noanswer":
                return '无人接听';
            case "callcenter_cor_refused":
                return '拒绝';
            case "callcenter_cor_shutdown":
                return '停机';
            case "callcenter_cor_unexisted":
                return '空号';
            default:
                return '暂无结果';

        }
    },
    cutTxt(str) {
        console.log(str);

        if (str.length > 38) return str.substring(0, 39) + '...'

    },
    imgSrc(src) {
        return config.picUrl + src
    },
    /** 时间戳转换 */
    getTime(time) {
        let date = null
        if ((time + '').length === 10) {
            date = new Date(time * 1000)
        } else {
            date = new Date(time)
        }
        const Y = date.getFullYear()
        const M = date.getMonth() + 1
        const D = date.getDate()
        const H = date.getHours()
        const MM = date.getMinutes()
        const S = date.getSeconds()
        return `${Y}-${(M > 9 ? M : ('0' + M))}-${(D > 9 ? D : ('0' + D))} ${(H > 9 ? H : ('0' + H))}:${(MM > 9 ? MM : ('0' + MM))}:${(S > 9 ? S : ('0' + S))}`
    }
}