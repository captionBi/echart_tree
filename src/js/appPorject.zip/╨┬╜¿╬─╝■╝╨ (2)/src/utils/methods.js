import config from '../utils/config'
const methods = {
    currency(n) {
        var b = parseInt(n).toString();
        var len = b.length;
        if (len <= 3) { return b; }
        var r = len % 3;
        return r > 0 ? b.slice(0, r) + "," + b.slice(r, len).match(/\d{3}/g).join(",") : b.slice(r, len).match(/\d{3}/g).join(",");
    },
    getImgArray(obj) {
        if (obj.length) {
            return obj.map(item => {
                return config.picUrl + item.path
            })
        }
    },
    removeObjectNull(obj) {
        for (let key of Object.keys(obj)) {
            if (!obj[key]) delete obj[key]
        }
    },
    cutString(string, key, start) {
        let index = string.indexOf(key)
        return string.substring(start, index)
    },
    veriPhoneNum(telNumber) {
        let myreg = /^(14[0-9]|13[0-9]|15[0-9]|17[0-9]|18[0-9]|19[0-9])\d{8}$$/;
        return myreg.test(telNumber)
    },
    formatTime: (date) => {
        let year = date.getFullYear()
        let month = date.getMonth() + 1
        let day = date.getDate()
        let hour = date.getHours()
        let minute = date.getMinutes()
        let second = date.getSeconds()
        month = month < 10 ? `0${month}` : month
        day = day < 10 ? `0${day}` : day
        hour = hour < 10 ? `0${hour}` : hour
        minute = minute < 10 ? `0${minute}` : minute
        second = second < 10 ? `0${second}` : second
        return `${year}-${month}-${day} ${hour}:${minute}:${second}`
    },
    formatNumber: (n) => {
        n = n.toString()
        return n[1] ? n : '0' + n
    },
    formatDate: (time) => {
        var re = /-?\d+/;
        var m = re.exec(time);
        var d = new Date(parseInt(m[0]));
        var o = {
            'M+': d.getMonth() + 1,
            'd+': d.getDate(),
            'h+': d.getHours(),
            'm+': d.getMinutes(),
            's+': d.getSeconds(),
            'q+': Math.floor((d.getMonth() + 3) / 3),
            'S': d.getMilliseconds()
        };
        var format = 'yyyy-MM-dd hh:mm:ss';
        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (d.getFullYear() + '').substr(4 - RegExp.$1.length))
        }
        for (var k in o) {
            if (new RegExp('(' + k + ')').test(format)) {
                format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length))
            }
        }
        return format
    },
    getUrlKey: (name) => {
        return (
            decodeURIComponent(
                // eslint-disable-next-line no-sparse-arrays
                (new RegExp("[?|&]" + name + "=" + "([^&;]+?)(&|#|;|$)").exec(location.href) || [, ""])[1].replace(/\+/g, "%20")) || null
        );
    },
    getUrlToken(callback) {
        const token = decodeURIComponent(
            (new RegExp('[?|&]token=' + '([^&;]+?)(&|#|;|$)').exec(
                location.href
                // eslint-disable-next-line no-sparse-arrays
            ) || [, ''])[1].replace(/\+/g, '%20') || null
        )
        if (token) {
            localStorage.setItem('token', token)
            callback(token)
        }

    },
    GetUrlParams: (url) => {
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1); //substr()方法返回从参数值开始到结束的字符串；
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
            }
        }
        return theRequest
    },
    LetterSort: (data) => {
        let results = {
            letter: []
        }
        var letter_reg = /^[A-Z]$/;
        var list = new Array();
        for (var i = 0; i < data.length; i++) {
            list['#'] = new Array();
            let letter = (data[i]["pin"]).substr(0, 1).toUpperCase();
            if (!letter_reg.test(letter)) {
                letter = '#';
            }
            if (!(letter in list)) {
                list[letter] = new Array();
            }
            list[letter].push(data[i]);
        }
        var result = new Array();
        for (var key in list) {
            result.push({
                letter: key,
                list: list[key]
            });
        }
        result.sort(function (x, y) {
            return x.letter.charCodeAt(0) - y.letter.charCodeAt(0);
        });
        var last_arr = result[0];
        result.splice(0, 1);
        result.push(last_arr);
        var json_sort = {}
        for (var j = 0; j < result.length; j++) {
            json_sort[result[j].letter] = result[j].list;
            results.letter.push(result[j].letter)
        }
        results.result = result
        return results
    },


}



export default methods;