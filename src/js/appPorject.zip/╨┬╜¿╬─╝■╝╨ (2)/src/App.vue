<template>
  <div id="app" :style="{ width: width, margin: '0 auto', height: '100%' }">
    <!-- <router-view /> -->
    <keep-alive include="engineers,siteSave,projectlists">
      <router-view></router-view>
    </keep-alive>
  </div>
</template>
<script>
export default {
  data() {
    return {
      width: "",
    };
  },
  activated() {},
  deactivated() {},
  created() {
    // vue原型挂载 - 是否PC端
    if (!/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
      // Vue.prototype.$pc = false
      // hostConfig.vconsole && new VConsole()
      this.width = "600px";
    } else {
    }
  },
};
</script>
<style lang="scss">
.van-calendar__selected-day {
  text-indent: 2px;
}
//实时客流蜂巢热力图的公共样式
.ondDivf {
  width: 94%;
  margin: 0 auto;
  padding-top: 36px;
  background: url("./assets/img/onebg.png") no-repeat;
  background-size: 100% 100%;
  height: 500px;
  .pieFons {
    text-align: center;
    font-size: 32px;
    color: white;
  }
}
</style>