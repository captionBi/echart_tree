import Vue from "vue";
import VueRouter from "vue-router";
import methods from "./utils/methods";
import axios from "axios";
import {
  Toast
} from "vant";
Vue.use(VueRouter);

const router = new VueRouter({
  routes: [{
    path: "/projectlist",
    name: "projectlist",
    meta: {
      title: "进度监控",
      appCode: "progressMonitor",
    },
    component: () => import("./pages/projectlist/index"),
  },
  {
    path: "/project-detail",
    name: "project-detail",
    meta: {
      title: "进度监控-详情",
      appCode: "progressMonitor",
    },
    component: () => import("./pages/projectlist/project-detail"),
  },
  {
    path: "/projectDetail",
    name: "projectDetail",
    meta: {
      title: "工程概览-详情",
      appCode: "engineering",
    },
    component: () => import("./pages/project/index"),
  },
  {
    path: "/panorama720",
    name: "panorama720",
    meta: {
      title: "720全景",
      appCode: "panorama",
    },
    component: () => import("./pages/site/panorama720"),
  },
  {
    path: "/engineering",
    name: "engineering",
    meta: {
      title: "工程概览",
      appCode: "engineering",
    },
    component: () => import("./pages/engineering/index"),
  },
  {
    path: "/engineering-plate",
    name: "engineering-plate",
    meta: {
      title: "板块投资详情",
      appCode: "engineering",
    },
    component: () => import("./pages/engineering/plate"),
  },
  {
    path: "/vacation",
    name: "vacation",
    meta: {
      title: "休假查询",
      appCode: "vocationSearch",
    },
    component: () => import("./pages/vacation/vacation"),
  },
  // {
  //   path: "/vacation2",
  //   name: "vacation2",
  //   meta: {
  //     title: "休假查询",
  //     appCode: "vocationSearch",
  //   },
  //   component: () => import("./pages/vacation/vacation"),
  // },
  {
    path: "/record",
    name: "record",
    meta: {
      title: "休假查询",
      appCode: "vocationSearch",
    },
    component: () => import("./pages/vacation/record"),
  },
  {
    path: "/site",
    name: "site",
    meta: {
      title: "云监工",
      appCode: "cloudOversee",
    },
    component: () => import("./pages/site/index"),
  },
  {
    path: "/video-detail",
    name: "video-detail",
    meta: {
      title: "视频详情",
    },
    component: () => import("./pages/site/video-detail"),
  },
  {
    path: "/section",
    name: "section",
    meta: {
      title: "标段",
      appCode: "",
    },
    component: () => import("./pages/sectioninfo/map"),
  },
  // component: () => import('./pages/sectioninfo/map'),
  {
    path: "/sectioninfo/:name/:construction/:price/:id/:projectId/:node",
    name: "sectioninfo",
    meta: {
      title: "标段详情",
      appCode: "",
    },
    component: () => import("./pages/sectioninfo/index"),
  },
  {
    path: "/video-more",
    name: "video-more",
    meta: {
      title: "视频详情",
      appCode: "",
    },
    component: () => import("./pages/site/video-more"),
  },
  {
    path: "/publicmanage",
    name: "publicmanage",
    meta: {
      title: "舆情大数据",
      appCode: "yqBigData",
    },
    component: () => import("./pages/publicmanage/index"),
  },
  {
    path: "/business",
    name: "business",
    meta: {
      title: "数据天河城",
      appCode: "thCityParty",
    },
    component: () => import("./pages/business/index"),
  },
  {
    path: "/partymanage",
    name: "partymanage",
    meta: {
      title: "党建管理",
      appCode: "",
    },
    component: () => import("./pages/partymanage/index"),
  },
  {
    path: "/ranking",
    name: "ranking",
    meta: {
      title: "龙虎榜",
      // appCode: "",
      appCode: "rankingList",
    },
    component: () => import("./pages/ranking/index"),
  },
  {
    path: "/personnel",
    name: "personnel",
    meta: {
      title: "人事大数据",
      appCode: "rsBigData",
    },
    component: () => import("./pages/personnel/index"),
  },
  {
    path: "/yuehaishare",
    name: "yuehaishare",
    meta: {
      title: "股票行情",
      appCode: "stockQuotation",
    },
    component: () => import("./pages/yuehaishare"),
  },
  {
    path: "/exchange",
    name: "exchange",
    meta: {
      title: "汇率行情",
      appCode: "exchangeRage",
    },
    component: () => import("./pages/exchange/index"),
  },
  //生产环境-可能暂未用到
  {
    path: "/progress",
    name: "progress",
    meta: {
      title: "粤海",
    },
    component: () => import("./pages/progress/index"),
  },
  {
    path: "/test",
    name: "test",
    meta: {
      title: "测试",
    },
    component: () => import("./pages/site/test"),
  },
  {
    path: "/more",
    name: "more",
    meta: {
      title: "全部收藏",
    },
    component: () => import("./pages/site/more"),
  },
  {
    path: "/voiceTest",
    name: "voiceTest",
    meta: {
      title: "语音测试",
    },
    component: () => import("./pages/voiceTest/test"),
  },
  {
    path: "/error",
    name: "error",
    meta: {
      title: "错误页面",
    },
    component: () => import("./pages/common/error.vue"),
  },
  {
    path: "/engineer-detail",
    name: "engineer-detail",
    meta: {
      title: "工程详情",
    },
    component: () => import("./pages/engineering/engineer-detail"),
  },
  {
    path: "/site-detail",
    name: "site-detail",
    meta: {
      title: "720详情",
    },
    component: () => import("./pages/site/site-detail"),

  },
  {
    path: "/histogram",
    name: "histogram",
    meta: {
      title: "债券",
      appCode: 'bondExchange',
    },
    component: () => import("./pages/histogram/index"),

  },
  {
    path: "/problem",
    name: "problem",
    meta: {
      title: "审计问题统计",
      appCode: 'audit',
    },
    component: () => import("./pages/problemstotle/index"),

  },
  {
    path: "/legalcontract",
    name: "legalcontract",
    meta: {
      title: "法务合同",
      appCode: 'audit',
    },
    component: () => import("./pages/legalcontract/index"),

  },
    //暂未用到
  ],
});
router.afterEach(() => {
  window.scrollTo(0, 0);
});
router.beforeEach((to, from, next) => {
  // console.log(to);
  //记录日志
  function inntRecord() {
    logRecord();
    // let code = "";
    // code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
    // if (code == "") {
    //   var iCount = 0;
    //   var testCode = window.setInterval(function () {
    //     let codeTest = "";
    //     codeTest = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
    //     if (codeTest != "") {
    //       logRecord();
    //       window.clearInterval(testCode);
    //     }
    //     iCount++;
    //     if (iCount == 10) {
    //       window.clearInterval(testCode);
    //     }
    //   }, 500);
    // }
  }

  function logRecord() {
    let code = "";
    code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
    const APPID = "ww1736e9ae98ad76c9";
    axios
      .post(
        "/gdh-com-hk-digital-accessloghistorysvc/api/service/logUserAccessInfo", {
        corpId: APPID,
        code: code,
        appCode: to.meta.appCode,
        pageCode: to.name,
        pageName: to.meta.title,
        pageUrl: window.location.href,
      }
      )
      .then((res) => {
        if (res.data.body.code == "10000") {
          localStorage.setItem('userId', res.data.body.userId)
        }
        if (
          res.data != null &&
          res.data.body.body != null &&
          res.data.body.body.code != null &&
          res.data.body.body.code == "-100"
        ) {

          const local = window.location.href;
          setTimeout(() => {
            window.location.href =
              "https://wechat.gdhchina.com/connect/oauth2/authorize?appid=" +
              APPID +
              "&redirect_uri=" +
              encodeURIComponent(local) +
              "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
          }, 2000);
        }
      });
  }
  if (to.meta.appCode && to.meta.appCode.length > 0 && isWeiXin()) {
    if (
      // to.fullPath.toLocaleLowerCase().indexOf("/site") > -1 ||
      to.fullPath.toLocaleLowerCase().indexOf("/vacation") > -1
    ) {
      console.log(1);
    } else {
      inntRecord();
    }
  }
  // 判断在哪里的浏览器访问
  function isWeiXin() {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.indexOf("micromessenger") > -1) {
      if (ua.indexOf("wxwork") > -1) { //企业微信
        return true;
      } else {
        return false; //是微信端
      }
    } else {
      return false;
    }
  }
  // 先取反   方便电脑查看
  if (isWeiXin()) {
    if (to.matched.length === 0) {
      from.name ?
        next({
          name: from.name,
        }) :
        next("/engineering");
    }
    next();
  } else if (to.path == "/voiceTest") {
    next();
  } else if (checkPath()) {
    next();
  } else {
    Toast("请在微信浏览器访问");
  }

  function checkPath() {
    var ua = window.navigator.userAgent.toLowerCase();
    let pathList = [];
    if (ua.indexOf("micromessenger") > -1) { //微信端可看
      pathList = [
        "/engineering-plate",
        "/engineering",
        "/projectDetail",
        '/business',
        "/ranking",
        "/problem",
        "/histogram",
        "/legalcontract",
      ];
    } else { //pc端可看
      pathList = [
        "/engineering-plate",
        "/engineering",
        "/projectDetail",
        "/ranking",
      ];
    }
    let path = to.path;
    return pathList.indexOf(path) > -1;
  }

  if (to.meta.background === "whitebg") {
    document.querySelector("html").setAttribute("style", "background: #f7f7f7");
  }
});

export default router;