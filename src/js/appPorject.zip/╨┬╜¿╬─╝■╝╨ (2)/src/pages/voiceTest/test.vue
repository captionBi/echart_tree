<template>
    <div>
        <button @click="start">开始录音</button>
        <button @click="stop">停止录音</button>
        <button @click="play">播放录音</button>
        <button @click="translateVoice">语音转文字</button>
        
        <p>{{words}}</p>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data(){
        return{
            words: '',
            url2: 'http://m.sea.com',
            url: 'https://wechat.gdhchina.com',
            localId: '',//录音id
            timeStamp: Math.round(new Date() / 1000), // 时间戳
            corpId: "ww1736e9ae98ad76c9", //企业微信的corpid
            corpSecret: "hnZQKk_whGy686CfWpmuQx1cyxvsSI4Z0LypZISDbts", //应用secret
            nonceStr: "Wm3WZYTPz0wzccnW", //生成签名的随机串
        }
    },
    created(){
        this.getAuthSign();
    },
    mounted(){
        // console.log(window.location.href.split('#')[0])
        // alert('缓存')
        // alert(JSON.stringify(window.localStorage))
        
    },
    methods: {

        //开始录音
        start(){
            wx.startRecord();
        },
        //结束录音
        stop(){
            alert(9999)
            wx.stopRecord({
                success: function (res) {
                    alert('成功')
                    alert(JSON.stringify(res));
                    this.localId = res.localId;
                    window.localStorage.setItem('localId', res.localId)
                    alert(this.localId)
                },
                fail: function (res) {
                    alert('失败了');
                },
            });
        },
        //播放录音
        play(){

            alert('播放')
            let localId = window.localStorage.getItem('localId')
            alert(localId)
            alert(this.localId)
            wx.playVoice({
                localId: localId, // 需要播放的音频的本地ID，由stopRecord接口获得
                success: function (res) {
                    alert('成功'+JSON.stringify(res))
                },
                fail: function (res) {
                    alert('失败'+JSON.stringify(res));
                },
                complete: function (res) {
                    // alert('df')
                    console.log(res)
                }
            });  
        },
        //语音转文字
        translateVoice(){
            alert(this.localId)
            let localId = window.localStorage.getItem('localId')
            alert(localId)
            wx.translateVoice({
                localId: localId, // 需要识别的音频的本地Id，由录音相关接口获得，音频时长不能超过60秒
                isShowProgressTips: 1, // 默认为1，显示进度提示
                success: function (res) {
                    alert('成功')
                    alert(res.translateResult); // 语音识别的结果
                    this.words = res.translateResult;
                },
                fail: function (res) {
                    alert('失败'); // 语音识别的结果
                }
            });
        },
        //获取access_token
        get_access_token(){
            alert(33)
            axios.get(`${this.url}/cgi-bin/gettoken`,{
                params: {
                    corpid : this.corpId,
	                corpsecret : this.corpSecret,
                }
            }).then(res=>{
                alert(11)
                alert(JSON.stringify(res.data))
                if(res.data.errmsg=='ok'){
                    alert('获取access_token: 成功');
                    window.localStorage.setItem('access_token', res.data.access_token);
                    this.get_ticket(res.data.access_token);
                }
            }).catch(function (error) {
                alert('错误')
                alert(JSON.stringify(error))
            })
        },
        //获取应用身份ticket
        get_ticket(access_token){
            axios.get(`${this.url}/cgi-bin/ticket/get`,{
                params: {
                    access_token : access_token,
	                type : 'agent_config',
                }
            }).then(res=>{
                if(res.data.errmsg=='ok'){
                    alert('获取应用身份ticket: 成功');
                    this.getAuthSign();
                    window.localStorage.setItem('ticket', res.data.ticket);
                }
            })
        },
        //获取签名signature
        getAuthSign(){
            this.$api.engineering.getAuthSign({
                "corpId": this.corpId,
                "corpSecret": this.corpSecret,
                "noncestr": this.nonceStr,
                "timestamp": this.timeStamp,
                "url": window.location.href.split('#')[0], //当前网页的URL，不包含#及其后面部分
            }).then(res=>{
                alert(1)
                if(res.state.code==10000){
                    alert('获取签名signature: 成功');
                    window.localStorage.setItem('signature', res.body.message);
                    this.getBase();
                    
                }
            })
        },
        getBase(){
            alert(window.localStorage.getItem('signature'))
            wx.config({
                beta: true,// 调用wx.invoke形式的接口值时，该值必须为true。
                debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                appId: this.corpId, // 必填，企业微信的cropID
                timestamp: this.timeStamp, // 必填，生成签名的时间戳
                nonceStr: this.nonceStr, // 必填，生成签名的随机串
                signature: window.localStorage.getItem('signature'),// 必填，签名，见附录1
                // jsApiList: '',
                jsApiList: ['startRecord','stopRecord','playVoice', 'onVoiceRecordEnd','translateVoice'], // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                success: function(res){
                    alert('2成功')
                    console.log(res)
                },
                fail: function(res){
                    alert('3失败')
                    alert(JSON.stringify(res))
                },
                complete: function(res){
                    alert('config完成')
                    alert(res)
                }
            });
            wx.ready(()=>{
                
            }),
            wx.error(function(res){
                 alert('出错了：' + JSON.stringify(res))
                 alert(wx.config)
                // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
            });
            wx.invoke("agentConfig", {
                agentid: this.corpId, // 必填，企业应用的agentid
                corpid: this.corpId,  // 必填，企业微信的corpid
                timestamp: this.timeStamp, // 必填，生成签名的时间戳,int类型, 如 1539100800
                nonceStr: this.nonceStr, // 必填，生成签名的随机串
                signature: window.localStorage.getItem('signature'),// 必填，签名，见附录5
            }, function(res) {
                if(res){
                    alert(6);
                    alert(JSON.stringify(res));
                }
                if(res.err_msg != "agentConfig:ok"){
                    //错误处理
                    return;
                }
                //这里可以调用用户数据接口
            });
        }
    }
}
</script>

<style lang="scss" scoped>

</style>