<template>
    <div class="nothing">
        <img src="../../assets/img//nothing.png" alt="">
        暂未数据
    </div>
</template>

<script>
    export default {}
</script>

<style scoped>
    .nothing {
        text-align: center;
        margin-top: 100px;
    }

    img {
        width: 396px;
        height: 374px;
    }
</style>