<template>
  <div class="exchange">
    <ul class="tab">
      <li class="tabitem active">粤海汇兑</li>
      <li class="tabitem" @click="location">市场汇率</li>
    </ul>

    <div class="chart" id="exchange" ref="exchange_1">
      <div id="myChart_exchange_1" :style="{height: height+'px'}"></div>
    </div>
    <div class="chart" id="exchange" ref="exchange_2">
      <div id="myChart_exchange_2" :style="{height: height+'px'}"></div>
    </div>

    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script type="text/ecmascript-6">
import Loading from "../../components/loading";
export default {
  name: "exchange",
  data() {
    return {
      height: 300,
      loadingShow: false, //加载图层
      flagclass: "0"
    };
  },
  mounted() {},
  created() {
    this._foreignexchangesvc();
  },
  methods: {
    // 初始化数据
    _foreignexchangesvc() {
      this.$api.exchange
        .exchangeinitialize()
        .then(response => {
          if (response.state.code == 10000) {
            this.loadingShow = false;
            var pricelist = response.body.dataList.map(item => {
              return {
                name: item.name,
                data: item.data,
                type: "line",
                stack: "总量",
                // areaStyle: {},
                label: {
                  normal: {
                    show: true,
                    position: "top"
                  }
                }
              };
            });
            // console.log(pricelist);
            this.LineChart(
              "myChart_exchange_1",
              response.body.monthList,
              response.body.nameList,
              pricelist.splice(1, 2).reverse(),
              ["#c23531"],
              1,
              1.2
            );
            // this.$refs.exchange_1.style.display = "none";
            this.LineChart(
              "myChart_exchange_2",
              response.body.monthList,
              response.body.nameList,
              pricelist.splice(0, 1).reverse(),
              ["#2f4554"],
              7,
              8
            );
            // this.$refs.exchange_2.style.display = "none";
          } else {
            console.log("状态错误");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    LineChart(id, monthList, nameList, dataList, color,min,max ) {
      let myChart = this.$echarts.init(document.getElementById(id));
      let option = {
        title: {
          subtext: "汇兑:港币(HKD)",
          left: "right"
        },
        color: color,
        tooltip: {
          trigger: "axis"
        },
        legend: {
          icon: "stack",
          bottom: "4%",
          left: "center",
          width: "100%",
          align: "auto",
          // data: ["邮件营销", "联盟广告", "视频广告", "直接访问", "搜索引擎"]
          data: nameList
        },
        grid: {
          left: "2%",
          right: "6%",
          bottom: "10%",
          top: "16%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: monthList
        },
        yAxis: {
          type: "value",
          min: min,
          max: max,
          interval:true,
          spiltNumber:3
        },
        series: dataList
        // series: [
        //   {
        //     name: "邮件营销",
        //     type: "line",
        //     stack: "总量",
        //     data: [500, 500, 500, 500, 500, 500, 500]
        //   },
        //   {
        //     name: "联盟广告",
        //     type: "line",
        //     stack: "总量",
        //     data: [600, 600, 600, 600, 600, 600, 600]
        //   },
        //   {
        //     name: "视频广告",
        //     type: "line",
        //     stack: "总量",
        //     data: [150, 232, 201, 154, 190, 330, 410]
        //   },
        //   {
        //     name: "直接访问",
        //     type: "line",
        //     stack: "总量",
        //     data: [320, 332, 301, 334, 390, 330, 320]
        //   },
        //   {
        //     name: "搜索引擎",
        //     type: "line",
        //     stack: "总量",
        //     data: [820, 932, 901, 934, 1290, 1330, 1320]
        //   }
        // ]
      };
      myChart.setOption(option);
    },
    location() {
      window.location.href = "http://www.chinamoney.com.cn/chinese/bkccpr/";
    }
  },
  components: { Loading }
};
</script>

<style scoped lang="scss">
.exchange {
  background-color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 100px;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  .tab {
    display: flex;
    height: 105px;
    background: rgba(255, 255, 255, 1);
    .tabitem {
      font-size: 36px;
      font-family: Adobe Heiti Std;
      font-weight: bold;
      color: rgba(1, 1, 1, 1);
      opacity: 0.6;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .active {
      opacity: initial;
      position: relative;
      &.active::before {
        content: "";
        display: inline-block;
        width: 210px;
        height: 10px;
        background: #e71710;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
  }
  .money {
    // display: flex;
    .active {
      opacity: initial;
      position: relative;
      &.active::before {
        content: "";
        display: inline-block;
        width: 210px;
        height: 10px;
        background: black;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
  }
  #exchange {
    background: #fff;
    margin-top: 30px;
    padding: 30px 0;
    position: relative;
    .chart_title {
      font-size: 38px;
      font-family: PingFang SC;
      font-weight: 800;
      color: rgba(0, 0, 0, 1);
      position: relative;
      &.chart_title::before {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        left: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
      &.chart_title::after {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        right: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
    }
    .businesstitle {
      position: absolute;
      top: 220px;
      left: 50px;
      display: flex;
      flex-direction: column;
      .item {
        display: flex;
        align-items: center;
        font-family: PingFang SC;
        font-weight: 800;
      }
    }
  }
}
</style>
