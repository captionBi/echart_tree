<template>
  <div class="yuehaishare">
    <div class="stock_box" v-for="(item,index) in Arr" :key="index" @click="ClickStock(item,index)">
      <!-- 上半部 -->
      <!-- <a :href="item.stockUrl"> -->
      <div class="stock_top">
        <div class="stock_name">
          <div :class="item.upDown>=0?'asquare':'asquares'"></div>
          <div
            class="mini_box"
            :class="item.upDown>=0?'stock_red':'stock_green'"
          >{{item.stockName}}</div>
          <div class="stock_code">
          <p v-if="item.stockCode==''">--</p>
          <p v-else>{{item.stockCode}}</p>
        </div>
        </div>
        
        <div v-if="item.stockTime==''?false:true" class="time">{{item.stockTime}}</div>
        <div v-else class="time_show"></div>
      </div>
      <!-- 下半部 -->
      <div class="stock_below">
        <ul class="stock_content_box">
          <li class="stock_content">
            <div>现价</div>
            <p>{{item.currentPrice}}</p>
          </li>
          <li class="stock_content">
            <div>涨跌</div>
            <p :class="item.upDown>=0?'stock_red':'stock_green'">{{item.upDown}}</p>
          </li>
          <li class="stock_content">
            <div>涨幅</div>
            <p :class="item.upDown>=0?'stock_red':'stock_green'">{{item.stockIncrease}}%</p>
          </li>
          <li class="stock_content" v-if="item.totalRatio===''?false:true">
            <div>总市值</div>
            <p :class="item.upDown>=0?'stock_red':'stock_green'">{{item.totalRatio}}</p>
          </li>
          <li class="stock_content" v-if="item.cityWorth===''?false:true">
            <div>市盈率</div>
            <p :class="item.upDown>=0?'stock_red':'stock_green'">{{item.cityRatio}}</p>
          </li>
          <li class="stock_content" v-if="item.cityWorth===''?false:true">
            <div>市净率</div>
            <p :class="item.upDown>=0?'stock_red':'stock_green'">{{item.cityWorth}}</p>
          </li>
        </ul>
      </div>
      <!-- </a> -->
      <div class="Stock_Show" v-if="item.StockShow">
        <img :src="item.stockUrl" alt />
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { get } from "../../api/config";
import Vue from "vue";
var stockDatas = [];
export default {
  name: "yuehaishare",
  data() {
    return {
      Arr: [],
      Code: true,
    };
  },
  mounted() {
    this.shenZhi();
    this.hangSheng();
    this.shangZhi();
    this.yueHaiTouZhi();
    this.yueHaiZhiDi();
    this.yueHaiZhiGe();
    this.guangNan();
    var dataAll = window.setInterval(() => {
      if (stockDatas.length == 7) {
        window.clearInterval(dataAll);
        this.Arr = stockDatas.sort((a, b) => a.stockIndex - b.stockIndex);
        //   console.log(stockDatas.sort(this.Arr));
        let StockList = this.Arr;
        StockList.map((item) => {
          Vue.set(item, "StockShow", false);
        });
        // console.log(this.Arr);
      }
    }, 100);
    // this.ClickStock()
  },
  methods: {
    ClickStock(item) {
      item.StockShow = !item.StockShow;
    },
    shenZhi() {
      get("http://qt.gtimg.cn/q=sz399001").then((res) => {
        // console.log(res,123123123);
        // var stockDataArray = res.body.message.split("~");
        var stockDataArray = res.split("~");
        var stockData = {
          stockIndex: 6,
          stockName: "深证成指",
          stockCode: "399001",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[32],
          stockTime: "",
          totalRatio: "",
          cityRatio: "",
          cityWorth: "",
          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=0.399001&unitWidth=-6&ef=&formula=RSI&type=&imageType=KXL&&0.9971659808632636",
        };
        stockDatas.push(stockData);
      });
    },
    hangSheng() {
      get("http://qt.gtimg.cn/q=hkHSI").then((res) => {
        // console.log(res.body.message,123123123);
        var stockDataArray = res.split("~");
        // if (stockDataArray[3].indexOf("%") > -1) {
        //   stockDataArray[3] = stockDataArray[3].substr(
        //     0,
        //     stockDataArray[3].indexOf("%")
        //   );
        // }
        // if (stockDataArray[3].indexOf('"') > -1) {
        //   stockDataArray[3] = stockDataArray[3].substr(
        //     0,
        //     stockDataArray[3].indexOf('"')
        //   );
        // }
        var stockData = {
          stockIndex: 7,
          stockName: "恒生指数",
          stockCode: "HSI",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[32],
          totalRatio: "",
          cityRatio: "",
          cityWorth: "",
          stockTime: "",
          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=100.HSI&type=&unitWidth=-6&ef=&formula=RSI&imageType=KXL&_=1595931523562",
        };
        stockDatas.push(stockData);
      });
    },
    shangZhi() {
      get("http://qt.gtimg.cn/q=sh000001").then((res) => {
        //   console.log(res);
        // console.log(res.body.message,123123123);
        // var stockDataArray = res.body.message.split("~");
        var stockDataArray = res.split("~");
        var stockData = {
          stockIndex: 5,
          stockName: "上证指数",
          stockCode: "000001",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[32],
          totalRatio: "",
          cityRatio: "",
          cityWorth: "",
          stockTime: "",
          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=1.000001&unitWidth=-6&ef=&formula=RSI&type=&imageType=KXL&&1595931014965;",
        };
        stockDatas.push(stockData);
      });
    },
    yueHaiTouZhi() {
      get("http://qt.gtimg.cn/q=hk00270").then((res) => {
        // console.log(res, 123123123);
        // var stockDataArray = res.body.message.split("~");
        // console.log(res);
        var stockDataArray = res.split("~");
        // var stockTime =
        //   stockDataArray[stockDataArray.length - 2] +
        //   " " +
        //   stockDataArray[stockDataArray.length - 1].substr(
        //     0,
        //     stockDataArray[stockDataArray.length - 1].indexOf('"')
        //   );
        var stockData = {
          stockIndex: 1,
          stockName: "粤海投资",
          stockCode: "00270",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[32],
          stockTime: stockDataArray[30].split(' ')[0],
          totalRatio: stockDataArray[45],
          cityRatio: stockDataArray[57],
          cityWorth: stockDataArray[58],
          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?imageType=KXL&nid=116.00270&type=D&unitWidth=-6&ef=&formula=RSI",
        };
        stockDatas.push(stockData);
      });
    },
    yueHaiZhiDi() {
      get("http://qt.gtimg.cn/q=hk00124").then((res) => {
        // console.log(res.body.message,123123123);
        // var stockDataArray = res.body.message.split("~");
        var stockDataArray = res.split("~");
        // var stockTime =
        //   stockDataArray[stockDataArray.length - 2] +
        //   " " +
        //   stockDataArray[stockDataArray.length - 1].substr(
        //     0,
        //     stockDataArray[stockDataArray.length - 1].indexOf('"')
        //   );
        var stockData = {
          stockIndex: 2,
          stockName: "粤海置地",
          stockCode: "00124",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[8],
          stockTime: stockDataArray[30].split(' ')[0],
          totalRatio: stockDataArray[45],
          cityRatio: stockDataArray[57],
          cityWorth: stockDataArray[58],

          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?imageType=KXL&nid=116.00124&type=D&unitWidth=-6&ef=&formula=RSI",
        };
        stockDatas.push(stockData);
      });
    },
    yueHaiZhiGe() {
      get("http://qt.gtimg.cn/q=hk01058").then((res) => {
        // console.log(res.body.message,123123123);
        // var stockDataArray = res.body.message.split("~");
        var stockDataArray = res.split("~");
        // var stockTime =
        //   stockDataArray[stockDataArray.length - 2] +
        //   " " +
        //   stockDataArray[stockDataArray.length - 1].substr(
        //     0,
        //     stockDataArray[stockDataArray.length - 1].indexOf('"')
        //   );
        var stockData = {
          stockIndex: 4,
          stockName: "粤海制革",
          stockCode: "01058",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[8],
          stockTime: stockDataArray[30].split(' ')[0],
          totalRatio: stockDataArray[45],
          cityRatio: stockDataArray[57],
          cityWorth: stockDataArray[58],

          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?imageType=KXL&nid=116.01058&type=D&unitWidth=-6&ef=&formula=RSI",
        };
        stockDatas.push(stockData);
      });
    },
    guangNan() {
      get("http://qt.gtimg.cn/q=hk01203").then((res) => {
        // console.log(res.body.message,123123123);
        // var stockDataArray = res.body.message.split("~");
        var stockDataArray = res.split("~");
        // var stockTime =
        //   stockDataArray[stockDataArray.length - 2] +
        //   " " +
        //   stockDataArray[stockDataArray.length - 1].substr(
        //     0,
        //     stockDataArray[stockDataArray.length - 1].indexOf('"')
        //   );
        var stockData = {
          stockIndex: 3,
          stockName: "广南（集团）",
          stockCode: "01203",
          currentPrice: stockDataArray[3],
          upDown: stockDataArray[31],
          stockIncrease: stockDataArray[8],
          stockTime: stockDataArray[30].split(' ')[0],
          totalRatio: stockDataArray[45],
          cityRatio: stockDataArray[57],
          cityWorth: stockDataArray[58],

          stockUrl:
            "http://webquoteklinepic.eastmoney.com/GetPic.aspx?imageType=KXL&nid=116.01203&type=D&unitWidth=-6&ef=&formula=RSI",
        };
        stockDatas.push(stockData);
      });
    },
  },
};
</script>

<style scoped lang="scss">
.yuehaishare {
  //   margin: 0 20px 0 20px;

  .stock_box {
    padding: 20px;
    border-bottom: 1px solid #e7e5e7;

    // 上半部
    .stock_top {
      display: flex;
      justify-content: space-between;
      .stock_name {
        font-size: 40px;
        font-weight: 700;
        display: -webkit-inline-box;
        .asquare {
          width: 10px;
          height: 100%;
          background-color: red;
        }
        .mini_box {
          padding-left: 10px;
        }
        .stock_code {
        line-height: 181%;
        font-weight: 700;
        font-size: 1rem;
    padding-left: 3vw;
      }
      }
      .time {
        line-height: 180%;
        color: #4f4f50;
        width: 6rem;
      }
      .time_show {
        width: 37vw;
      }
      
    }
    .stock_below {
      padding-top: 15px;
      .stock_content_box {
        display: flex;
        flex: 1;
        justify-content: space-between;

        .stock_content {
          // text-align: center;
          width: 7.5rem;
          font-size: 1rem;
          p {
            padding-top: 8px;
            font-weight: bold;
          }
        }
      }
    }
    a {
      color: #000;
    }
    .Stock_Show {
      img {
        width: 100%;
      }
    }
  }
  .stock_green {
    color: #43a34a;
  }
  .stock_red {
    color: #d04f47;
  }
  .asquare {
    width: 10px;
    height: 100%;
    background-color: #d04f47;
  }
  .asquares {
    width: 10px;
    height: 100%;
    background-color: #43a34a;
  }
}
</style>
