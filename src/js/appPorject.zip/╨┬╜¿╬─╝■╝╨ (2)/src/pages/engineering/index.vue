<template>
  <div class="engineer">
    <div class="content" ref="obtain">
      <div class="engineer_module">
        <div
          class="engineer_module_item engineer_module_first bordus text-center"
        >
          <a href="#total">
            <p class="engineer_module_item_title">总投资额</p>
            <div>
              <span class="big_count">{{
                topData.investmentCount | currency
              }}</span>
              <span>万元</span>
            </div>
          </a>
        </div>
        <div
          class="engineer_module_second bordus text-center flex justify-between"
        >
          <div class="text-center engineer_img">
            <a href="#engineer_list">
              <p class>在建项目</p>
              <div>
                <span class="middle_count">{{
                  topData.totalCount | currency
                }}</span>
                <span>个</span>
              </div>
            </a>
          </div>
          <div class="text-center engineer_img">
            <a href="#plan">
              <p class>年度计划投资</p>
              <div>
                <span class="middle_count">{{
                  topData.investmentPlanCount | currency
                }}</span>
                <span>万元</span>
              </div>
            </a>
          </div>
        </div>
        <div
          class="engineer_module_second bordus text-center flex justify-between"
        >
          <div class="text-center engineer_img">
            <a href="#finish">
              <p class>年度完成投资</p>
              <div>
                <span class="middle_count">{{
                  topData.yearFinishCount | currency
                }}</span>
                <span>万元</span>
              </div>
            </a>
          </div>
          <div class="text-center engineer_img">
            <a href="#count">
              <p class>累计完成投资</p>
              <div>
                <span class="middle_count">{{
                  topData.finishCount | currency
                }}</span>
                <span>万元</span>
              </div>
            </a>
          </div>
          <!-- <div class="line"></div>
        <div class="flex justify-around border_bot padding-bottom-sm">
          <div class="text-center basis-sm">
            <p class="yellow_title">在建项目</p>
            <div>
              <span class="middle_count">{{topData.totalCount | currency}}</span> <span>个</span>
            </div>
          </div>
          <div class="text-center basis-sm ">
            <p class="yellow_title">年度计划投资</p>
            <div>
              <span class="middle_count">{{topData.investmentPlanCount| currency}}</span> <span>万元</span>
            </div>
          </div>
        </div>
        <div class="flex justify-around padding-top-sm">
          <div class="text-center basis-sm">
            <p class="yellow_title">年度完成投资</p>
            <div>
              <span class="middle_count">{{topData.finishCount| currency}}</span> <span>万元</span>
            </div>
          </div>
          <div class="text-center basis-sm ">
            <p class="yellow_title">累计完成投资</p>
            <div>
              <span class="middle_count">{{topData.yearFinishCount| currency}}</span> <span>万元</span>
            </div>
          </div>
        </div>-->
        </div>
        <!-- echart饼图   板块总投资概况-->
        <div class="padding-top chart" id="total">
          <div class="chart_tit">
            <p class="text-center text-sm chart_title">板块总投资概况</p>
            <div class="bot_line"></div>
          </div>
          <div id="myChart" :style="{ height: height + 'px' }"></div>
          <p class="text-gray text-df margin-bottom">*点击饼状图查看详情*</p>
          <img
            src="../../assets/img/engineering/look.gif"
            alt=""
            class="look"
          />
        </div>
        <!-- echart饼图   板块年度计划投资概况-->
        <div class="padding-top chart" id="plan">
          <div class="chart_tit">
            <p class="text-center text-sm chart_title">板块年度计划投资概况</p>
            <div class="bot_line"></div>
          </div>
          <div id="myChart_plan" :style="{ height: height + 'px' }"></div>

          <p class="text-gray text-df margin-bottom">*点击饼状图查看详情*</p>
          <img
            src="../../assets/img/engineering/look.gif"
            alt=""
            class="look"
          />
        </div>
        <!-- echart饼图   板块年度完成投资概况-->
        <div class="padding-top chart" id="finish">
          <div class="chart_tit">
            <p class="text-center text-sm chart_title">板块年度完成投资概况</p>
            <div class="bot_line"></div>
          </div>
          <div id="myChart_count" :style="{ height: height + 'px' }"></div>
          <p class="text-gray text-df margin-bottom">*点击饼状图查看详情*</p>
          <img
            src="../../assets/img/engineering/look.gif"
            alt=""
            class="look"
          />
        </div>
        <!-- echart饼图   板块累积完成投资概况-->
        <div class="padding-top chart" id="count">
          <div class="chart_tit">
            <p class="text-center text-sm chart_title">板块累计完成投资概况</p>
            <div class="bot_line"></div>
          </div>
          <div id="myChart_finish" :style="{ height: height + 'px' }"></div>
          <p class="text-gray text-df margin-bottom">*点击饼状图查看详情*</p>
          <img
            src="../../assets/img/engineering/look.gif"
            alt=""
            class="look"
          />
        </div>
        <!-- echart 仪表盘 -->
        <!-- <div class="padding-top text-main chart chart_none">
            <p class="text-center text-sm">年度投资计划完成率</p>
            <div id="myClock" :style="{height: height+'px'}"></div>
      </div>-->
        <!-- echart 仪表盘 -->
        <!-- <div class="padding-top text-main chart">
        <p class="text-center text-sm">年度投资计划完成率</p>
        <div id="myChart2" :style="{height: height+'px'}"></div>
      </div>-->
      </div>
      <!-- 搜索框数据 -->
      <div class="engineer_search" id="engineer_list">
        <!-- searchParams向子组件传值 -->
        <screen
          class="screen"
          @getSearchList="screeningRequest"
          @searchParams="getSearchParams"
          @chooseItem="chooseItem"
          @cancle="cancle"
        ></screen>
      </div>
      <!-- 显示所有数据 -->
      <ol class="engineer_list">
        <li
          class="list_item"
          v-for="(item, index) in projectList"
          :key="index"
          @click="goDetail(item, index)"
        >
          <div class="li_child flex justify-between">
            <img class="list_item_img" :src="imgUrl" alt />
            <div class="list_item_cont">
              <p
                class="list_item_cont_title red bold"
                :class="item.projectStatus == 0 ? 'green_status' : 'red_status'"
              >
                {{ item.projectName }}
              </p>
              <p class="list_item_cont_fee text-md" style="line-height: 15px">
                总投资额:{{ item.investmentCount | currency }}万元
              </p>
              <p class="list_item_cont_status text-md">
                阶段:{{ item.projectPeriod | projectPeriod }}
              </p>
            </div>
            <div
              class="list_item_status"
              style="line-height: 15px; width: 90px"
            >
              <span
                class="dot"
                :class="item.projectStatus == 0 ? 'greenDot' : 'redDot'"
              ></span>
              <span
                class="status"
                :class="item.projectStatus == 0 ? 'green_status' : 'red_status'"
                >{{ item.projectStatus == 0 ? "正常" : item.delayTime }}</span
              >
            </div>
          </div>
        </li>
      </ol>
    </div>

    <div class="back" v-if="btnFlag" @click="backTop">
      <img src="../../assets/img/engineering/back.png" alt="" />
    </div>
    <!-- loading -->
    <loading v-if="loadingShow"></loading>

    <!-- <scrollTop></scrollTop> -->
  </div>
</template>

<script>
import screen from "../../components/screen";
import loading from "../../components/loading";
// import scrollTop from "../common/scrollTop";
import { Search, Tab, Tabs } from "vant";
export default {
  name: "engineers",
  components: {
    screen,
    loading,
    [Search.name]: Search,
    [Tab.name]: Tab,
    [Tabs.name]: Tabs,
  },
  data() {
    return {
      imgUrl: require("../../assets/img/engineering/eng.jpg"),
      height: 220,
      datas: "",
      topData: {
        totalCount: "",
        investmentCount: "",
        investmentPlanCount: "",
        yearFinishCount: "",
        finishCount: "",
      },
      projectList: [],
      eChartData: [],
      eChartData1: [],
      eChartData2: [],
      eChartData3: [],
      eChartData4: [],
      loadingShow: true,
      projectUrl: "../../assets/img/engineerng/project.png",
      engineer1: require("../../assets/img/engineering/p1.png"),
      engineer2: require("../../assets/img/engineering/p2.png"),
      btnFlag: false,
      scrollTop: 0,
    };
  },

  created() {
    this.getEngineeringCount();
    this.getChart();
  },
  mounted() {
    // 滚动条的获取
    window.addEventListener("scroll", this.handleScrollx, true);
  },

  methods: {
    screeningRequest(param) {
      this.projectList = param;
      //   this.getEngineeringCount()
    },
    handleScrollx() {
      this.scrollTop = window.pageYOffset;
      if (this.scrollTop > 200) {
        this.btnFlag = true;
      } else {
        this.btnFlag = false;
      }
    },
    backTop() {
      window.scrollTo(0, 0);
    },
    cancle() {
      this.projectList = [];
      this.getEngineeringCount();
    },
    //
    chooseItem(data) {
      this.projectList = [];
      this.projectList.push(data);
    },
    getSearchParams(data) {
      console.log(data);
      this.datas = data;
      if (!data.projectName) {
        this.getEngineeringCount();
      }
    },
    getChart() {
      this.$api.engineering
        .getBoardData()
        .then((res) => {
          this.loadingShow = false;
          if (res.state.code === 10000) {
            res.body.yearInvestmentPlanCount.map((item) => {
              this.eChartData2.push({
                name: item.name,
                value: item.count,
                num: item.count + "",
              });
            });
            res.body.investmentProgressYearCount.map((item) => {
              this.eChartData3.push({
                name: item.name,
                value: item.count,
                num: item.count + "",
              });
            });
            res.body.investmentProgressCount.map((item) => {
              this.eChartData4.push({
                name: item.name,
                value: item.count,
                num: item.count + "",
              });
            });
            this.$nextTick(function () {
              this.drawChart(
                this.eChartData2,
                "myChart_plan",
                "yearInvestmentPlanCount",
                "板块年度计划投资概况"
              );
              this.drawChart(
                this.eChartData3,
                "myChart_count",
                "investmentProgressYearCount",
                "板块年度完成投资概况"
              );
              this.drawChart(
                this.eChartData4,
                "myChart_finish",
                "investmentProgressCount",
                "板块累计完成投资概况"
              );
              // this.drawClockChart(rate);
              // this.drawChart2()
            });
          }
        })
        .catch(() => {
          //   console.log('接口请求失败')
          this.loadingShow = false;
        });
    },

    // 获取工程概览统计信息
    getEngineeringCount() {
      this.projectList = [];
      this.loadingShow = true;
      this.eChartData1 = [];
      let obj = {
        projectName: "",
        projectType: "",
        projectStatus: "",
        projectPeriod: "",
        projectBoard: "",
      };
      let params = {};
      this.topData = {};
      Object.assign(params, obj, this.datas);
      this.$api.engineering
        .getEngineering(params)
        .then((res) => {
          this.loadingShow = false;
          if (res.state.code === 10000) {
            this.topData = {
              ...this.topData,
              ...res.body.topData,
            };
            this.projectList = res.body.projectList;
            let yearFinishCount = parseInt(res.body.topData.yearFinishCount);
            let investmentPlanCount = parseInt(
              res.body.topData.investmentPlanCount
            );
            let rate = "";
            if (investmentPlanCount == 0) {
              rate = 0;
            } else {
              rate = (yearFinishCount / investmentPlanCount) * 100;
            }
            console.log(rate, "rate---------");
            rate = rate.toFixed(1);
            res.body.eChartData.map((item) => {
              console.log(item, 222222222);
              this.eChartData1.push({
                name: item.name,
                value: item.count,
                num: item.count + "",
              });
              console.log(this.eChartData1);
            });
            this.$nextTick(function () {
              this.drawChart(
                this.eChartData1,
                "myChart",
                "investmentCount",
                "板块总投资概况"
              );
            });
          }
        })
        .catch(() => {
          // console.log('接口请求失败')
          this.loadingShow = false;
        });
    },
    // echart饼图
    drawChart(data, id, type, title) {
      console.log(data, id, type, title, 11111111111111111111111);
      let myChart = this.$echarts.init(document.getElementById(id));
      let option = {
        // tooltip: {
        //   trigger: "item",
        //   formatter: function (data) {
        //     var counter = 0;
        //     var result = [];
        //     var num_array = data.data.num.split(".");
        //     var num = num_array[0];
        //     var str = "";
        //     for (var i = num.length - 1; i >= 0; i--) {
        //       counter++;
        //       result.unshift(num[i]);
        //       if (!(counter % 3) && i != 0) {
        //         result.unshift(",");
        //       }
        //     }
        //     if (num_array.length > 1) {
        //       str = result.join("") + "." + num_array[1] + "万元";
        //     } else {
        //       str = result.join("") + "万元";
        //     }
        //     return (
        //       data.name + "<br/>" + str + " " + data.percent.toFixed(0) + "%"
        //     );
        //   },
        //   textStyle: {
        //     fontSize: 12
        //   }
        // },
        color: ["#3274FF", "#945CDE", "#FEA700"],
        series: [
          {
            hoverAnimation: false, //扇区放大高亮
            name: "",
            type: "pie",
            radius: ["32%", "50%"],
            avoidLabelOverlap: true,
            label: {
              // position: "outside",
              // alignTo: "edge",
              fontSize: "18",
              align: "left",
              color: "#606266",
              margin: 0,
              formatter: function (a) {
                var result = [],
                  counter = 0;
                var isFloat = String(a.data.num).indexOf(".");
                if (isFloat != -1) {
                  var n = parseInt(a.data.num).toFixed(0);
                  a.data.num = n.toString();
                }
                var num_array = a.data.num.split(".");
                var num = num_array[0];
                var newstr = "";
                for (var i = num.length - 1; i >= 0; i--) {
                  counter++;
                  result.unshift(num[i]);
                  if (!(counter % 3) && i != 0) {
                    result.unshift(",");
                  }
                }
                if (num_array.length > 1) {
                  newstr = result.join("");
                  newstr += "." + num_array[1];
                  return [
                    "{a|" + a.name + "}",
                    "{b|" + newstr + "万元" + "}",
                    "{c|" + a.percent.toFixed(0) + "%" + "}",
                  ].join("\n");
                } else {
                  return [
                    "{a|" + a.name + "}",
                    "{b|" + result.join("") + "万元" + "}",
                    "{c|" + a.percent.toFixed(0) + "%" + "}",
                  ].join("\n");
                }
              },
              rich: {
                a: {
                  lineHeight: 14,
                  fontSize: 16,
                  fontWeight: "bold",
                },
                b: {
                  lineHeight: 20,
                  fontSize: 14,
                  fontWeight: "bold",
                },
                c: {
                  lineHeight: 12,
                  height: 15,
                  fontSize: 14,
                  fontWeight: "bold",
                },
              },
            },
            labelLine: {
              show: true,
              length: 10,
              length2: 5,
              lineStyle: {
                color: "#D6D6D6",
              },
            },
            data: data,
          },
        ],
      };
      myChart.setOption(option);
      // echart 点击事件
      let self = this;
      myChart.on("click", function (params) {
        console.log(title);
        console.log(
          params.name,
          "name---",
          type,
          "type===",
          params.data,
          "data",
          params.title
        );
        let name =
          params.name == "水务及水环境治理"
            ? "0"
            : "" || params.name == "产业园及制造业"
            ? "1"
            : "" || params.name == "城市综合体"
            ? "2"
            : "";
        self.$router.push({
          name: "engineering-plate",
          query: {
            board: name,
            type: type,
            data: params.data.num,
            title: title,
          },
        });
      });
    },
    // 仪表图
    drawClockChart(rate) {
      // console.log(rate)
      let myClock = this.$echarts.init(document.getElementById("myClock"));
      let option = {
        tooltip: {
          formatter: "{a} <br/>{b} : {c}%",
        },
        series: [
          {
            name: "业务指标",
            radius: "50%",
            center: ["50%", "55%"],
            type: "gauge",
            axisLabel: {
              show: false,
            },
            pointer: {
              width: 5,
              length: "70%",
            },
            axisTick: {
              length: 1,
            },
            splitLine: {
              length: 0,
            },
            axisLine: {
              show: true,

              lineStyle: {
                width: 20,
                color: [
                  [0.25, "#3274FF"],
                  [0.5, "#945CDE"],
                  [0.75, "#FEA700"],
                  [1, "#6EC17D"],
                ],
              },
            },
            detail: {
              formatter: "{value}%",
            },
            data: [
              {
                value: rate,
              },
            ],
          },
        ],
      };

      myClock.setOption(option);
    },
    // 饼图
    // drawChart2 () {
    //   let myChart = this.$echarts.init(document.getElementById("myChart2"));
    //   let option = {
    //     tooltip: {
    //       trigger: 'item',
    //       formatter: function (data) {
    //         var counter = 0;
    //         var result = [];
    //         var num_array = data.data.num.split('.');
    //         var num = num_array[0];
    //         var str = '';
    //         for (var i = num.length - 1; i >= 0; i--) {
    //           counter++;
    //           result.unshift(num[i]);
    //           if (!(counter % 3) && i != 0) {
    //             result.unshift(',');
    //           }
    //         }
    //         if (num_array.length > 1) {
    //           str = result.join('') + '.' + num_array[1] + '万元';
    //         } else {
    //           str = result.join('') + '万元'
    //         }
    //         return data.name + '<br/>' + str + ' ' + data.percent.toFixed(0) + '%'
    //       },
    //       textStyle: {
    //         fontSize: 12
    //       },
    //     },
    //     color: ['#3274FF', '#945CDE', '#FEA700'],
    //     series: [{
    //       name: '',
    //       type: 'pie',
    //       radius: ['30%', '45%'],
    //       avoidLabelOverlap: false,
    //       label: {
    //         show: false,
    //         position: 'center'
    //       },
    //       emphasis: {
    //         label: {
    //           show: true,
    //           fontSize: '30',
    //           fontWeight: 'bold'
    //         }
    //       },
    //       labelLine: {
    //         show: false
    //       },
    //       data: [
    //         { value: 335, name: '直接访问' },
    //         { value: 310, name: '邮件营销' },
    //         { value: 234, name: '联盟广告' },
    //         { value: 135, name: '视频广告' },
    //         { value: 1548, name: '搜索引擎' }
    //       ]
    //     }]
    //   }
    //   myChart.setOption(option);

    // },
    // 跳转到详情页面
    goDetail(item) {
      this.$router.push({
        // name: "engineer-detail",
        name: "projectDetail",
        query: {
          id: item.id,
          projectName: item.projectName,
        },
      });
    },
    tabClick() {},
    stageConfirm() {},
    onSearch() {},
  },
};
</script>

<style lang="scss" scoped>
/deep/.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  width: 0;
}

@import "./css/index.scss";
</style>
