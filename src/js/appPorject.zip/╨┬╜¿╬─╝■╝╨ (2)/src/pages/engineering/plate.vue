<template>
  <div class="plate" :class="color">
    <div class="padding-top chart">
      <div class="chart_tit">
        <p class="text-center text-sm plan_title">{{title}}</p>
        <!-- <p class="text-center text-xs plan_title plan_title_sub">{{name}}</p> -->
        <p class="text-right margin text-bold">单位：亿</p>
        <!-- <div class="bot_line"></div> -->
        <div class="flex justify-start">
          <div class="index_list">
            <ul>
              <li class="item" v-for="(item,index) in barData" :key="index">
                <span class="index">{{index+1}}</span>
              </li>
            </ul>
          </div>
          <ul class="list">
            <li class="item cont_item flex justify-between text-cut" v-for="(item,index) in barData" :key="index" @click="goDetail(item)">
              <div class="item_cont min_item left">
                <div class="bg" :style="{width:item.width+'%'}"></div>
                <div class="text-cut text">
                  {{item.projectName}}
                </div>
              </div>
              <!-- <div class="item_cont min_item" :style="{width:item.percent+'%'}">{{item.name}}</div> -->
              <div class="percent">{{item.countY}}({{item.percent}}%)</div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
import loading from "../../components/loading";

export default {
  components: { loading },
  data () {
    return {
      loadingShow: true,
      height: 500,
      type: "",
      name: "",
      color: "",
      barData: [
      ]
    };
  },
  created () {

    this.board = this.$route.query.board;
    this.name = this.board == '0' ? '水务及水环境治理' : '' || this.board == '1' ? '产业园及制造业' : '' || this.board == '2' ? '城市综合体' : ''
    let tit = this.$route.query.title.replace("概况", '情况')
    // this.title = this.name + tit;
    this.title = this.$route.query.title;
    console.log(this.title)
    this.type = this.$route.query.type;
    this.data = this.$route.query.data;
    this.color = this.board == '0' ? 'blue' : '' || this.board == '1' ? 'purple' : '' || this.board == '2' ? 'orange' : ''

    let params = { board: this.board, type: this.type }
    this.$api.engineering
      .getBoardList(params)
      .then(res => {
        this.loadingShow = false;
        if (res.state.code === 10000) {
          // res.body = res.body.sort((a, b) => {
          //   if (a.investmentCount) return b.investmentCount - a.investmentCount
          //   if (a.yearInvestmentPlanCount) return b.yearInvestmentPlanCount - a.yearInvestmentPlanCount
          //   if (a.investmentProgressYearCount) return b.investmentProgressYearCount - a.investmentProgressYearCount
          //   if (a.investmentProgressCount) return b.investmentProgressCount - a.investmentProgressCount
          // });
          
          let mother;
          if(this.title =='板块总投资概况' || this.title =='板块年度计划投资概况'){
            res.body = res.body.sort((a, b) => {
              if (a.investmentCount) return b.investmentCount - a.investmentCount;
              if (a.yearInvestmentPlanCount) return b.yearInvestmentPlanCount - a.yearInvestmentPlanCount;
            });
            mother = res.body[0].investmentCount || res.body[0].yearInvestmentPlanCount;
          }
          res.body.map(item => {
            item.count = item.investmentCount || item.yearInvestmentPlanCount;
            if(this.title =='板块年度完成投资概况' || this.title =='板块累计完成投资概况'){
              item.count = item.investmentProgressYearCount || item.investmentProgressCount;
              this.data = item.yearInvestmentPlanCount || item.investmentCount;
            }
            item.countY = (item.count / 10000).toFixed(2);
            item.percent = ((parseInt(item.count) / parseInt(this.data)).toFixed(2) * 100).toFixed(0);
            item.percent = item.percent=='NaN'? 0:item.percent;
            item.width = (this.title =='板块总投资概况' || this.title =='板块年度计划投资概况')?((parseInt(item.count) / mother).toFixed(2) * 100):item.percent;     
            item.width = item.width=='NaN'? 0:item.width;
          })
          if(this.title =='板块年度完成投资概况' || this.title =='板块累计完成投资概况'){
            res.body = res.body.sort((a, b) => {
              if (a.investmentProgressYearCount || a.investmentProgressCount) return b.percent - a.percent;
            });
          }
          console.log(res.body)
          
          // if(this.title =='板块年度完成投资概况' || this.title =='板块累计完成投资概况'){
          //   // console.log(2222)
          //   let mother = res.body[0].investmentProgressYearCount || res.body[0].investmentProgressCount;
          //   // console.log(mother)
          // }

          // res.body.map(item => {
          //   item.width = (parseInt(item.count) / mother).toFixed(2) * 100;
          // })
          this.barData = res.body;


        }


      }).catch(() => {
        // console.log('接口请求失败')
        this.loadingShow = false;
      });
  },
  mounted () {
    this.drawBar();
  },
  methods: {
    drawBar () { },
    // 跳转到详情页面
    goDetail (item) {
      this.$router.push({
        name: "projectDetail",
        query: {
          id: item.id,
          projectName: item.projectName
        }
      });
    },
  }
};
</script>
<style lang="scss" scoped>
.purple {
  .index {
    color: #a578ff !important;
  }
  .bg {
    background: #d39aed !important;
  }
  // .cont_item {
  //   background: #dea3fa !important;
  // }
  // .item_cont {
  //   background: #a578ff !important;
  // }
  .plan_title {
    &::before {
      background: #a578ff !important;
    }
    &::after {
      background: #a578ff !important;
    }
  }
}

.orange {
  .index {
    color: #f2810b !important;
  }
  .bg {
    background: #f2810b !important;
  }

  // .cont_item {
  //   background: #f9bca3 !important;
  // }
  // .item_cont {
  //   background: #f2810b !important;
  // }
  .plan_title {
    &::before {
      background: #f2810b !important;
    }
    &::after {
      background: #f2810b !important;
    }
  }
}
.plate {
  background: #fff;
  padding: 40px 20px 50px 10px;
  .cont_item {
    // background: #82c9f8;
    font-size: 34px;
    color: #000;
    font-weight: 600;
    overflow: hidden;
  }
  .item {
    position: relative;
    line-height: 64px;
    height: 64px;
    font-size: 34px;
    margin-top: 20px;
    .index {
      font-size: 26px;
      color: #0da5eb;
      position: relative;
      top: 2px;
    }
  }
  .item_cont {
    white-space: nowrap;
  }
  .index_list {
    padding-top: 10px;
    min-width: 5%;
    text-align: right;
  }
  .list {
    border-left: 1px solid #737373;
    border-bottom: 1px solid #737373;
    padding: 10px 20px 20px 10px;
    margin-left: 10px;
    min-width: 95%;
    .left {
      position: relative;
      width: 88%;
      .text {
        position: absolute;
        left: 0;
        width: 100%;
      }
      .bg {
        position: absolute;
        left: 0;
        height: 100%;
        background: #1aadff;
      }
    }
    .percent {
      font-size: 26px;
      width: 35%;
      text-align: right;
    }
  }

  .plan_title {
    font-size: 36px;
    position: relative;
    line-height: 50px;
    color: #000;
    text-align: center;
    font-weight: 600;

    &::before {
      content: '';
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-right: 15px;
      position: relative;
      top: -4px;
    }

    &::after {
      content: '';
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-left: 15px;
      position: relative;
      top: -4px;
    }
  }
  .plan_title_sub {
    font-size: 30px;
    &::before {
      content: '';
      width: 16px;
      height: 5px;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-right: 15px;
      position: relative;
      top: -4px;
    }

    &::after {
      content: '';
      width: 16px;
      height: 5px;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-left: 15px;
      position: relative;
      top: -4px;
    }
  }
}
</style>