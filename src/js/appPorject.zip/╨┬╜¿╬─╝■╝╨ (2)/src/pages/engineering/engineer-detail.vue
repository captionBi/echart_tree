<template>
  <div class="engineer_detail">
    <!-- 基本信息 -->
    <div class="detail_module detail_module_pbottom">
      <div class="title">
        <span class="tag"></span>
        <p class="detail_title">基本信息</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">项目名称</p>
        <p class="item_cont">{{detail.basicInfo.projectName}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">所处阶段</p>
        <p class="item_cont">{{detail.basicInfo.projectPeriod | projectPeriod}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">负责人</p>
        <p class="item_cont">{{detail.basicInfo.projectManager}}</p>
      </div>
      <div class="detail_module_item total_detail">
        <p class="item_title width total_detail_left">项目概况</p>
        <p class="item_cont detail_font total_detail_right" v-html="detail.basicInfo.projectSummary">{{detail.basicInfo.projectSummary}}</p>
      </div>
      <div class="detail_module_item total_detail border_none">
        <p class="item_title width total_detail_left">项目计划</p>
        <p class="item_cont detail_font total_detail_right" v-html="detail.basicInfo.projectPlan">{{detail.basicInfo.projectPlan}}</p>
        <!-- <p class="item_cont detail_font">珠江新城项目工期调整已于2019年1月16日获集团批准，具体情况如下： 1、里程碑节点计划：⑴
                    2019年2月28日大塔楼筏板基础施工，6月21日大塔楼（原B区）核心筒施工至正负零，7月20日大塔楼施工许可证办理，9月8小塔楼结构施工至封顶； ⑵
                    2020年4月19日小塔楼外装饰施工，7月；</p> -->
      </div>
    </div>
    <!-- 投资情况 -->
    <div class="detail_module module_bottom">
      <div class="title">
        <span class="tag"></span>
        <p class="detail_title">投资情况(万元)</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">总投资</p>
        <p class="item_cont">{{detail.investmentPlan.totalInvestment | currency}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">本年度计划投资额</p>
        <p class="item_cont">{{detail.investmentPlan.InvestmentPlanYear | currency}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">本年度计划累计投资额</p>
        <p class="item_cont">{{detail.investmentPlan.InvestmentPlanCount | currency}}</p>
      </div>
    </div>
    <!-- 投资进度情况 -->
    <div class="detail_module module_bottom">
      <div class="title">
        <span class="tag"></span>
        <p class="detail_title">投资进度情况(万元)</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">当月完成额</p>
        <p class="item_cont">{{detail.investmentProgress.finishCountMonth | currency}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">本年度累计完成</p>
        <p class="item_cont">{{detail.investmentProgress.finishCountYear | currency}}</p>
      </div>
      <div class="detail_module_item flex justify-between">
        <p class="item_title">累计完成投资</p>
        <p class="item_cont">{{detail.investmentProgress.totalFinishCount | currency}}</p>
      </div>
    </div>
    <!-- 跳转按钮 -->
    <!-- <p class="btn">点击条转云文档</p> -->
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
  import loading from "../../components/loading"
  export default {
    name: "engineerDetail",
    components: {
      loading
    },
    data() {
      return {
        id: '',
        detail: {},
        loadingShow: true
      }
    },
    created() {
      this.id = this.$route.query.id
      this.getProjectDetail()
    },
    methods: {
      // 处理文本换行
      // formatterText(text) {
      //   let reg = /[*]/g;
      //   text = text.replace(reg, "<br>");
      // },
      // 工程详情内容
      getProjectDetail() {
        this.loadingShow = true
        this.$api.engineering.getEngineeringDetail({
          id: this.id
        }).then(res => {
          this.loadingShow = false
          if (res.state.code === 10000) {
            let reg=/[*]/g
            res.body.basicInfo.projectSummary = res.body.basicInfo.projectSummary.replace(reg, "<br>")
            res.body.basicInfo.projectPlan = res.body.basicInfo.projectPlan.replace(reg, "<br>")
            this.detail = res.body
          }
        })
      }

    }
  }
</script>
<style lang="scss" scoped>
  @import './css/engineerDetail/engineerDetail.scss';
</style>