<template>
    <div class="container">
        <div class="project">
            <van-tabs @click="tabClick" color="#0076F0" v-model="active" swipeable>
                <van-tab title="基本信息">
                    <baseInfo></baseInfo>
                </van-tab>
                <van-tab title="投资情况">
                    <investment></investment>
                </van-tab>
                <van-tab title="形象进度">
                    <graphic></graphic>
                </van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
    import {
        Search,
        Tab,
        Tabs,
        Toast
    } from 'vant';
    import baseInfo from './tabs/baseInfo';
    import investment from './tabs/investment';
    import graphic from './tabs/graphic';
    export default {
        components: {
            [Search.name]: Search,
            [Tab.name]: Tab,
            [Tabs.name]: Tabs,
            [Toast.name]: Toast,
            baseInfo: baseInfo,
            investment: investment,
            graphic: graphic,
        },
        data() {
            return {
                active: 0,
            }
        },
        methods: {
            tabClick() {

            }
        }
    }
</script>

<style scoped lang="scss">
    .project {
        /deep/.van-tabs {
            position: unset;
            .van-tab{
                font-size: 18px;
                color: rgba(0,0,0,0.7);
            }
            .van-tab.van-tab--active{
                color: #000;
            }
            .van-tabs__content {
                padding: 15px 10px;
            }
            .van-tabs__wrap {
                padding-top: 6px;
                background: #fff;
                height: 50px;
            }
        }
        .content {
            background: #fff;
            border-radius: 6px;
            padding: 15px;
            overflow: hidden;
        }
    }
</style>