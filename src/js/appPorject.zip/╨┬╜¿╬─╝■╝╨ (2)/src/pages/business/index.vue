<template>
  <div class="bigDivs">
    <div class="topdata">
      <div>实时客流蜂巢热力图</div>
      <div>{{ timeValue }}</div>
    </div>
    <div class="picovers">
      <div class="onetis">
        <div>
          <img src="../../assets/img/goright.png" alt="" />
        </div>
        <div>
          <div>实时流入</div>
          <div>{{ topData.realTimeIn }}</div>
        </div>
      </div>
      <div class="onetis">
        <div>
          <img src="../../assets/img/goleft.png" alt="" />
        </div>
        <div>
          <div>实时流出</div>
          <div>{{ topData.realTimeOut }}</div>
        </div>
      </div>
      <div class="onetis">
        <div>
          <img src="../../assets/img/peoples.png" alt="" />
        </div>
        <div>
          <div>实时人数</div>
          <div>{{ topData.realTimeCount }}</div>
        </div>
      </div>
      <div class="onetis">
        <div>
          <img src="../../assets/img/gotop.png" alt="" />
        </div>
        <div>
          <div>实时增长</div>
          <div>{{ topData.addPercent }}</div>
        </div>
      </div>
    </div>
    <div class="earedivs">
      <div class="areafont">区域地图</div>
      <div class="reslat">
        <div class="areatop">
          <div>TOP区域</div>
          <div>
            <div>人数</div>
            <div><img src="../../assets/img/close.png" alt="" /></div>
          </div>
        </div>
        <div class="areacontent">
          <div>1,广州天河城主场</div>
          <div>{{ topData.realTimeCount }}</div>
        </div>
      </div>
    </div>
    <div>
      <numberchart
        :peopleList="peopleList"
        :timeData="timeData"
        ids="peopleChart"
      ></numberchart>
    </div>
    <div class="clickDiv">
      <div @click="changeNum(1)" :class="clickNum === 1 ? 'tabdiv' : ''">
        历史趋势
      </div>
      <div @click="changeNum(2)" :class="clickNum === 2 ? 'tabdiv' : ''">
        实时数据
      </div>
      <div @click="changeNum(3)" :class="clickNum === 3 ? 'tabdiv' : ''">
        全天数据
      </div>
    </div>
    <div class="tabdivx" v-show="clickNum === 1">
      <onelinecpm
        :onelineName="monthName"
        :onelineList="monthList"
        fonts="月"
        :rotate="38"
        ids="monthChart"
      ></onelinecpm>
      <!-- <onelinecpm
        :onelineName="weekName"
        :onelineList="weekList"
        fonts="周"
        :rotate="38"
        ids="weeksChart"
      ></onelinecpm> -->
      <onelinecpm
        :onelineName="daysName"
        :onelineList="daysList"
        fonts="日"
        :rotate="38"
        ids="daysChart"
      ></onelinecpm>
    </div>
    <div class="tabdivx" v-show="clickNum === 2">
      <histogramcom
        :xList="xStopList"
        :hisList="hisList"
        :areaList="tisData"
        ids="histogramChart"
        fonts="实时驻留"
      ></histogramcom>
      <piecom
        :dataList="timeSouse"
        :picName="timeNameSouse"
        ids="timeChart"
        fonts="实时来源"
      ></piecom>
      <provincial
        :list="resourceOfProvince"
        :name="'省国际来源'"
        :urlpic="zgdtpic"
      ></provincial>
      <provincial
        :list="resourceOfCity"
        :name="'市国际来源'"
        :urlpic="gzpic"
      ></provincial>
      <morelinecom
        :xList="inTimeXlist"
        :areaList="inTimeName"
        :morelineList="inTimeList"
        ids="timeinChart"
        fonts="实时流入"
      ></morelinecom>
      <morelinecom
        :xList="outTimeXlist"
        :areaList="outTimeName"
        :morelineList="outTimeList"
        fonts="实时流出"
        ids="timeoutChart"
      ></morelinecom>
      <sexcom :sexObj="sexObj"></sexcom>
      <piecom
        :dataList="dataList"
        ids="yearChart"
        fonts="年龄"
        :picName="dataName"
      ></piecom>
      <piecom
        :dataList="jobList"
        ids="jobChart"
        fonts="职业"
        :picName="jobName"
        :showLabel="true"
      ></piecom>
    </div>
    <div class="tabdivx" v-show="clickNum === 3">
      <histogramcom
        :xList="stopXListHistory"
        :hisList="stopHistoryList"
        :areaList="stopHistoryName"
        ids="allDayresidesChart"
        fonts="历史驻留"
      ></histogramcom>
      <piecom
        :dataList="allSouse"
        :picName="allNameSouse"
        ids="allDayChart"
        fonts="全日来源"
      ></piecom>
      <provincial
        :list="allDayresourceProvince"
        :name="'省国际来源'"
        :urlpic="zgdtpic"
      ></provincial>
      <provincial
        :list="allDayresourceCity"
        :name="'市国际来源'"
        :urlpic="gzpic"
      ></provincial>
      <populationcom
        :populationList="populationList"
        ids="populatinChart"
        :yAxis="allYAxisList"
        fonts="全天人数"
      ></populationcom>
      <morelinecom
        :xList="oneTimeXlist"
        :areaList="oneTimeName"
        :morelineList="oneTimeList"
        ids="oneTimeChart"
        fonts="一小时新增"
      ></morelinecom>
      <sexcom :sexObj="AllDaysexObj"></sexcom>
      <piecom
        :dataList="AllDaydataList"
        ids="AlldayyearChart"
        fonts="年龄"
        :picName="AllDaydataName"
      ></piecom>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import piecom from "../../components/piecom";
import histogramcom from "../../components/histogramcom";
import onelinecpm from "../../components/onelinecpm";
import morelinecom from "../../components/morelinecom";
import populationcom from "../../components/populationcom";
import numberchart from "../../components/numberchart";
import sexcom from "../../components/sexcom";
import provincial from "../../components/provincial";
import lonelyhis from "../../components/lonelyhis";
import loading from "../../components/loading";
import gzpic from "../../assets/img/gz.gif";
import zgdtpic from "../../assets/img/zgdt.gif";

Date.prototype.Format = function (fmt) {
  // author: meizz
  var o = {
    "M+": this.getMonth() + 1, // 月份
    "d+": this.getDate(), // 日
    "h+": this.getHours(), // 小时
    "m+": this.getMinutes(), // 分
    "s+": this.getSeconds(), // 秒
    "q+": Math.floor((this.getMonth() + 3) / 3), // 季度
    S: this.getMilliseconds(), // 毫秒
  };
  if (/(y+)/.test(fmt))
    fmt = fmt.replace(
      RegExp.$1,
      (this.getFullYear() + "").substr(4 - RegExp.$1.length)
    );
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt))
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length)
      );
  return fmt;
};

export default {
  name: "business",
  components: {
    piecom,
    histogramcom,
    onelinecpm,
    morelinecom,
    populationcom,
    numberchart,
    sexcom,
    provincial,
    lonelyhis,
    loading,
  },
  data() {
    return {
      gzpic,
      zgdtpic,
      timeValue: "",
      dataList: [],
      dataName: [],
      jobList: [],
      jobName: [],
      hisList: [],
      onelineList: [],
      morelineList: [],
      populationList: [],
      peopleList: [],
      clickNum: 1,
      proList: [],
      sexObj: {},
      onelydataList: [],
      timeData: [],
      topData: {},
      timeSouse: [],
      timeNameSouse: [],
      resourceOfProvince: [],
      resourceOfCity: [],
      xStopList: [],
      tisData: [],
      outTimeList: [],
      outTimeName: [],
      outTimeXlist: [],
      inTimeList: [],
      inTimeName: [],
      inTimeXlist: [],
      stopHistoryList: [],
      stopHistoryName: [],
      stopXListHistory: [],
      allSouse: [],
      allNameSouse: [],
      allDayresourceProvince: [],
      allDayresourceCity: [],
      allYAxisList: [],
      loadingShow: true,
      oneTimeXlist: [],
      oneTimeName: [],
      oneTimeList: [],
      AllDaysexObj: {},
      AllDaydataList: [],
      AllDaydataName: [],
      monthList: [],
      monthName: [],
      weekList: [],
      weekName: [],
      daysList: [],
      daysName: [],
    };
  },
  mounted() {
    this.loadingShow = true;
    this.$api.business.hasRealTimeData().then((data, index) => {
      this.topData = data.body;
      this.loadingShow = false;
    });
    this.$api.business.hasgetStreamPeople().then((data, index) => {
      this.peopleList = [
        {
          data: data.body.dataList.countList,
          type: "line",
          showSymbol: false,
          areaStyle: {},
        },
      ];
      this.loadingShow = false;
      this.timeData = data.body.dataList.times;
    });
    this.changeNum(1);
    setInterval(() => {
      this.timeValue = new Date().Format("yyyy-MM-dd hh:mm:ss");
    }, 1000);
    // this.onelineList = [820, 932, 901, 934, 1290, 1330, 1320];

    // this.onelydataList = [120, 200, 150, 80, 70, 110, 130];
  },
  methods: {
    changeNum(e) {
      if (e === 1) {
        this.loadingShow = true;
        this.$api.business.hasDataByMonth().then((res, index) => {
          this.monthList = res.body.values;
          this.monthName = res.body.months;
          this.loadingShow = false;
        });
        // this.$api.business.hasDataByWeek().then((res, index) => {
        //   this.weekList = res.body.values;
        //   this.weekName = res.body.weeks;
        // });
        this.$api.business.hasDDataByDay().then((res, index) => {
          this.daysList = res.body.values;
          this.daysName = res.body.days;
        });
      }
      if (e === 2) {
        this.loadingShow = true;
        this.$api.business.hasInputStream().then((data, index) => {
          let areaAbs = data.body.dataList.map((item, index) => {
            return {
              name: item.areaName,
              type: "line",
              stack: "line",
              showSymbol: false,
              data: item.countList,
            };
          });
          this.inTimeList = areaAbs;
          this.inTimeName = data.body.nameList;
          this.inTimeXlist = data.body.xList;
        });
        this.$api.business.hasOutputStream().then((data, index) => {
          let areaAbs = data.body.dataList.map((item, index) => {
            return {
              name: item.areaName,
              type: "line",
              stack: "line",
              showSymbol: false,
              data: item.countList,
            };
          });
          this.outTimeList = areaAbs;
          this.outTimeName = data.body.nameList;
          this.outTimeXlist = data.body.xList;
        });
        this.$api.business.hasgetAttributeData().then((data, index) => {
          let newAgeName = [];
          data.body.ageObject.dataList.map((item, index) => {
            newAgeName.push(item.name);
          });
          this.jobList = data.body.occupationObject.dataList;
          this.jobName = data.body.occupationObject.nameList;
          this.dataList = data.body.ageObject.dataList;
          this.dataName = newAgeName;
          this.sexObj = data.body.sexObject;
        });
        this.$api.business.hasgetRealTimeInfo().then((data, index) => {
          this.resourceOfProvince = data.body.resourceOfProvince.dataList;
          this.resourceOfCity = data.body.resourceOfCity.dataList;
          this.timeSouse = data.body.realTimeResource.dataList;
          this.timeNameSouse = data.body.realTimeResource.nameList;
          let newsareaArry = data.body.realTimeDwell.areaList;
          this.tisData = newsareaArry;
          let newareaList = data.body.realTimeDwell.dataList.map(
            (item, index) => {
              return {
                name: newsareaArry[index],
                type: "bar",
                stack: "time",
                barWidth: 20,
                data: item.data,
              };
            }
          );
          this.loadingShow = false;
          this.hisList = newareaList;
          this.xStopList = data.body.realTimeDwell.xList;
        });
      }
      if (e === 3) {
        this.loadingShow = true;
        this.$api.business.hasAllDayCount().then((res, index) => {
          this.populationList = res.body.allDayCount.valueList;
          this.allYAxisList = res.body.allDayCount.yList;
        });
        this.$api.business.hasAddByHour().then((data, index) => {
          let areaAbs = data.body.dataList.map((item, index) => {
            return {
              name: item.areaName,
              type: "line",
              stack: "line",
              showSymbol: false,
              data: item.countList,
            };
          });
          this.loadingShow = false;
          this.oneTimeList = areaAbs;
          this.oneTimeName = data.body.nameList;
          this.oneTimeXlist = data.body.xList;
        });
        this.$api.business.hasPassAnalysis().then((data, index) => {
          console.log("ssssssss", data.body);
          this.allSouse = data.body.resourceOfDay.dataList;
          this.allNameSouse = data.body.resourceOfDay.nameList;
          this.allDayresourceProvince = data.body.resourceOfProvince.dataList;
          this.allDayresourceCity = data.body.resourceOfCity.dataList;

          let newsareaArry = data.body.historyDwell.areaList;
          this.stopHistoryName = newsareaArry;
          let newareaList = data.body.historyDwell.dataList.map(
            (item, index) => {
              return {
                name: newsareaArry[index],
                type: "bar",
                stack: "time",
                barWidth: 20,
                data: item.data,
              };
            }
          );
          this.stopHistoryList = newareaList;
          this.stopXListHistory = data.body.historyDwell.xList;
        });
        this.$api.business.hasAgeAndSex().then((data, index) => {
          let newAgeName = [];
          data.body.ageData.dataList.map((item, index) => {
            newAgeName.push(item.name);
          });
          this.AllDaydataList = data.body.ageData.dataList;
          this.AllDaydataName = newAgeName;
          this.AllDaysexObj = data.body.sexData;
        });
      }
      this.clickNum = e;
    },
  },
};
</script>

<style scoped lang="scss">
.bigDivs {
  background: url("../../assets/img/bg.jpg") repeat;
  padding-bottom: 20px;
}
.topdata {
  height: 150px;
  background: url("../../assets/img/topshow.png") no-repeat;
  background-size: cover;
  text-align: center;
  padding-top: 10px;
  & > div:nth-child(1) {
    font-size: 42px;
    margin-top: 20px;
    color: white;
    position: relative;
    left: 24px;
  }
  & > div:nth-child(2) {
    font-size: 30px;
    margin-top: 16px;
    color: #0ccee7;
    position: relative;
    left: 24px;
  }
}
.picovers {
  display: flex;
  flex-wrap: wrap;
  & > div {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-left: 3%;
    margin-top: 20px;
  }
  & > div:nth-child(2),
  & > div:nth-child(4) {
    margin-left: 4%;
  }
  .onetis {
    width: 45%;
    height: 190px;
    background: url("../../assets/img/tonspic.png") no-repeat center center;
    background-size: 100% 100%;
    & > div:nth-child(1) {
      margin-top: 20px;
      img {
        width: 100px;
        height: 100px;
      }
    }
    & > div:nth-child(2) {
      margin-top: 20px;
      color: #647786;
      font-size: 32px;
      margin-left: 20px;
      & > div:nth-child(2) {
        margin-top: 20px;
      }
    }
  }
}
.earedivs {
  width: 94%;
  margin: 40px auto;
  padding-top: 36px;
  background: url("../../assets/img/areapic.png") no-repeat;
  background-size: 100% 100%;
  height: 706px;
  position: relative;
  .areafont {
    width: 100%;
    text-align: center;
    position: absolute;
    top: 20px;
    color: white;
    font-size: 32px;
  }
  .reslat {
    position: absolute;
    right: 4%;
    bottom: 60px;
    height: 300px;
    width: 80%;
    border: 1px solid #156386;
    background: rgba(0, 52, 85, 0.4);
    .areatop {
      background: rgba(0, 88, 144, 0.8);
      display: flex;
      color: white;
      font-size: 28px;
      height: 60px;
      line-height: 60px;
      text-indent: 40px;
      & > div:nth-child(1) {
        flex: 1;
      }
      & > div:nth-child(2) {
        width: 160px;
        display: flex;
        position: relative;
        img {
          width: 30px;
          height: 30px;
          position: absolute;
          right: 10px;
          top: 10px;
        }
      }
    }
    .areacontent {
      display: flex;
      color: white;
      height: 60px;
      line-height: 60px;
      text-indent: 40px;
      font-size: 28px;
      & > div:nth-child(1) {
        flex: 1;
      }
      & > div:nth-child(2) {
        width: 160px;
      }
    }
  }
}
.clickDiv {
  display: flex;
  margin: 3%;
  & > div {
    flex: 1;
    font-size: 32px;
    height: 120px;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
.tabdiv {
  background: url("../../assets/img/tab.png") no-repeat;
  background-size: cover;
}
.tabdivx {
  & > div {
    margin-bottom: 20px;
  }
}
</style>
