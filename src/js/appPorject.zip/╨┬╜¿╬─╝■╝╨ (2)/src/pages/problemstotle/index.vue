<template>
  <div class="problempage">
    <div class="allcontent">
      <div class="problemNum">
        <div>总问题数量</div>
        <div>{{ countList.wtTotalCount }}</div>
        <div>(个)</div>
      </div>
      <div class="numList">
        <div>
          <div>
            {{ countList.yzgTotalCount }}<span>个</span>
            <div class="kongdiv" style="background: #499aed"></div>
          </div>
          <div>已整改</div>
        </div>
        <div>
          <div>
            {{ countList.zgzTotalCount }}<span>个</span>
            <div class="kongdiv" style="background: #48ba97"></div>
          </div>
          <div>整改中</div>
        </div>
        <div>
          <div>
            {{ countList.wzgTotalCount }}<span>个</span>
            <div class="kongdiv" style="background: #fca52d"></div>
          </div>
          <div>未整改</div>
        </div>
        <div>
          <div>
            {{ countList.wfzgTotalCount }}<span>个</span>
            <div class="kongdiv" style="background: #f3705a"></div>
          </div>
          <div>无法整改</div>
        </div>
      </div>
      <div class="posiDiv">
        <div class="protis">
          <img @click="showtisClick" src="../../assets/img/doubt.png" alt="" />
        </div>
        <div class="picDiv">
          <div id="myChart" style="height: 260px; width: 100%"></div>
        </div>
        <div class="clickClss">
          <div>
            <div @click="typeClick(1)" :class="types === 1 ? 'tranClass' : ''">
              完 成 率
            </div>
            <div @click="typeClick(2)" :class="types === 2 ? 'tranClass' : ''">
              问 题 数
            </div>
            <div @click="typeClick(3)" :class="types === 3 ? 'tranClass' : ''">
              未 整 改
            </div>
          </div>
        </div>
        <div class="bottomDiv" v-show="types === 1">
          <div
            class="oneData"
            @click="goDetail(item.unitId)"
            v-for="(item, index) in yzgList"
            :key="index"
          >
            <div class="fontdiv">
              <div>{{ index + 1 }}. {{ item.unitName }}</div>
              <div>{{ item.yzg }}({{ item.zgwcl }})</div>
            </div>
            <div class="linediv">
              <div :style="{ width: item.zgwcl }"></div>
            </div>
          </div>
        </div>
        <div class="bottomDiv" v-show="types === 2">
          <div
            class="oneData"
            @click="goDetail(item.unitId)"
            v-for="(item, index) in wtsList"
            :key="index"
          >
            <div class="fontdiv">
              <div>{{ index + 1 }}. {{ item.unitName }}</div>
              <div style="color: #eba434">
                {{ item.wts }}({{
                  Number(
                    ((item.wts / countList.wtTotalCount) * 100).toFixed(1)
                  )
                }}%)
              </div>
            </div>
            <div class="linediv">
              <div
                :style="{
                  width:
                    Number(
                      ((item.wts / countList.wtTotalCount) * 100).toFixed(1)
                    ) + '%',
                  backgroundImage:
                    'linear-gradient(to right, #ffd07b, #fbc43e)',
                }"
              ></div>
            </div>
          </div>
        </div>
        <div class="bottomDiv" v-show="types === 3">
          <div
            class="oneData"
            @click="goDetail(item.unitId)"
            v-for="(item, index) in wzgList"
            :key="index"
          >
            <div class="fontdiv">
              <div>{{ index + 1 }}. {{ item.unitName }}</div>
              <div style="color: #49bcb0">{{ item.wzg }}({{ item.wzgbl }})</div>
            </div>
            <div class="linediv">
              <div
                :style="{
                  width: item.wzgbl,
                  backgroundImage:
                    'linear-gradient(to right, #53d3c1, #49bcb0)',
                }"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <transition name="enterprise">
      <!-- 全屏遮罩 -->
      <div class="enterprisedetail" v-show="showDataBox" @click="shadehandler">
        <!-- 主体内容盒子 -->
        <div class="enterprisecontent">
          <div class="title">
            <img src="../../assets/img/problem.png" alt="" />
            <span>问题详情</span>
          </div>
          <div class="contents">
            <div
              class="bigOne"
              v-for="(item, index) in detailDataList"
              :key="index"
            >
              <div class="sonOne">
                <div></div>
                <div>{{ index + 1 }}. {{ item.trackName }}</div>
              </div>
              <div class="sonTwo">
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>报告时间:</div>
                  <div>{{ item.reportTime }}</div>
                </div>
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>整改完成率:</div>
                  <div>{{ item.zgwcl }}</div>
                </div>
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>问题数:</div>
                  <div>{{ item.wts }}</div>
                </div>
              </div>
              <div class="sonThree">
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>已整改:</div>
                  <div>{{ item.yzg }}</div>
                </div>
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>未整改:</div>
                  <div>{{ item.wzg }}</div>
                </div>
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>整改中:</div>
                  <div>{{ item.zgz }}</div>
                </div>
                <div class="onlyOne">
                  <div class="dianDiv"></div>
                  <div>无法整改:</div>
                  <div>{{ item.wfzg }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
    <div v-if="showTis" class="tisBox">
      <div class="okBox">
        <img class="bgs" src="../../assets/img/bgs.png" alt="" />
        <img
          @click="showTis = false"
          class="close"
          src="../../assets/img/close.png"
          alt=""
        />
        <div class="tisclass">
          <div @click="sonStyle(1)" :class="sonTs === 1 ? 'colorchange' : ''">
            完成率
          </div>
          <div @click="sonStyle(2)" :class="sonTs === 2 ? 'colorchange' : ''">
            问题数
          </div>
          <div @click="sonStyle(3)" :class="sonTs === 3 ? 'colorchange' : ''">
            未整改
          </div>
        </div>
        <div class="cons" v-show="sonTs === 1">
          <div>数据及公式说明:</div>
          <div class="sontis">数量：已整改的问题数量；</div>
          <div class="sontis">%：数量/公司问题数量；</div>
        </div>
        <div class="cons" v-show="sonTs === 2">
          <div>数据及公式说明:</div>
          <div class="sontis">数量：公司问题总数；</div>
          <div class="sontis">%：数量/所有公司问题汇总数；</div>
        </div>
        <div class="cons" v-show="sonTs === 3">
          <div>数据及公式说明:</div>
          <div class="sontis">数量：未整改的问题数量；</div>
          <div class="sontis">%：数量/公司问题数量</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import {
//     Search,
//     Tab,
//     Tabs,
//     Toast
// } from 'vant';
export default {
  components: {},
  data() {
    return {
      types: 1,
      showTis: false,
      showDataBox: false,
      problemData: [
        {
          name: "小欧",
          sex: "男",
          age: "21",
          effdt: "沙发",
          positionDesc: "安抚",
          jobDesc: "水电费",
        },
      ],
      countList: [],
      wzgList: [],
      wtsList: [],
      yzgList: [],
      detailDataList: [],
      sonTs: 1,
      currName: "",
      dataSetArr: [],
    };
  },
  mounted() {
    document.title = "审计统计";
    this.$api.problemstotle.hasGetIndexInfo().then((data, index) => {
      console.log("ceshi", data);
      this.countList = data.body.count;
      this.dataSetArr = [
        {
          name: "已整改",
          value: data.body.count.yzgTotalCount,
        },
        {
          name: "整改中",
          value: data.body.count.zgzTotalCount,
        },
        {
          name: "未整改",
          value: data.body.count.wzgTotalCount,
        },
        {
          name: "无法整改",
          value: data.body.count.wfzgTotalCount,
        },
      ];
      this.wzgList = data.body.wzgList;
      this.wtsList = data.body.wtsList;
      this.yzgList = data.body.yzgList;
      this.$nextTick(() => {
        this.lineEcher();
      });
    });
  },
  methods: {
    sonStyle(type) {
      this.sonTs = type;
    },
    showtisClick() {
      console.log("aaaaaaaaaa");
      this.showTis = true;
    },
    typeClick(e) {
      this.types = e;
    },
    lineEcher() {
      let colors = this._colors();
      let itemCol = this._itemColor();
      let dataSorce = this._yAxisData();
      let centerData = this._getCenterData();
      let legendData = this._legData();
      let myChart = this.$echarts.init(document.getElementById("myChart"));
      let option = {
        //backgroundColor: "#ccc", //背景颜色
        color: colors,
        tooltip: {
          show: false,
          backgroundColor: "rgba(3,43,80,0.7)",
          textStyle: {
            color: "rgba(255,255,255,0.7)",
            fontSize: 16,
          },
          extraCssText: "text-align:right",
          formatter: function (params, m) {
            let item = `
          <span 
          style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:${
            itemCol[params.dataIndex]
          };"></span>
          `;
            let str = `${item} ${params.name}&nbsp;${params.value}`;
            return str;
          },
        },
        series: [
          {
            name: "",
            type: "pie",
            radius: ["43%", "63%"],
            center: ["50%", "50%"],
            avoidLabelOverlap: true,
            hoverAnimation: false, //鼠标移入变大
            label: {
              // normal: {
              //   show: true,
              // },
              // emphasis: {
              //   show: true,
              // },
              show: true,
              position: "outside",
              formatter: (params) => {
                let nm = params.name;
                let per = Number(params.percent).toFixed(1);
                // return [`{a|${nm}}\n`, `{b|${per}%}`];
                return `{a|${nm}}\n{b|${per}%}`;
              },
              rich: {
                a: {
                  color: "#3c8bfb",
                  fontSize: 12,
                  lineHeight: 20,
                },
                b: {
                  color: "#3c8bfb",
                  fontSize: 12,
                  foneWeight: "bold",
                },
              },
            },
            labelLine: {
              normal: {
                length: 12,
                show: true,
              },
              emphasis: {
                show: true,
              },
            },
            animation: false,
            tooltip: {
              show: true,
            },

            data: dataSorce,
          },
          {
            name: "内框",
            type: "pie",
            hoverAnimation: true,
            radius: ["38%", "38.5%"],
            center: ["50%", "50%"],
            label: {
              normal: {
                show: true,
                position: "center",

                formatter: [
                  `{a|${centerData[0].name}}`,
                  `{b|${centerData[0].value + "%"}}`,
                ].join("\n"),
                rich: {
                  a: {
                    color: "#3c8bfb",
                    fontSize: 18,
                    lineHeight: 30,
                  },
                  b: {
                    color: "#3c8bfb",
                    fontSize: 20,
                    foneWeight: "bold",
                    textShadowBlur: 20,
                    textShadowColor: "#3c8bfb",
                  },
                },
              },
            },
            labelLine: {
              normal: {
                show: false,
              },
            },
            itemStyle: {
              normal: {
                color: "#2bb0eb",
                shadowColor: "#2bb0eb",
                borderWidth: 3,
                borderColor: "rgba(211, 232, 255,0.2)",
                // 	shadowBlur: 2,
                // 	opacity:0.3
              },
            },
            data: [
              {
                value: 100,
                tooltip: {
                  show: false,
                },
              },
            ],
          },
        ],
      };
      myChart.setOption(option);
      myChart.on("mouseover", (params) => {
        this.currName = params.name;
        let op = myChart.getOption();
        if (params.seriesIndex === 0) {
          let _label = {
            normal: {
              show: true,
              position: "center",
              formatter: [
                `{a|${params.name}}`,
                `{b|${params.percent + "%"}}`,
              ].join("\n"),
              rich: {
                a: {
                  color: "#3c8bfb",
                  fontSize: 18,
                  lineHeight: 30,
                },
                b: {
                  color: "#3c8bfb",
                  fontSize: 20,
                  foneWeight: "bold",
                  textShadowBlur: 20,
                  textShadowColor: "#3c8bfb",
                },
              },
            },
          };
          op.series[1].label = _label;
          myChart.setOption(op, true);
        }
      });
    },
    // 点击隐藏弹窗
    shadehandler() {
      this.showDataBox = false;
    },
    goDetail(id) {
      console.log("aaaaaaa", id);
      this.showDataBox = true;
      this.detaliList(id);
    },
    detaliList(id) {
      this.$api.problemstotle.hasGetDetailInfo(id).then((data, index) => {
        console.log("ceshisssssssssssssssssssss", data);
        this.detailDataList = data.body.dataList;
      });
    },
    _legData() {
      let dataArr = [];
      this.dataSetArr &&
        this.dataSetArr.map((item, i) => {
          dataArr.push({
            name: item.name,
            icon: "circle",
            textStyle: { color: "#ccc", fontSize: 12 },
          });
        });
      return dataArr;
    },
    _yAxisData() {
      return this.dataSetArr && this.dataSetArr.map((item) => item);
    },
    _dySum() {
      let dySum = this.countList.wtTotalCount;
      let arr = [];
      this.dataSetArr &&
        this.dataSetArr.map((item) => {
          let val = ((Number(item.value) / dySum) * 100).toFixed(1);
          arr.push({
            name: item.name,
            value: val,
          });
        });
      console.log("aaaaaaaaa", arr);
      return arr;
    },
    _getCenterData() {
      let dtS = this._dySum();

      if (this.currName !== "") {
        return (
          dtS &&
          dtS.filter((item) => {
            return item.name === this.currName;
          })
        );
      } else {
        return [dtS && dtS[0]];
      }
    },
    _axisLine() {
      return {
        lineStyle: {
          color: "#3398DB", //坐标轴线颜色
          width: 2,
        },
      };
    },
    _itemColor() {
      return [
        "#327bfa",
        "#54d4c2",
        "#fdbd80",
        "#f3705a",
        "#e40036",
        "#ffde1d",
        "#f8492c",
        "#1da349",
        "#eb3d7e",
      ];
    },
    _colors() {
      return [
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#327bfa" }, // 1
            { offset: 1, color: "#77a6f8" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#54d4c2" }, //2
            { offset: 1, color: "#48baaf" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#fdbd80" }, //3
            { offset: 1, color: "#f8a04c" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#f3705a" }, //4
            { offset: 1, color: "#b691f9" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#e40036" }, //5
            { offset: 1, color: "#f97695" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#ffde1d" }, //6
            { offset: 1, color: "#fff2a5" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#f8492c" }, //7
            { offset: 1, color: "#fea191" },
          ],
          false
        ),

        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#1da349" }, //8
            { offset: 1, color: "#39d16b" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#eb3d7e" }, //9
            { offset: 1, color: "#fd97bd" },
          ],
          false
        ),
      ];
    },
  },
};
</script>

<style scoped lang="scss">
.problempage {
  height: 100%;
  .allcontent {
    height: 100%;
    width: 96%;
    margin: 0 auto;
    border-radius: 8px;
    background: white;
    padding-top: 20px;
    .problemNum {
      border-radius: 8px;
      border-bottom: 6px solid #fcc62d;
      background: #3c8bfb;
      height: 80px;
      line-height: 80px;
      display: flex;
      color: white;
      & > div:nth-child(1) {
        flex: 1;
        margin-left: 20px;
      }
      & > div:nth-child(2) {
        margin-right: 20px;
      }
      & > div:nth-child(3) {
        margin-right: 40px;
      }
    }
    .numList {
      width: 94%;
      margin: 20px auto;
      & > div {
        display: inline-block;
        & > div:nth-child(1) {
          color: #2f454d;
          font-weight: 600;
          position: relative;
          span {
            font-size: 29px;
          }
          .kongdiv {
            position: absolute;
            right: -30px;
            top: 6px;
            width: 14px;
            height: 30px;
          }
        }
        & > div:nth-child(2) {
          font-size: 22px;
          margin-top: 20px;
        }
      }
      & > div:nth-child(2),
      & > div:nth-child(3),
      & > div:nth-child(4) {
        margin-left: 16%;
      }
    }
    .posiDiv {
      position: relative;
      .protis {
        position: absolute;
        top: 0;
        right: 40px;
        background: white;
        z-index: 9;
        img {
          width: 40px;
          height: 40px;
        }
      }
      .picDiv {
        width: 100%;
      }
      .clickClss {
        width: 100%;
        height: 80px;
        line-height: 80px;
        box-shadow: 0px 10px 50px 0px rgba(0, 0, 0, 0.1);
        & > div {
          display: flex;
          width: 100%;
          height: 80px;
          line-height: 80px;
          position: relative;
          & > div {
            flex: 1;
            text-align: center;
            font-size: 26px;
            position: absolute;
            bottom: 0;
          }
          & > div:nth-child(1) {
            left: 0;
            width: 33%;
          }
          & > div:nth-child(2) {
            left: 33%;
            width: 33%;
          }
          & > div:nth-child(3) {
            left: 66%;
            width: 33%;
          }
        }
      }
      .bottomDiv {
        margin-top: 20px;
        .oneData {
          width: 100%;
          margin-bottom: 10px;
          .fontdiv {
            display: flex;
            & > div:nth-child(1) {
              flex: 1;
            }
            & > div:nth-child(2) {
              color: #3c8bfb;
            }
          }
          .linediv {
            width: 100%;
            height: 30px;
            border-radius: 15px;
            background: #d5e6ff;
            margin-top: 10px;
            position: relative;
            & > div {
              position: absolute;
              top: 0;
              left: 0;
              height: 30px;
              border-radius: 15px;
              background-image: linear-gradient(to right, #6dbefd, #3d8cfb);
            }
          }
        }
      }
    }
  }
}

.enterprisedetail {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 200;
  background-color: rgba(0, 0, 0, 0.6);
  &.enterprise-enter-active,
  &.enterprise-leave-active {
    transition: all 0.4s;
    .enterprisecontent {
      transition: all 0.4s;
    }
  }
  &.enterprise-enter,
  &.enterprise-leave-to {
    opacity: 0;
    .enterprisecontent {
      transform: translate3d(0, 100%, 0);
    }
  }
  .enterprisecontent {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: #fff;
    border-radius: 30px 30px 0 0;
    .title {
      text-align: center;
      font-weight: bold;
      padding: 20px 0;
      display: flex;
      justify-content: center;
      align-items: center;
      border-bottom: 1px dashed #ccc;
      img {
        width: 40px;
        height: 40px;
        margin-right: 10px;
      }
    }
    .contents {
      height: 70vh;
      overflow-y: scroll;
      .bigOne {
        border-bottom: 1px dashed #ccc;
        padding-bottom: 20px;
        .sonOne {
          display: flex;
          align-items: center;
          padding: 0 0 0 30px;
          margin-top: 10px;
          font-size: 24px;
          font-weight: 600;
          & > div:nth-child(1) {
            width: 10px;
            height: 30px;
            background: #4190f6;
          }
          & > div:nth-child(2) {
            flex: 1;
            margin-left: 10px;
          }
        }
        .sonTwo {
          display: flex;
          padding: 0 0 0 30px;
          margin-top: 10px;
          .onlyOne {
            display: flex;
            align-items: center;
            font-size: 22px;
            .dianDiv {
              width: 6px;
              height: 6px;
              background: #3c8bfb;
              border-radius: 50%;
            }
            & > div:nth-child(2) {
              margin-left: 10px;
            }
            & > div:nth-child(3) {
              margin-left: 20px;
            }
          }
          & > div:nth-child(2) {
            flex: 1;
            margin-left: 40px;
            & > div:nth-child(3) {
              color: #3c8bfb;
            }
          }
          & > div:nth-child(3) {
            margin-right: 40px;
            & > div:nth-child(3) {
              color: #fdca84;
            }
          }
        }
        .sonThree {
          display: flex;
          background: #3c8bfb;
          color: white;
          align-items: center;
          padding: 0 0 0 30px;
          font-size: 22px;
          margin-top: 10px;
          .onlyOne {
            display: flex;
            align-items: center;
            .dianDiv {
              width: 6px;
              height: 6px;
              background: white;
              border-radius: 50%;
            }
            & > div:nth-child(2) {
              margin-left: 10px;
            }
            & > div:nth-child(3) {
              margin-left: 10px;
            }
          }
          & > div:nth-child(2) {
            margin-left: 30px;
          }
          & > div:nth-child(3) {
            flex: 1;
            margin-left: 40px;
          }
          & > div:nth-child(4) {
            margin-right: 40px;
          }
        }
      }
    }
  }
}
.tranClass {
  height: 100px;
  line-height: 100px;
  background: #3c8bfb;
  color: #fff;
  border-radius: 8px 8px 0 0;
}
.tisBox {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 200;
  background-color: rgba(0, 0, 0, 0.6);
  .okBox {
    width: 80%;
    margin: 50% auto 0;
    background: white;
    border-radius: 16px;
    height: 500px;
    position: relative;
    padding: 30px 0;
    .bgs {
      width: 90%;
      position: absolute;
      top: -220px;
      left: 5%;
      z-index: -1;
    }
    .close {
      position: absolute;
      top: -200px;
      right: 60px;
      display: inline-block;
      width: 40px;
      height: 40px;
    }
    .tisclass {
      width: 70%;
      margin: 0 auto;
      display: flex;
      border: 1px solid #3d7dff;
      color: #3d7dff;
      height: 60px;
      line-height: 60px;
      & > div {
        flex: 1;
        text-align: center;
      }
      & > div:nth-child(1),
      & > div:nth-child(2) {
        border-right: 1px solid #3d7dff;
      }
    }
    .cons {
      width: 90%;
      margin: 20px auto 0;
      height: 300px;
      background: #f7fbfd;
      border-radius: 16px;
      padding: 20px 30px;
      .sontis {
        text-indent: 30px;
        margin-top: 20px;
      }
    }
  }
}
.colorchange {
  background: #3d7dff;
  color: white;
}
</style>