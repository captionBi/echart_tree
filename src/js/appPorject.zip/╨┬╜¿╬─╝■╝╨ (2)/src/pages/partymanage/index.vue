<template>
  <div class="partymanage">
    <ul class="tab" style="display:none;">
      <li
        class="tabitem"
        :class="{'active':currentindex == item.flag}"
        v-for="(item, index) in tablist"
        :key="index"
        @click="handoverhandler(item.flag)"
      >{{item.text}}</li>
    </ul>
    <component :is="cut"></component>
  </div>
</template>

<script type="text/ecmascript-6">
import Overview from "./tabs/overview";
import Dynamic from "./tabs/dynamic";
import Works from "./tabs/works";
export default {
  name: "partymanage",
  data() {
    return {
      tablist: [
        { text: "党建概况", flag: 1 },
        { text: "党建动态", flag: 2 },
        { text: "创新案例", flag: 3 }
      ],
      cut: Overview,
      currentindex: 1
    };
  },
  methods: {
    handoverhandler(flag) {
      this.currentindex = flag;
      flag == 1
        ? (this.cut = Overview)
        : flag == 2
        ? (this.cut = Dynamic)
        : (this.cut = Works);
    }
  },
  components: { Overview, Dynamic, Works }
};
</script>

<style scoped lang="scss">
.partymanage {
  .tab {
    display: flex;
    height: 105px;
    background: rgba(255, 255, 255, 1);
    .tabitem {
      font-size: 36px;
      font-family: Adobe Heiti Std;
      font-weight: bold;
      color: rgba(1, 1, 1, 1);
      opacity: 0.6;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .active {
      opacity: initial;
      position: relative;
      &.active::before {
        content: "";
        display: inline-block;
        width: 210px;
        height: 10px;
        background: #e71710;
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
  }
}
</style>
