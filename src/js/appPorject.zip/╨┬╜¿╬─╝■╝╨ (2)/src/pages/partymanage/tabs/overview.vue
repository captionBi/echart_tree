<template>
  <div class="overview" :style="{overflowY:scrollcalculate}">
    <!-- 搜索框 -->
    <div class="search">
      <div class="include">
        <input class="searchinput" type="text" placeholder="搜索" v-model="searchvalue" />
        <div class="closed" v-show="searchvalue" @click="closedhandler"></div>
        <!-- <img
          class="searchimg"
          src="@/assets/img/search.png"
          alt
          v-show="!searchvalue"
          @click="resethandler"
        />-->
      </div>
      <div class="voice" @click="voiceFun('open')">
        <img src="@/assets/img/partymanage/voice.png" alt />
        <div class="text">语音</div>
      </div>
    </div>

    <!-- 搜索结果列表 -->
    <div class="result" v-show="searchresponseflag">
      <div class="hinttext" v-show="!searchresultarr.length">搜索不到任何结果</div>
      <ul class="resultlist" v-show="searchresultarr.length">
        <li
          class="item"
          :data-id="item.id"
          v-for="(item, index) in searchresultarr"
          :key="index"
          @click="itemdetail(item)"
        >{{item.fullName}}</li>
      </ul>
    </div>
    <!-- 遮罩层 -->
    <transition name="obstructanimation">
      <div class="obstruct" v-show="searchresponseflag"></div>
    </transition>

    <!-- 党员人数 -->
    <div class="partycount">
      <img class="img" src="@/assets/img/partymanage/member.png" alt />
      <div class="info">
        <div class="title">党员人数</div>
        <div class="number">
          <span class="number">{{partyMemberNum}}</span>
          <span class="unit">名</span>
        </div>
      </div>
    </div>

    <!-- 党务干部 -->
    <div class="partywork">
      <img class="img" src="@/assets/img/partymanage/committee.png" alt />
      <div class="info">
        <div class="title">党务干部</div>
        <div class="number">
          <span class="number">{{partyCadresNum}}</span>
          <span class="unit">名</span>
        </div>
      </div>
      <div class="detail">详细>></div>
    </div>

    <div class="banner">
      <van-swipe
        ref="bannerswipe"
        class="my-swipe"
        :autoplay="8000"
        indicator-color="white"
        :height="460"
        @change="banneronChange"
      >
        <!-- <van-swipe-item>
          echart饼图  党员占员工数比
          <div class="chart" id="percentage">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">党员占员工数比</p>
              <div class="bot_line"></div>
              <div class="chartbutton">
                <div class="leftbutton"></div>
                <div class="rightbutton"></div>
              </div>
            </div>
            <div id="myChart_percentage" :style="{height: height+'px'}"></div>
          </div>
        </van-swipe-item>-->
        <!-- <van-swipe-item>
          echart柱状图  年度发展党员计划
          <div class="chart" id="plan">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">年度发展党员计划</p>
              <div class="bot_line">
                <div class="yeartext" @click="showpopupflag('1')">2020</div>
              </div>
              <div class="chartbutton">
                <div class="leftbutton"></div>
                <div class="rightbutton"></div>
              </div>
            </div>
            <div id="myChart_plan" :style="{height: barheight+'px'}"></div>
            <ul class="planlist" style="height:130px;">
              <li class="item">计划发展</li>
              <li class="item">已经发展</li>
            </ul>
            <p class="text-explain">完成比例 65%</p>
          </div>
        </van-swipe-item>-->
        <van-swipe-item>
          <!-- echart柱状图  党员活动次数统计 -->
          <div class="chart" id="activity">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">党员活动次数统计</p>
              <div class="bot_line">
                <div class="yeartext" @click="showpopupflag('2')">{{activityyear}}</div>
              </div>
              <div class="chartbutton">
                <div class="leftbutton" @click="prevhandler"></div>
                <div class="rightbutton" @click="nexthandler"></div>
              </div>
            </div>
            <div id="myChart_activity" :style="{height: barheight+'px'}"></div>
          </div>
        </van-swipe-item>
        <van-swipe-item>
          <!-- echart饼图  党员年龄结构 -->
          <div class="chart" id="age">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">党员年龄结构</p>
              <div class="bot_line"></div>
              <div class="chartbutton">
                <div class="leftbutton" @click="prevhandler"></div>
                <div class="rightbutton" @click="nexthandler"></div>
              </div>
            </div>
            <div id="myChart_age" :style="{height: height+'px'}"></div>
          </div>
        </van-swipe-item>
        <van-swipe-item>
          <!-- echart饼图  党龄结构 -->
          <div class="chart" id="partystanding">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">党龄结构</p>
              <div class="bot_line"></div>
              <div class="chartbutton">
                <div class="leftbutton" @click="prevhandler"></div>
                <div class="rightbutton" @click="nexthandler"></div>
              </div>
            </div>
            <div id="myChart_partystanding" :style="{height: height+'px'}"></div>
          </div>
        </van-swipe-item>
        <van-swipe-item>
          <!-- echart饼图  学历结构 -->
          <div class="chart" id="education">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">学历结构</p>
              <div class="bot_line"></div>
              <div class="chartbutton">
                <div class="leftbutton" @click="prevhandler"></div>
                <div class="rightbutton" @click="nexthandler"></div>
              </div>
            </div>
            <div id="myChart_education" :style="{height: height+'px'}"></div>
          </div>
        </van-swipe-item>
        <van-swipe-item>
          <!-- echart饼图  性别结构 -->
          <div class="chart" id="gender">
            <div class="chart_tit">
              <p class="text-center text-sm chart_title">性别结构</p>
              <div class="bot_line"></div>
              <div class="chartbutton">
                <div class="leftbutton" @click="prevhandler"></div>
                <div class="rightbutton" @click="nexthandler"></div>
              </div>
            </div>
            <div id="myChart_gender" :style="{height: height+'px'}"></div>
          </div>
        </van-swipe-item>
        <template slot="indicator">
          <div class="indicator">
            <div class="custom-indicator" :class="{'active':currentindex == 0}"></div>
            <div class="custom-indicator" :class="{'active':currentindex == 1}"></div>
            <div class="custom-indicator" :class="{'active':currentindex == 2}"></div>
            <div class="custom-indicator" :class="{'active':currentindex == 3}"></div>
            <div class="custom-indicator" :class="{'active':currentindex == 4}"></div>
            <!-- <div class="custom-indicator" :class="{'active':currentindex == 5}"></div>
            <div class="custom-indicator" :class="{'active':currentindex == 6}"></div>-->
          </div>
        </template>
      </van-swipe>

      <div class="textbutton">
        <div class="leftbutton" @click="prevhandler">上一幅图表</div>
        <div class="rightbutton" @click="nexthandler">下一幅图表</div>
      </div>
    </div>

    <!-- 申请入党 -->
    <div class="application">
      <img class="img" src="@/assets/img/partymanage/tobecome.png" alt />
      <div class="info">
        <div class="title">申请入党</div>
        <div class="number">
          <span class="number">{{applicationnumber}}</span>
          <span class="unit">名</span>
        </div>
      </div>
    </div>

    <!-- 积极分子/发展对象 -->
    <div class="positive">
      <div class="leftobj">
        <div class="info">
          <div class="title">积极分子</div>
          <div class="number">
            <span class="number">{{activistnumber}}</span>
            <span class="unit">名</span>
          </div>
        </div>
      </div>
      <div class="rightobj">
        <div class="info">
          <div class="title">发展对象</div>
          <div class="number">
            <span class="number">{{developnumber}}</span>
            <span class="unit">名</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 加载层 -->
    <loading v-if="loadingShow"></loading>
    <van-popup v-model="popupflag" round position="bottom" :style="{ height: '50%' }">
      <van-picker
        ref="vanpicker"
        title="选择年份"
        show-toolbar
        :default-index="defaultindex"
        :columns="yeararray"
        @confirm="onConfirm"
        @cancel="onCancel"
        @change="onChange"
      />
    </van-popup>

    <div class="fullModal" v-if="show" @click="voiceFun('close')"></div>
    <div :class="show?'voiceModal show':'voiceModal'">
      <span class="close" @click="voiceFun('close')">x</span>
      <div class="img">
        <img v-if="longShow" src="@/assets/img/engineering/icon_voice_svg.svg" />
        <img v-if="!longShow" src="@/assets/img/engineering/icon_voice_png.png" />
        <p class="reminder">{{voiceTxt}}</p>
      </div>
      <div class="button" @touchstart="touchStart" @touchend="touchEnd">
        <van-button type="info" size="large">长按录音</van-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
// import { Toast } from "vant";
import Loading from "../../../components/loading";
import { Toast, Button } from "vant";
export default {
  name: "overview",
  data() {
    return {
      loadingShow: true, //加载层
      height: 340, //饼图高度
      barheight: 300, //柱状图高度
      popupflag: false, //弹框显示关闭旗帜
      yeararray: ["2019", "2020", "2021", "2022", "2023"],
      defaultindex: 1,
      searchvalue: "", //输入的搜索值
      searchresultarr: [], //搜索结果数组
      searchresponseflag: false, //搜索结果完毕旗帜
      partyMemberNum: 0, //成员
      partyCadresNum: 0, //干部
      currentindex: 0, //轮播图索引
      agearray: [], //党员年龄结构
      educationarray: [], //学历结构
      genderarray: [], //性别结构
      partystandingarray: [], //党龄结构
      activityyear: 2020, //党员活动次数统计-年
      // 录音
      show: false,
      loop: 0,
      longShow: false,
      voiceTxt: "",
      url2: "http://m.sea.com",
      url: "https://wechat.gdhchina.com",
      localId: "", //录音id
      timeStamp: Math.round(new Date() / 1000), // 时间戳
      corpId: "ww1736e9ae98ad76c9", //企业微信的corpid
      corpSecret: "Yu_8FD95HgqUzgcqPgxZjonX-yUi6Vl_bQb9ETskwG4", //应用secret
      nonceStr: "Wm3WZYTPz0wzccnW", //生成签名的随机串
      timer: null,
      applicationnumber: 0, //申请入党
      activistnumber: 0, //积极分子
      developnumber: 0 //发展对象
    };
  },
  created() {
    this._partyrequest("");
    this._construction("");
    this._activityrequest("", this.activityyear); //默认2020
    this._applyrequest("合计");
  },
  mounted() {
    this.getAuthSign();

    // const arr = [
    //   {
    //     name: "1",
    //     num: "5695610",
    //     value: 5695610
    //   },
    //   {
    //     name: "2",
    //     num: "669577",
    //     value: 669577
    //   },
    //   {
    //     name: "3",
    //     num: "669577",
    //     value: 3826631
    //   }
    // ];
    this.$nextTick(() => {
      // this.drawChart(arr, "myChart_percentage", ["#FFA200", "#00B6D1"]);
      // this.drawHorizontalBArChart("myChart_plan");
    });
    setTimeout(() => {}, 500);
  },
  computed: {
    // 计算是否可以滚动
    scrollcalculate() {
      return this.searchresponseflag == false ? "scroll" : "hidden";
    }
  },
  methods: {
    // 用户清除输入值
    closedhandler() {
      this.searchresponseflag = false;
      this.searchvalue = "";
      this.$nextTick(() => {
        this.$refs.vanpicker.setColumnIndex(0, 1);
      });

      this.activityyear = 2020;
      window.sessionStorage.removeItem("keyword");
      this._partyrequest("");
      this._construction("");
      this._activityrequest("", this.activityyear); //默认2020
      this._applyrequest("合计");
    },
    // 用户点击重置
    // resethandler() {
    //   this.$nextTick(() => {
    //     this.$refs.vanpicker.setColumnIndex(0, 1);
    //   });

    //   this.activityyear = 2020;
    //   window.sessionStorage.removeItem("keyword");
    //   this._partyrequest("");
    //   this._construction("");
    //   this._activityrequest("", this.activityyear); //默认2020
    //   this._applyrequest("合计");
    // },
    // 搜索关键字
    _searchkeyword(value) {
      console.log(value);
      if (value == "") {
        this.searchresultarr = [];
        return false;
      } else {
        const parameter = {
          name: value
        };
        this.$api.partymanage
          .searchkeyword(parameter)
          .then(response => {
            console.log(response);
            if (response.status == 1000 && response.data.result.length) {
              this.searchresultarr = response.data.result[0].children;
              for (
                let i = 0;
                i < response.data.result[0].children.length;
                i++
              ) {
                if (response.data.result[0].children[i].fullName == value) {
                  this.searchresponseflag = false;
                } else {
                  this.searchresponseflag = true;
                }
              }
            } else {
              this.searchresponseflag = false;
              console.log("状态错误或者没有数据!");
            }
          })
          .catch(accident => {
            console.log(accident + ":意外错误");
          });
      }
    },
    // 党员数据
    _partyrequest(value) {
      const parameter = {
        name: value
      };
      this.$api.partymanage
        .partyrequest(parameter)
        .then(response => {
          console.log(response);
          if (response.status == 1000) {
            this.partyMemberNum = response.data.result.partyMemberNum;
            this.partyCadresNum = response.data.result.partyCadresNum;
            this.loadingShow = false;
          } else {
            console.log("状态错误或者没有数据!");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    // 党组织活动次数统计
    _activityrequest(name, year) {
      const parameter = {
        name: name,
        times: this.getUnixTime(
          year + "/" + "01" + "/" + "01" + " " + "00:00:00"
        )
      };
      this.$api.partymanage
        .activityrequest(parameter)
        .then(response => {
          console.log(response);
          if (
            response.status == 1000 &&
            response.data.result.activityTypeList.length
          ) {
            const titlearray = response.data.result.activityTypeList.map(
              item => {
                return item.typeName;
              }
            );
            const valuearray = [];
            for (let key in response.data.result.orgActivityMap) {
              valuearray.push(response.data.result.orgActivityMap[key]);
            }
            this.drawPortaitBArChart(
              "myChart_activity",
              titlearray,
              valuearray
            );
            // console.log(titlearray);
            // console.log(valuearray);
          } else {
            console.log("状态错误或者没有数据!");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    // 党员数据结构统计
    _construction(name) {
      const parameter = {
        name: name
      };
      this.$api.partymanage
        .construction(parameter)
        .then(response => {
          console.log(response);
          if (response.status == 1000 && response.data.result) {
            const { result } = response.data;
            var agetotal =
              result.ageNum +
              result.ageNum1 +
              result.ageNum2 +
              result.ageNum3 +
              result.ageNum4;
            const ageObj_1 = {
              value: result.ageNum,
              rate: this.GetPercent(result.ageNum, agetotal),
              name: "18-28岁" + "  " + this.GetPercent(result.ageNum, agetotal)
            };
            const ageObj_2 = {
              value: result.ageNum1,
              rate: this.GetPercent(result.ageNum1, agetotal),
              name: "29-35岁" + "  " + this.GetPercent(result.ageNum1, agetotal)
            };
            const ageObj_3 = {
              value: result.ageNum2,
              rate: this.GetPercent(result.ageNum2, agetotal),
              name: "36-50岁" + "  " + this.GetPercent(result.ageNum2, agetotal)
            };
            const ageObj_4 = {
              value: result.ageNum3,
              rate: this.GetPercent(result.ageNum3, agetotal),
              name: "51-60岁" + "  " + this.GetPercent(result.ageNum3, agetotal)
            };
            const ageObj_5 = {
              value: result.ageNum4,
              rate: this.GetPercent(result.ageNum4, agetotal),
              name:
                "大于60岁" + "  " + this.GetPercent(result.ageNum4, agetotal)
            };
            this.agearray = [];
            this.agearray.push(
              ageObj_1,
              ageObj_2,
              ageObj_3,
              ageObj_4,
              ageObj_5
            );
            this.drawChart(this.agearray, "myChart_age", [
              "#F33F50",
              "#FFAA00",
              "#8B52FF",
              "#44BFFF",
              "#3175FF"
            ]);

            var educationtotal =
              result.educationNum +
              result.educationNum1 +
              result.educationNum2 +
              result.educationNum3 +
              result.educationNum4;
            const educationObj_1 = {
              value: result.educationNum,
              rate: this.GetPercent(result.educationNum, educationtotal),
              name: "博士"
            };
            const educationObj_2 = {
              value: result.educationNum1,
              rate: this.GetPercent(result.educationNum1, educationtotal),
              name: "硕士"
            };
            const educationObj_3 = {
              value: result.educationNum2,
              rate: this.GetPercent(result.educationNum2, educationtotal),
              name: "本科"
            };
            const educationObj_4 = {
              value: result.educationNum3,
              rate: this.GetPercent(result.educationNum3, educationtotal),
              name: "大专"
            };
            const educationObj_5 = {
              value: result.educationNum4,
              rate: this.GetPercent(result.educationNum4, educationtotal),
              name: "其它"
            };
            this.educationarray = [];
            this.educationarray.push(
              educationObj_1,
              educationObj_2,
              educationObj_3,
              educationObj_4,
              educationObj_5
            );
            this.drawChart(this.educationarray, "myChart_education", [
              "#F33F50",
              "#FFAA00",
              "#8B52FF",
              "#44BFFF",
              "#3175FF"
            ]);

            var gendertotal = result.genderNum + result.genderNum1;
            const genderObj_1 = {
              value: result.genderNum,
              rate: this.GetPercent(result.genderNum, gendertotal),
              name: "男"
            };
            const genderObj_2 = {
              value: result.genderNum1,
              rate: this.GetPercent(result.genderNum1, gendertotal),
              name: "女"
            };
            this.genderarray = [];
            this.genderarray.push(genderObj_1, genderObj_2);
            this.drawChart(this.genderarray, "myChart_gender", [
              "#3175FF",
              "#F8A8EC"
            ]);

            var partystandingtotla =
              result.userNum +
              result.userNum1 +
              result.userNum2 +
              result.userNum3;
            const partystandingObj_1 = {
              value: result.userNum,
              rate: this.GetPercent(result.userNum, partystandingtotla),
              name: "0-5年党龄"
            };
            const partystandingObj_2 = {
              value: result.userNum1,
              rate: this.GetPercent(result.userNum1, partystandingtotla),
              name: "6-10年党龄"
            };
            const partystandingObj_3 = {
              value: result.userNum2,
              rate: this.GetPercent(result.userNum2, partystandingtotla),
              name: "11-20年党龄"
            };
            const partystandingObj_4 = {
              value: result.userNum3,
              rate: this.GetPercent(result.userNum3, partystandingtotla),
              name: "21年以上"
            };
            this.partystandingarray = [];
            this.partystandingarray.push(
              partystandingObj_1,
              partystandingObj_2,
              partystandingObj_3,
              partystandingObj_4
            );
            this.drawChart(this.partystandingarray, "myChart_partystanding", [
              "#F33F50",
              "#FFAA00",
              "#44BFFF",
              "#8B52FF"
            ]);
          } else {
            console.log("状态错误或者没有数据!");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    // 申请入党
    _applyrequest(name) {
      const parameter = {
        condition: { unitName: `like:${name}` },
        number: 0,
        relation: "and",
        size: 0,
        sortDirection: "ASC",
        sortProperties: []
      };
      this.$api.partymanage
        .applyrequest(parameter)
        .then(response => {
          console.log(response);
          if (response.state.code == 10000 && response.body.list.length) {
            this.applicationnumber = response.body.list[0].applyForPartyCount;
            this.activistnumber = response.body.list[0].partyActivistsCount;
            this.developnumber = response.body.list[0].devpObjectCount;
          } else {
            this.applicationnumber = 0;
            this.activistnumber = 0;
            this.developnumber = 0;
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    // 用户点击搜索列表的详情
    itemdetail(item) {
      // console.log(item);
      this.$nextTick(() => {
        this.$refs.vanpicker.setColumnIndex(0, 1);
      });
      this.activityyear = 2020;
      window.sessionStorage.setItem("keyword", item.fullName);
      this._partyrequest(item.fullName);
      this._activityrequest(item.fullName, this.activityyear);
      this._construction(item.fullName);
      this._applyrequest(item.fullName);
      // this._applyrequest("粤海投资有限公司");
      this.searchvalue = item.fullName;
    },
    // 选择年确定
    onConfirm(value) {
      // Toast(`当前值：${value}, 当前索引：${index}`);
      this._activityrequest(
        window.sessionStorage.getItem("keyword") || "",
        value
      );
      this.activityyear = value;
      this.popupflag = false;
    },
    // 选择年份变化
    onChange(picker, value, index) {
      // Toast(`当前值：${value}, 当前索引：${index}`);
      console.log(picker, value, index);
    },
    onCancel() {
      this.popupflag = false;
    },
    // 用户点击年选择按钮
    showpopupflag() {
      this.popupflag = true;
    },
    // 轮播图索引
    banneronChange(index) {
      // console.log(index);
      this.currentindex = index;
    },
    // echart饼图
    // 此函数需要传入 数据数组 颜色数组 id
    drawChart(data, id, color) {
      let myChart = this.$echarts.init(document.getElementById(id));
      let titlelist = [];
      data.forEach(item => {
        titlelist.push(item.name);
      });
      let option = {
        color: color,
        legend: {
          // orient: 'vertical',
          // top: 'middle',
          // bottom: 10,
          // left: "center",
          // x: "center",
          bottom: "0",
          left: "center",
          width: "100%",
          align: "auto"

          // icon: "rect",
          // itemWidth: 20,
          // itemHeight: 20,
          // itemGap: 60,
          // textStyle: {
          //   fontSize: 14
          // },

          // data: titlelist
        },
        series: [
          {
            hoverAnimation: true, //扇区放大高亮
            name: "",
            type: "pie",
            radius: ["32%", "50%"],
            center: ["50%", "40%"],
            avoidLabelOverlap: true,
            label: {
              // position: "outside",
              // alignTo: "edge",
              fontSize: "18",
              align: "left",
              color: "#606266",
              margin: 0,
              formatter: function(value) {
                return [
                  "{a|" + value.data.name + "}",
                  "{b|" + value.data.value + "人" + "}",
                  "{c|" + value.data.rate + "}"
                ].join("\n");
                // var result = [],
                //   counter = 0;
                // var isFloat = String(a.data.num).indexOf(".");
                // if (isFloat != -1) {
                //   var n = parseInt(a.data.num).toFixed(0);
                //   a.data.num = n.toString();
                // }
                // var num_array = a.data.num.split(".");
                // var num = num_array[0];
                // console.log(num_array);
                // var newstr = "";
                // for (var i = num.length - 1; i >= 0; i--) {
                //   counter++;
                //   result.unshift(num[i]);
                //   if (!(counter % 3) && i != 0) {
                //     result.unshift(",");
                //   }
                // }
                // console.log(result);
                // if (num_array.length > 1) {
                //   newstr = result.join("");
                //   newstr += "." + num_array[1];
                //   return [
                //     "{a|" + a.name + "}",
                //     "{b|" + newstr + "万元" + "}",
                //     "{c|" + a.percent.toFixed(0) + "%" + "}"
                //   ].join("\n");
                // } else {
                //   return [
                //     "{a|" + a.name + "}",
                //     "{b|" + result.join("") + "万元" + "}",
                //     "{c|" + a.percent.toFixed(0) + "%" + "}"
                //   ].join("\n");
                // }
              },
              rich: {
                //控制说明的文字的样式
                a: {
                  lineHeight: 14,
                  fontSize: 12,
                  fontWeight: "bold"
                },
                b: {
                  lineHeight: 20,
                  fontSize: 12,
                  fontWeight: "bold"
                },
                c: {
                  lineHeight: 12,
                  fontSize: 12,
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              //控制连线的颜色
              show: true,
              length: 10,
              length2: 10
              // lineStyle: {
              //   color: "#D6D6D6"
              // }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      // echart 点击事件
      // let self = this;
      // myChart.on("click", function(params) {
      //   console.log(title);
      //   console.log(
      //     params.name,
      //     "name---",
      //     type,
      //     "type===",
      //     params.data,
      //     "data",
      //     params.title
      //   );
      //   let name =
      //     params.name == "水务及水环境治理"
      //       ? "0"
      //       : "" || params.name == "产业园及制造业"
      //       ? "1"
      //       : "" || params.name == "城市综合体"
      //       ? "2"
      //       : "";
      //   self.$router.push({
      //     name: "engineering-plate",
      //     query: {
      //       board: name,
      //       type: type,
      //       data: params.data.num,
      //       title: title
      //     }
      //   });
      // });
    },
    // 纵向柱状图
    drawPortaitBArChart(id, titlelist, valuelist) {
      let yearChart = this.$echarts.init(document.getElementById(id));
      let option = {
        color: "#FFAE01",
        legend: {
          x: "center",
          bottom: "10",
          width: "100%",
          // icon: "rect",
          // itemWidth: 20,
          // itemHeight: 10,
          // itemGap: 20,
          textStyle: {
            fontSize: 14
          },
          data: ["已开展"]
        },
        grid: {
          left: "10",
          right: "10",
          bottom: "13%",
          top: "30",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            axisTick: {
              show: false //刻度
            },
            // data: this.actualYearData.months,
            data: titlelist,
            axisLine: {
              lineStyle: {
                color: "rgba(115,115,115,.5)"
              }
            },

            axisLabel: {
              rotate: 40,
              textStyle: {
                fontSize: 8,
                color: "#333"
              }
            },
            splitLine: {
              show: true,
              lineStyle: {
                color: ["#F0F0F0"]
              }
            }
          }
        ],
        yAxis: {
          type: "value",
          name: "次"
        },
        series: [
          {
            name: "已开展",
            type: "bar",
            stack: "one",
            data: valuelist,
            showBackground: true,
            backgroundStyle: {
              color: "rgba(220, 220, 220, 0.8)"
            },
            label: {
              show: true,
              position: "inside"
            }
          }
        ]
      };
      yearChart.setOption(option);
    },
    // 横向柱状图
    drawHorizontalBArChart(id) {
      let yearChart = this.$echarts.init(document.getElementById(id));
      // var colors = ["#FFAE01", "#E9221B"];
      let option = {
        tooltip: {
          show: false,
          trigger: "axis",
          axisPointer: {
            type: "shadow"
          }
        },
        legend: {
          data: [
            { name: "已经发展", icon: "circle" },
            { name: "计划发展", icon: "circle" }
          ]
        },
        grid: {
          left: "10%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: {
          type: "value",
          boundaryGap: [0, 0.01]
          // show: false
        },
        yAxis: {
          type: "category",
          // data: ["已经发展", "计划发展"],
          axisLine: {
            show: false //坐标轴
          },
          axisTick: [
            {
              //坐标轴小标记
              show: false
            }
          ],
          offset: 8,
          nameTextStyle: {
            fontSize: 15
          }
        },
        series: [
          {
            type: "bar",
            barWidth: 30,
            label: {
              normal: {
                show: true,
                textStyle: {
                  color: "#959595",
                  fontSize: 14
                },
                position: "right"
              }
            },
            itemStyle: {
              normal: {
                // barBorderRadius: [0, 25, 25, 0],
                color: function(param) {
                  let colorList = ["#E9221B", "#FFAE01"];
                  let x = "";
                  param.dataIndex % 2 == 0 ? (x = 1) : (x = 2);
                  if (x == "1") {
                    return colorList[0];
                  } else {
                    return colorList[1];
                  }
                }
              }
            },
            data: [50, 100]
          }
        ]
      };
      yearChart.setOption(option);
    },
    // 用户点击上一幅图表
    prevhandler() {
      this.$refs.bannerswipe.prev();
    },
    // 用户点击下一幅图表
    nexthandler() {
      this.$refs.bannerswipe.next();
    },
    // 计算百分比
    GetPercent(num, total) {
      /// <summary>
      /// 求百分比
      /// </summary>
      /// <param name="num">当前数</param>
      /// <param name="total">总数</param>
      num = parseFloat(num);
      total = parseFloat(total);
      if (isNaN(num) || isNaN(total)) {
        return "-";
      }
      return total <= 0
        ? "0%"
        : Math.round((num / total) * 10000) / 100.0 + "%";
    },
    // 时间转换时间戳
    getUnixTime(dateStr) {
      console.log(dateStr);
      var newstr = dateStr.replace(/-/g, "/");
      var date = new Date(newstr);
      var time_str = date.getTime().toString();
      return time_str.substr(0, 10);
    },
    //点击录音
    voiceFun(obj) {
      this.show = obj == "open" ? true : false;
      if (obj == "open") {
        this.searchresponseflag = [];
        this.searchresponseflag = false;
      }
      // 此变量控制搜索列表
      // this.searchListShow = false;
      // 此变量搜索值
      // obj == "open" ? (this.searchvalue = "") : (this.show = false);
      // 提示 倾听中
      this.voiceTxt = "";
      this.longShow = false;
    },
    //获取签名signature
    getAuthSign() {
      this.$api.engineering
        .getAuthSign({
          corpId: this.corpId,
          corpSecret: this.corpSecret,
          noncestr: this.nonceStr,
          timestamp: this.timeStamp,
          url: window.location.href.split("#")[0] //当前网页的URL，不包含#及其后面部分
        })
        .then(res => {
          console.log(JSON.stringify(res) + "获取签名");
          if (res.state.code == 10000) {
            window.localStorage.setItem("signature", res.body.message);
            this.getBase();
          }
        });
    },
    getBase() {
      wx.config({
        beta: true, // 调用wx.invoke形式的接口值时，该值必须为true。
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: this.corpId, // 必填，企业微信的cropID
        timestamp: this.timeStamp, // 必填，生成签名的时间戳
        nonceStr: this.nonceStr, // 必填，生成签名的随机串
        signature: window.localStorage.getItem("signature"), // 必填，签名，见附录1
        // jsApiList: '',
        jsApiList: [
          "startRecord",
          "stopRecord",
          "playVoice",
          "onVoiceRecordEnd",
          "translateVoice"
        ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
      });
      wx.ready(() => {}),
        wx.error(function(res) {
          alert("出错了：" + JSON.stringify(res));
          // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
        });
    },
    // 开始触摸
    touchStart() {
      let _this = this;
      let isMinite = false;
      _this.loop = setTimeout(function() {
        _this.loop = 0;
        //执行长按要执行的内容，如弹出菜单
        _this.voiceTxt = "倾听中，松手结束";
        _this.longShow = true;
        wx.startRecord(); //开始录音
      }, 500);
      // this.timer = setTimeout(function(){
      //   alert('已过1分钟')
      //   _this.touchEnd();
      // }, 1000*5);
      // clearTimeout(_this.timer);
    },
    // 触摸结束
    touchEnd() {
      let _this = this;
      clearTimeout(_this.loop);
      // if(_this.loop!=0){
      _this.longShow = false;
      //这里写要执行的内容（尤如onclick事件）
      wx.stopRecord({
        success: function(res) {
          _this.localId = res.localId;
          _this.voiceTxt = "识别中，请稍后";
          _this.timer = setTimeout(function() {
            _this.translateVoice();
          }, 1000 * 3);
        },
        fail: function(res) {
          Toast(JSON.stringify(res) + "识别失败，请重新录音");
        }
      });
      clearTimeout(_this.timer);
      // }
    },
    //语音转文字
    translateVoice() {
      let _this = this;
      // alert('转文字')
      // alert(_this.localId)
      wx.translateVoice({
        localId: _this.localId, // 需要识别的音频的本地Id，由录音相关接口获得，音频时长不能超过60秒
        isShowProgressTips: 1, // 默认为1，显示进度提示
        success: function(res) {
          _this.voiceTxt = "";
          console.log(res.translateResult);
          _this.searchvalue = res.translateResult
            ? res.translateResult.substr(0, res.translateResult.length - 1)
            : "";
          // _this.onChangeinput();
        },
        fail: function(res) {
          Toast(res + "语音转文字失败");
        }
      });
    }
    // onChangeinput() {
    //   this.show = false;
    //   this.$api
    //     .queryProjectList({
    //       projectName: this.searchValue
    //     })
    //     .then(res => {
    //       if (res.state.code === 10000) {
    //         if (res.body.length) {
    //           // this.searchListShow = true;
    //           // this.searchList = res.body;
    //           this.searchresultarr = res.body;
    //         } else {
    //           this.searchListShow = false;
    //           Toast("暂无数据");
    //         }
    //       }
    //     });
    //   this.search = !this.search;
    // },
  },
  watch: {
    searchvalue(newvalue) {
      console.log(newvalue);
      // console.log(newvalue, oldvalue);
      this._searchkeyword(newvalue);
    }
  },
  components: { Loading, "van-button": Button, [Toast.name]: Toast }
};
</script>

<style scoped lang="scss">
.overview {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  // top: 105px;
  top: 0px;
  bottom: 0px;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  // 弹窗样式
  .result {
    z-index: 101;
    position: absolute;
    top: 103px;
    left: 0;
    right: 0;
    // z-index: 1;
    // height: 92%;
    bottom: 0;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
    background: #fff;
    .hinttext {
      font-size: 35px;
      height: 100%;
      width: 100%;
      text-align: center;
      line-height: 350px;
      font-weight: bold;
    }
    .resultlist {
      .item {
        padding: 15px 30px;
        font-weight: bold;
        display: -webkit-box;
        overflow: hidden;
        white-space: normal !important;
        text-overflow: ellipsis;
        word-wrap: break-word;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        line-height: 2.8;
        border: 1px solid #b8bbbf;
      }
    }
  }
  .obstruct {
    position: fixed;
    top: 103px;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 100;
    &.obstructanimation-enter-active,
    &.obstructanimation-leave-active {
      transition: all 0.4s;
    }

    &.obstructanimation-enter,
    &.obstructanimation-leave-to {
      opacity: 0;
    }
    // transition: all 10s linear 0s;
  }
  .search {
    margin: 0 auto;
    width: 90%;
    height: 103px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 1);
    .voice {
      width: 160px;
      height: 80px;
      background: #eef4fa;
      border-radius: 40px;
      margin-left: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      img {
        width: 36px;
        height: 46px;
      }
      .text {
        font-size: 32px;
        font-family: Adobe Heiti Std;
        font-weight: normal;
        color: rgba(0, 0, 0, 1);
      }
    }
    .include {
      flex: 1;
      height: 80px;
      background: rgba(238, 244, 250, 1);
      border-radius: 40px;
      display: flex;
      align-items: center;
      padding: 0 20px;
    }
    .searchinput {
      flex: 1;
      height: 100%;
      outline: none;
      border: none;
      text-indent: 20px;
      background: rgba(238, 244, 250, 1);
      border-radius: 40px;
    }
    .searchimg {
      width: 40px;
      height: 40px;
    }
    .closed {
      width: 40px;
      height: 40px;
      border: 1px solid #ccc;
      border-radius: 50%;
      position: relative;
      margin-left: 20px;
    }
    .closed:before {
      content: "";
      display: block;
      position: absolute;
      width: 90%;
      height: 1px;
      background: #666;
      transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      top: 16px;
      left: 5%;
    }
    .closed:after {
      content: "";
      display: block;
      position: absolute;
      width: 90%;
      height: 1px;
      background: #666;
      transform: rotate(-45deg);
      -webkit-transform: rotate(-45deg);
      top: 16px;
      left: 5%;
    }
  }
  .application,
  .partywork,
  .partycount {
    position: relative;
    .img {
      display: block;
      width: 90%;
      margin: 0 auto;
    }
    .info {
      position: absolute;
      top: 35px;
      left: 70px;
      .title {
        font-size: 40px;
        font-family: PingFang-SC-Heavy;
        color: #fff;
      }
      .number {
        .number {
          font-size: 70px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
          margin-right: 20px;
        }
        .unit {
          font-size: 50px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
        }
      }
    }
    .detail {
      position: absolute;
      bottom: 0px;
      right: 40px;
      color: #fff;
      padding: 20px;
    }
  }

  .application,
  .partywork {
    margin-top: 30px;
  }

  #partystanding,
  #plan,
  #activity,
  #age,
  #education,
  #gender,
  #percentage {
    background: #f4f1f4;
    // margin-top: 30px;
    padding: 30px 0;
    .chart_title {
      font-size: 38px;
      font-family: PingFang SC;
      font-weight: 800;
      color: rgba(0, 0, 0, 1);
      position: relative;
      &.chart_title::before {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        left: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
      &.chart_title::after {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        right: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
    }
    .chart_tit {
      position: relative;
    }
    .chartbutton {
      .leftbutton {
        width: 50px;
        height: 50px;
        // background: red;
        border-left: 6px solid #bdbdbd;
        border-top: 6px solid #bdbdbd;
        position: absolute;
        left: 60px;
        top: 0px;
        transform: rotate(-45deg);
      }
      .rightbutton {
        width: 50px;
        height: 50px;
        // background: red;
        border-right: 6px solid #bdbdbd;
        border-top: 6px solid #bdbdbd;
        position: absolute;
        right: 60px;
        top: 0px;
        transform: rotate(45deg);
      }
    }
  }

  #partystanding,
  #education,
  #gender {
    .chart_title {
      &.chart_title::before {
        left: 35%;
      }
      &.chart_title::after {
        right: 35%;
      }
    }
  }
  #plan,
  #activity {
    .chart_title {
      &.chart_title::before {
        left: 25%;
      }
      &.chart_title::after {
        right: 25%;
      }
    }
    .bot_line {
      text-align: center;
      margin-top: 20px;
      .yeartext {
        display: inline-block;
        width: 260px;
        height: 59px;
        background: rgba(255, 243, 235, 1);
        border: 1px solid rgba(255, 115, 1, 1);
        border-radius: 27px;
        font-size: 36px;
        font-family: PingFang SC;
        font-weight: 800;
        color: #ff7200;
        position: relative;
        &.yeartext::after {
          content: "";
          width: 0;
          height: 0;
          position: absolute;
          top: 50%;
          right: 40px;
          transform: translateY(-50%);
          border-right: solid 15px transparent;
          border-left: solid 15px transparent;
          border-top: solid 15px #ff7200;
        }
      }
    }
  }

  #plan {
    position: relative;
    .text-explain {
      text-align: center;
      font-size: 34px;
      font-family: PingFang SC;
      font-weight: 800;
      color: rgba(96, 98, 102, 1);
    }
    .planlist {
      position: absolute;
      left: 0;
      bottom: 180px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      .item {
        width: 85px;
        height: 73px;
        font-size: 34px;
        font-family: PingFang SC;
        font-weight: 800;
        color: rgba(96, 98, 102, 1);
      }
    }
  }

  .positive {
    width: 90%;
    margin: 30px auto;
    display: flex;
    justify-content: space-between;
    .leftobj,
    .rightobj {
      width: 48%;
      height: 200px;
      background: linear-gradient(
        -48deg,
        rgba(255, 102, 72, 1),
        rgba(227, 4, 4, 1)
      );
      border-radius: 10px;
      position: relative;
      .info {
        position: absolute;
        top: 35px;
        left: 30px;
        .title {
          font-size: 40px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
        }
        .number {
          .number {
            font-size: 70px;
            font-family: PingFang-SC-Heavy;
            color: #fff;
            margin-right: 20px;
          }
          .unit {
            font-size: 50px;
            font-family: PingFang-SC-Heavy;
            color: #fff;
          }
        }
      }
    }
  }

  .banner {
    position: relative;
    .textbutton {
      display: none;
      display: flex;
      justify-content: center;
      position: absolute;
      bottom: 10px;
      left: 50%;
      transform: translateX(-50%);
      .leftbutton,
      .rightbutton {
        text-align: center;
        width: 260px;
        height: 80px;
        line-height: 80px;
        background: rgba(255, 255, 255, 1);
        border: 2px solid rgba(231, 23, 16, 1);
        border-radius: 10px;
        font-size: 34px;
        font-family: Adobe Heiti Std;
        font-weight: bold;
        color: rgba(244, 64, 46, 1);
      }
      .leftbutton {
        margin-right: 30px;
      }
    }
  }
  .my-swipe .van-swipe-item {
    background-color: #f4f1f4;
  }
  .my-swipe {
    width: 90%;
    margin: 30px auto;
  }
  .indicator {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 90%;
    position: absolute;
    bottom: 120px;
    left: 50%;
    transform: translateX(-50%);
    .custom-indicator {
      width: 60px;
      height: 14px;
      background: rgba(154, 154, 154, 1);
      border-radius: 7px;
      margin-right: 24px;
    }
    .active {
      background: #f33d2c;
    }
  }
  // .custom-indicator {
  //   position: absolute;
  //   right: 5px;
  //   bottom: 5px;
  //   padding: 2px 5px;
  //   width: 60px;
  //   height: 20px;
  //   // font-size: 12px;
  //   background: red;
  // }

  .fullModal {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background: transparent;
  }

  .voiceModal {
    height: 350px;
    position: fixed;
    left: 0;
    right: 0;
    bottom: -400px;
    background: #fff;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    z-index: 9999;
    transition: all 0.3s ease-in;

    .close {
      position: absolute;
      right: 20px;
      top: 15px;
      color: #fff;
      padding: 10px 20px;
    }
    .img {
      background: #2980b9;
      text-align: center;
      padding: 20px 0;
      .reminder {
        color: #fff;
        padding-top: 20px;
        -webkit-touch-callout: none; /*系统默认菜单被禁用*/
        -webkit-user-select: none; /*webkit浏览器*/
        -khtml-user-select: none; /*早期浏览器*/
        -moz-user-select: none; /*火狐*/
        -ms-user-select: none; /*IE10*/
        user-select: none;
      }
      img {
        width: 10%;
      }
    }
    .button {
      margin-top: 20px;
      padding: 0 10px;
      position: absolute;
      bottom: 20px;
      left: 0;
      right: 0;
      /deep/ .van-button__text {
        -webkit-touch-callout: none; /*系统默认菜单被禁用*/
        -webkit-user-select: none; /*webkit浏览器*/
        -khtml-user-select: none; /*早期浏览器*/
        -moz-user-select: none; /*火狐*/
        -ms-user-select: none; /*IE10*/
        user-select: none;
      }
      button {
        display: block;
        width: 100%;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
    }
  }

  .voiceModal.show {
    bottom: 0;
  }
}
</style>
