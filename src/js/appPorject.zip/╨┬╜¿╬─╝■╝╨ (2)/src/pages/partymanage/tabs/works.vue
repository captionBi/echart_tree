<template>
  <div class="works">创新案例</div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "works",
  data() {
    return {};
  },
  components: {}
};
</script>

<style scoped lang="scss">
</style>
