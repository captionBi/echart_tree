<template>
  <div class="dynamic">党建动态</div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "dynamic",
  data() {
    return {};
  },
  components: {}
};
</script>

<style scoped lang="scss">
</style>
