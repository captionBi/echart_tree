<template>
  <div class="site">
    <!-- <div class="img"><img :src="require('../../assets/img/vacation/banner2.png')" /></div> -->
    <div class="parorama">
      <p class="count_name">全景图总数</p>
      <p class="count">
        {{projectTotal?projectTotal:0}}
        <span class="nuit">个</span>
      </p>
    </div>
    <van-search
      v-model="searchValue"
      shape="round"
      show-action
      placeholder="搜索框"
      @search="onSearch"
    >
      <template #action>
        <div @click="onSearch" v-if="search" class="search_button">搜索</div>
        <div @click="onCancel" v-else class="search_button">取消</div>
      </template>
    </van-search>
    <div class="overall_view">
      <van-row type="flex" justify="space-around" class="view_row">
        <van-col span="3" class="row_title">序号</van-col>
        <van-col span="14" class="row_title">全景名称</van-col>
        <van-col span="4" class="row_title">分期</van-col>
        <van-col span="3" class="row_title">操作</van-col>
      </van-row>
      <van-row
        type="flex"
        justify="space-around"
        class="view_row view_row_td"
        v-for="(item,index) in list"
        :key="index"
        @click="goPanoramicUrl(item)"
      >
        <van-col span="3" class="row_title">{{index+1}}</van-col>
        <van-col span="14" class="row_title text-cut">{{item.panoramicName}}</van-col>
        <van-col span="4" class="row_title text-cut">{{item.tenders}}</van-col>
        <van-col span="3" class="status row_cont">查看</van-col>
      </van-row>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import loading from "@/components/loading";
import { Search, Tab, Tabs, Col, Row, Toast } from "vant";
export default {
  components: {
    loading,
    [Search.name]: Search,
    [Tab.name]: Tab,
    [Tabs.name]: Tabs,
    [Col.name]: Col,
    [Row.name]: Row,
    [Toast.name]: Toast
  },
  data() {
    return {
      list: [],
      loadingShow: true,
      projectTotal: "",
      searchValue: "",
      search: true,
      newList: []
    };
  },
  created() {
    this.queryProjectList();
  },
  methods: {
    // 搜索
    onSearch() {
      let params = {
        projectName: this.searchValue
      };
      this.$api.site.getSearchList(params).then(res => {
        if (res.state.code === 10000) {
          if (res.body.length) {
            this.newList = res.body;
            this.list = res.body;
          } else {
            this.searchValue = "";
            this.search = !this.search;
            Toast("暂无数据");
          }
        }
      });
      this.search = !this.search;
    },
    onCancel() {
      this.searchValue = "";
      this.search = !this.search;
      this.queryProjectList();
    },
    // 720全景列表
    queryProjectList(params = {}) {
      this.loadingShow = true;
      this.$api.site.getSearchList(params).then(res => {
        this.loadingShow = false;
        if (res.state.code === 10000) {
          this.projectTotal = res.body.length;
          this.list = res.body;
        }
      });
    },
    // 全景详情
    goPanoramicUrl(item) {
      window.location.href = item.panoramicUrl;
    }
  }
};
</script>

<style scoped lang='scss'>
.parorama {
  background: url("../../assets/img/vacation/banner2.png");
  background-size: cover;
  height: 250px;
  border-radius: 10px;
  padding: 20px 0px 20px 40px;
  width: 100%;
  color: #fff;
  margin: 0px 0px 20px 0px;

  .count_name {
    font-size: 38px !important;
  }

  .count {
    font-size: 60px !important;
    text-align: center;
    margin-top: 40px;
  }
}

.img {
  img {
    width: 100%;
    display: block;
  }
}

.site {
  padding: 20px;
  overflow: hidden;

  .overall_view {
    margin: 24px 0;
    background: #fff;
    font-size: 30px;
    text-align: center;
    padding: 15px 20px;
    border-radius: 10px;

    .delay {
      color: #fc0a21;
    }

    .normal {
      color: #00c52e;
    }

    .view_row {
      padding: 20px 0px;

      .row_title {
        color: rgba(95, 97, 101, 0.9);
        font-size: 32px;
      }

      .row_cont {
        color: #0076f0;
        font-size: 30px;
      }
    }

    .view_row:nth-child(odd) {
      background: #e9f1fb;
    }
  }
}

.text-cut {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}
.nuit {
  font-size: 36px;
  margin-left: 5px;
  position: relative;
  top: -5px;
}
</style>