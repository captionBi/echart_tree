<template>
  <div class=''>
    <div class="video active" style="width: 300px;height: 300px" id="ckplayera"></div>
  </div>
</template>
<script>
export default {
  components: {},
  name: '',
  data () {
    return {}
  },
  created () {
    // let player1 = new ckplayer()


  },
  methods: {
    // ckplayera () {
    //   setTimeout(function () {
    //     var videoObject = {
    //       container: '#ckplayera',  // 容器的ID或className
    //       variable: 'player1',  // 播放函数名称 与下面一致
    //       autoplay: true,   // 是否自动播放 d
    //       live: true,  // 是否是直播视频 true = 直播，false = 点播
    //       mobileCkControls: false,  // 是否在移动端（包括ios）环境中显示控制
    //       video: 'http://hls01open.ys7.com/openlive/3c417b6d4.m3u8'  // hls地址
    //     }
    //     let player1 = new ckplayer(videoObject)

    //     console.log(ckplayer);

    //   }, 6)
    // },
  },
}
</script>
<style lang='scss' scoped >
</style>
