<template>
  <div class="video-more">
    <Card :item="moreData"></Card>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import Card from "./components/card"
import loading from "@/components/loading";

export default {
  components: { Card, loading },
  created() {
    let projectId = this.$route.query.projectId
    this.moreData = this.$route.query
    this.getVideoListByProjectId(projectId)
  },
  data() {
    return {
      moreData: {},
      loadingShow: false
    }
  },
  computed: {
    projectInfo(){
      return this.$route.query
    }
  },
  methods: { 
    async getVideoListByProjectId(projectId) {
      this.loadingShow = true;
      const { getProjectAndeVideoList } = this.$api.site
      let res = await getProjectAndeVideoList(projectId)
      if(res.state.code==10000){
        this.loadingShow = false;
        this.$set(this.moreData,'list', res.body)
      }
    },
  }
}
</script>

<style lang="scss" scoped>
.video-more {
  width: 100vw;
  padding: 25px 15px;
  box-sizing: border-box;
}
</style>