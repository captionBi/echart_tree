<template>
  <div class="site_detail">
    <video id="myVideo" class="video-js">
      <source :src="urls" type="video/mp4">
    </video>
  </div>
</template>
<script>
import {
  loading
} from "vant"
export default {
  components: {
    [loading.name]: loading
  },
  data () {
    return {
      id: '',
      screenWidth: document.body.clientWidth, // 屏幕宽
      screeHeight: document.body.clientHeight,
      urls: ""
    }
  },
  created () {
    // this.id = this.$route.query.id
    // this.$api.site.getVideoDetail(this.id).then(res => {
    //   // console.log(res,'=========')
    //   if (res.state.code === 10000) {
    //     if (res.body.code === 20001) {
    //       alert("无权限")
    //     } else if (res.body.code === 0) {
    //       // let reg = /[*]/g;
    //       //   text = text.replace(reg, "<br>");
    //       let url = res.body.data.url
    //       //  let url = 'http://api.welink.qq.com/hls/200900000000002098.m3u8?ticket=bff5f9229d164ff69e68546fdbf3c008'
    //       // let urlF = url.substring(0, url.indexOf("/hls"));
    //       // let urlB = url.substring(url.indexOf("/hls"));
    //       url = url.replace('com', 'com:880')
    //       this.urls = url
    //       // this.urls = `${urlF}:880${urlB}`
    //       console.log(this.urls, '----------');
    //     }
    //   }
    // })

  },
  mounted () {
    this.id = this.$route.query.id
    this.$api.site.getVideoDetail(this.id).then(res => {
      // console.log(res,'=========')
      if (res.state.code === 10000) {
        if (res.body.code === 20001) {
          alert("无权限")
        } else if (res.body.code === 0) {
          // let reg = /[*]/g;
          //   text = text.replace(reg, "<br>");
          let url = res.body.data.url
          //  let url = 'http://api.welink.qq.com/hls/200900000000002098.m3u8?ticket=bff5f9229d164ff69e68546fdbf3c008'
          // let urlF = url.substring(0, url.indexOf("/hls"));
          // let urlB = url.substring(url.indexOf("/hls"));
          url = url.replace('api.welink.qq.com', '219.135.193.190:8088')
          this.urls = url
          this.initVideo(url);
          // this.urls = `${urlF}:880${urlB}`
          console.log(this.urls, '----------');

        }
      }
    })


  },
  methods: {
    initVideo (url) {
      console.log(url, 'url========')
      let myVideo = document.getElementById("myVideo")
      //初始化视频方法
      this.$video(myVideo, {
        //确定播放器是否具有用户可以与之交互的控件。没有控件，启动视频播放的唯一方法是使用autoplay属性或通过Player API。
        controls: true,
        //自动播放属性,muted:静音播放
        autoplay: "muted",
        //建议浏览器是否应在<video>加载元素后立即开始下载视频数据。
        preload: "auto",
        //设置视频播放器的显示宽度（以像素为单位）
        width: this.screenWidth + 'px',
        //设置视频播放器的显示高度（以像素为单位）
        // height: "400px"
      });
    }
  }
}
</script>
<style lang="scss" scoped>
.loading_view {
  position: relative;
  min-height: 100%;
}

.loading_par {
  text-align: center;
  line-height: 135px;
  width: 135px;
  height: 135px;
  border-radius: 30px;
  background: #fff;
  position: fixed;
  top: calc(50% - 67px);
  left: calc(50% - 67px);
}

// .videoPlay {
//     width: 100%;
//     height: 667px;
// }
.site_img {
  width: 50%;
  min-height: 100%;
}

.site_detail {
  min-width: 100%;
  min-height: 100%;
}

.mask {
  width: 100%;
  height: 200px;
  background: rgba(0, 0, 0, 0.1);
  font-size: 30px;
  color: rgba(255, 255, 255, 0.4);
  padding-left: 40px;
  position: fixed;
  bottom: 0px;
}

.video_name {
  margin: 50px 0px 30px 0px;
}

.video_name_cont {
  color: #fff;
}

.title {
  width: 130px;
  text-align: right;
}

video {
  height: 100%;
  width: 100%;
}
</style>