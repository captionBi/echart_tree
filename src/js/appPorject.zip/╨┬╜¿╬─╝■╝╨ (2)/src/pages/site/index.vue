<template>
  <div class="video-page">
    <div>
      <section class="video--hd">
        <!-- <div class="window-count" v-for="item in countData" :key="item.id"> -->
        <div class="window-count">
          <div class="count">{{ count }}</div>
          <div class="text-df">工程总数</div>
        </div>
        <div class="window-count">
          <div class="count">{{ counts }}</div>
          <div class="text-df">监控数量</div>
        </div>
      </section>
    </div>
    <div class="Heights">
      <section class="video-bd">
        <div class="myCollection">
          <div class="dg-flex">
            <span class="text-sub text-df">我的收藏({{ collectListLen }})</span>
            <i class="flex-1"></i>
            <i
              class="i-text"
              v-show="collectList.length"
              @click="collectlist_click"
              >{{ collectlist_text }}</i
            >
          </div>
          <div class="item_list">
            <template v-if="collectList && collectList.length">
              <div v-show="collectlist_show">
                <div
                  class="item_box"
                  v-for="(item, index) in collectList"
                  :key="index"
                >
                  <div class="item_video" @click="goVedioDetail(item)">
                    <img
                      class="item_list_img"
                      :src="
                        item.bgImg
                          ? item.bgImg
                          : require('../../assets/img/site/collectImg.jpg')
                      "
                      alt
                    />
                    <p class="item_list_title">{{ item.videoName }}</p>
                  </div>
                  <div class="text-xs flex-between text-gray">
                    <i class="number">点击量: {{ item.clicks }}</i>
                    <p class="flex-center">
                      <i @click="cancelCollection(item)">收藏</i>
                      <img
                        src="../../assets/img/site/collection.png"
                        class="cancelCollection"
                      />
                    </p>
                  </div>
                </div>
              </div>
            </template>
            <div class="no_collect" v-else>暂无收藏</div>
          </div>
        </div>
        <template v-if="cardList && cardList.length > 0">
          <div class="plate" v-for="(item, index) in cardList" :key="index">
            <div class="operation">
              <div class="title">
                {{
                  item.board == 0
                    ? "水务及水环境治理"
                    : item.board == 1
                    ? "产业园及制造业"
                    : "城市综合体"
                }}
              </div>
              <div class="button" @click="neatenhandler(item)">
                {{ item.text }}
              </div>
            </div>
            <div class="operationcontent" v-show="item.flag">
              <Card
                ref="card"
                v-for="(card, index) in item.list"
                :key="index"
                :item="card"
                :showMore="true"
                @click-more="goMoreHandler(card)"
                @collectList="collect_list"
              ></Card>
            </div>
          </div>
        </template>
      </section>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import Card from "./components/card";
import loading from "../../components/loading";
import { Toast } from "vant";
import axios from "axios";
import methods from "../../utils/methods";

export default {
  name: "siteSave",
  components: { Card, loading },
  data() {
    return {
      loadingShow: false,
      count: 0,
      counts: 0,
      countData: [
        { num: 60, label: "工程总数", id: "1" },
        { num: 40, label: "监控数量", id: "2" },
      ],
      collectList: [],
      collectlist_show: true,
      collectlist_text: "收起",
      collectListLen: 0,
      cardList: [],
      cardList2: [
        {
          projectName: "水务及水环境治理",
          count: 3,
          list: [],
        },
        {
          projectName: "啊哈哈哈",
          count: 3,
          list: [
            {
              bgimg:
                "http://img4.imgtn.bdimg.com/it/u=3471015490,2905080736&fm=26&gp=0.jpg",
              id: 1,
              name: "珠三角工程",
            },
            {
              bgimg:
                "http://img4.imgtn.bdimg.com/it/u=3471015490,2905080736&fm=26&gp=0.jpg",
              id: 2,
              name: "珠江新城",
            },
            {
              bgimg:
                "http://img4.imgtn.bdimg.com/it/u=3471015490,2905080736&fm=26&gp=0.jpg",
              id: 3,
              name: "珠三角工程",
            },
            {
              bgimg:
                "http://img4.imgtn.bdimg.com/it/u=3471015490,2905080736&fm=26&gp=0.jpg",
              id: 3,
              name: "珠三角工程",
            },
            {
              bgimg:
                "http://img4.imgtn.bdimg.com/it/u=3471015490,2905080736&fm=26&gp=0.jpg",
              id: 3,
              name: "珠三角工程",
            },
          ],
        },
      ],
    };
  },
  created() {
    this.collect_list(localStorage.getItem("userId"));
    this.remain = [];
    this.listarray = [];
    this.getProjectVideoList();
    // this.inntRecord();
  },

  methods: {
    // initAccessRecord() {
    //     window.alert(document.referrer);
    //   let code = "";
    //   code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
    //   if (code == "") {
    //     this.logRecord();
    //   } else {
    //     let self = this;
    //     window.setTimeout(function () {
    //       self.logRecord();
    //     }, 1000);
    //   }
    // },
    inntRecord() {
      this.logRecord();
      let self = this;
      let code = "";
      code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
      if (code == "") {
        var iCount = 0;
        var testCode = window.setInterval(function () {
          let codeTest = "";
          codeTest = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
          if (codeTest != "") {
            self.logRecord();
            window.clearInterval(testCode);
            // window.alert(codeTest);
          }
          iCount++;
          if (iCount == 10) {
            window.clearInterval(testCode);
          }
        }, 500);
      }
    },
    logRecord() {
      let code = "";
      code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
      const APPID = "ww1736e9ae98ad76c9";
      axios
        .post(
          "/gdh-com-hk-digital-accessloghistorysvc/api/service/logUserAccessInfo",
          {
            corpId: APPID,
            code: code,
            appCode: "cloudOversee",
            pageCode: "site",
            pageName: "云监工",
            pageUrl: window.location.href,
          }
        )
        .then((res) => {
          //   window.alert(JSON.stringify(res));
          if (res.data.body.code == "10000") {
            this.collect_list(res.data.body.userId);
          }
          if (
            res.data != null &&
            res.data.body.body != null &&
            res.data.body.body.code != null &&
            res.data.body.body.code == "-100"
          ) {
            const local = window.location.href;
            setTimeout(() => {
              window.location.href =
                "https://wechat.gdhchina.com/connect/oauth2/authorize?appid=" +
                APPID +
                "&redirect_uri=" +
                encodeURIComponent(local) +
                "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
            }, 2000);
          }
        });
    },
    goVedioDetail(item) {
      // let BASE_URL = 'https://itest.gdhchina.com/';
      let BASE_URL = location.protocol + "//" + document.domain + "/";
      let url = encodeURIComponent(item.cam);
      window.location.href = `${BASE_URL}hls.html?cam=${url}&type=${item.type}&id=${item.id}&name=${item.videoName}`;
    },
    getProjectVideoList() {
      this.loadingShow = true;
      let msg = "";
      this.$api.site.getProjectAndeVideoList().then((res) => {
        console.log(res, "000000000000000");
        this.loadingShow = false;
        if (res.state.code == 10000) {
          // 获取数量
          this.count = res.body.projectCount;
          this.counts = res.body.videoCount;
          let list = res.body.videoList ? res.body.videoList : [];
          let num = 0;
          list.map((item, index) => {
            for (let index = 0; index < item.list.length; index++) {
              const element = item.list[index];
              element.list.forEach((val) => {
                if (val.cam.indexOf("videoBak") >= 0) {
                  num++;
                }
              });
            }
          });
          if (num) {
            this.getProjectVideoList();
          }
          this.listarray = list;
          this.cardList = list.map((item) => {
            return {
              board: item.board,
              count: item.count,
              list: item.list,
              flag: true,
              text: "收起",
            };
          });
          console.log(this.cardList);
        } else {
          Toast(msg || "获取失败，请稍后重试");
        }
      });
    },
    //收藏列表
    collect_list(userId) {
      this.loadingShow = true;
      //   let self = this;
      this.$api.site.getFavoriteList(userId).then((res) => {
        this.loadingShow = false;
        if (res.state.code == 10000) {
          this.collectList = res.body;
          this.collectListLen = res.body.length ? res.body.length : 0;
        } else {
          Toast(res.body.message);
        }
        //   self.logRecord();
      });
    },
    // 取消收藏
    cancelCollection(item) {
      //   this.$refs.card[0].collect_delete(item);
      console.log(item);
    },
    // 用户点击收起
    neatenhandler(item) {
      // console.log(item);
      if (item.flag) {
        item.flag = false;
        item.text = "展开";
      } else {
        item.flag = true;
        item.text = "收起";
      }
    },
    collectlist_click() {
      if (this.collectlist_show) {
        this.collectlist_text = "收起";
      } else {
        this.collectlist_text = "展开";
      }
      this.collectlist_show = !this.collectlist_show;
    },
  },
};
</script>

<style lang="scss" scoped>
i {
  font-style: normal;
}
.video-page {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  // top: 105px;
  top: 0px;
  bottom: 0px;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
}

.video--hd {
  width: 100%;
  background-color: var(--white);
  padding: 30px 15px;
  display: flex;
  .window-count {
    flex-basis: 46%;
    flex-grow: 1;
    height: 100%;
    padding: 15px 40px;
    box-sizing: border-box;
    background: url("../../assets/images/project/bg02.png") center/cover
      no-repeat;
    color: var(--white);
    border-radius: 5px;
    min-height: 144px;
    & + .window-count {
      margin-left: 20px;
    }
    .count {
      font-size: 60px;
      height: 72px;
    }
  }
}

.video-bd {
  flex-grow: 1;
  padding: 0 30px;
  //   overflow: scroll;
}
.myCollection {
  border-radius: 15px;
  padding: 15px 20px;
  margin-bottom: 30px;
  background: #fff;
  overflow: hidden;
  clear: both;
  span {
    position: relative;
    padding-left: 25px;
    display: block;
    &::before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      display: inline-block;
      width: 10px;
      background-color: var(--main);
    }
  }
}
.item_list {
  margin-top: 30px;
  overflow: hidden;
  clear: both;
  .item_box {
    padding: 0 10px;
    width: 33%;
    float: left;
    padding-bottom: 10px;
  }
  .item_video {
    // padding-bottom: 20px;
    overflow: hidden;
    .item_list_img {
      width: 26.5vw;
      height: 200px;
      overflow: hidden;
      display: block;
      @media screen and(min-width:700px) {
        height: 200px !important;
      }
    }

    .item_list_title {
      color: rgba(95, 97, 101, 0.9);
      font-size: 25px;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
      padding-top: 10px;
      padding-bottom: 15px;
    }
  }
}
.text-xs {
  .cancelCollection {
    width: 20px;
  }
}
.Heights {
  //     height: 100%;
  padding-top: 5.66667vw;
  overflow: scroll;
}
.plate {
  .operation {
    display: flex;
    justify-content: space-between;
    .title {
      font-weight: bold;
    }
    .button {
      color: blue;
      padding: 5px 10px;
    }
  }
}
.dg-flex {
  display: flex;
}
.flex-1 {
  flex: 1;
}
.i-text {
  color: blue;
  padding: 5px 10px;
}
</style>
