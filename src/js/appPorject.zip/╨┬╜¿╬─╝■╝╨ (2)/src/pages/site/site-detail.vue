<template>
  <div class="site_detail">
    <div class="loading_view" v-if="!hasData">
      <div class="loading_par" v-if="loadingShow">
        <van-loading class="loading" type="spinner" size="24px" color="#1989fa" />
      </div>
      <!-- <div class="img_list flex justify-between flex-wrap">
        <img class="site_img" src="../../assets/img/site/p1.jpg" alt="">
        <img class="site_img" src="../../assets/img/site/p2.jpg" alt="">
        <img class="site_img" src="../../assets/img/site/p3.jpg" alt="">
        <img class="site_img" src="../../assets/img/site/p4.jpg" alt="">
      </div> -->
    </div>
    <div v-if="hasData">
      <!-- <video :src="siteDetail.panoramicUrl" controls muted></video> -->
      <!-- <video class="video_play" src="../../assets/img/site/1.mp4" controls muted></video> -->
      <div class="mask">
        <div class="video_name flex justify-start">
          <p class="title">项目名称:</p>
          <p class="video_name_cont">{{siteDetail.projectName}}</p>
        </div>
        <div class="video_status flex justify-start">
          <p class="title">状态:</p>
          <p>进度正常</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {
    loading
  } from "vant"
  export default {
    components: {
      [loading.name]: loading
    },
    data() {
      return {
        hasData: true,
        img1: "../../assets/img/site/1.jpg",
        img2: "../../assets/img/site/2.jpg",
        img3: "../../assets/img/site/3.jpg",
        img4: "../../assets/img/site/4.jpg",
        siteDetail: "",
        loadingShow: true
      }
    },
    created() {
      this.getPanorama()
    },
    methods: {
      getPanorama() {
        this.loadingShow = true
        this.$api.site.getPanorama('8acf2505b7614e6393b6a6915869861c').then(res => {
          this.loadingShow = false
          this.siteDetail = res.body[0]
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .loading_view {
    position: relative;
    min-height: 100%;
  }

  .loading_par {
    text-align: center;
    line-height: 135px;
    width: 135px;
    height: 135px;
    border-radius: 30px;
    background: #fff;
    position: fixed;
    top: calc(50% - 67px);
    left: calc(50% - 67px);
  }

  // .videoPlay {
  //     width: 100%;
  //     height: 667px;
  // }
  .site_img {
    width: 50%;
    min-height: 100%;
  }

  .site_detail {
    min-width: 100%;
    min-height: 100%;
  }

  .mask {
    width: 100%;
    height: 200px;
    background: rgba(0, 0, 0, 0.1);
    font-size: 30px;
    color: rgba(255, 255, 255, 0.4);
    padding-left: 40px;
    position: fixed;
    bottom: 0px;
  }

  .video_name {
    margin: 50px 0px 30px 0px;
  }

  .video_name_cont {
    color: #fff;
  }

  .title {
    width: 130px;
    text-align: right;
  }

  video {
    height: 100%;
    width: 100%;
  }
</style>