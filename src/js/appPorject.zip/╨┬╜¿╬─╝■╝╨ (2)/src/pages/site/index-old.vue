<template>
  <div class='site'>
    <!-- <van-tabs @click="tabClick" color="#0076F0" v-model="active">
      <van-tab title="实时视频"> -->
    <!-- <div class="video flex justify-between">
          <div class="video_count margin_r">
            <p class="count">{{projectTotal?projectTotal:0}}</p>
            <p class="count_name ">工程总数</p>
          </div>
          <div class="video_count">
            <p class="count">{{videoNum?videoNum:0}}</p>
            <p class="count_name">监控在线数量</p>
          </div>
        </div> -->
    <div class="parorama">
      <p class="count_name ">监控在线数量</p>
      <p class="count">{{videoNum?videoNum:0}}<span class="nuit">个</span></p>
    </div>
    <div class="video_list">
      <!-- 我的收藏 -->
      <div class="video_item">
        <!-- <div class="item_title flex justify-between">
              <div class="item_title_cont">
                <span class="dot"></span>
                <span>我的收藏</span>
                <span>(3)</span>
              </div>
              <p class="item_more" @click="goMore()">查看更多</p>
            </div> -->
        <div class="item_list flex justify-between flex-wrap">
          <div class="item_video flex-start" v-for="(item,index) in videoList" :key="index"
            @click="goVedioDetail(item)">
            <img class="item_list_img" :src="imgUrl" alt="">
            <div>
              <p class="item_list_title">{{item.projectName}}</p>
              <p class="item_list_title">{{item.videoName}}</p>
              <p class="item_list_title">{{item.tenders}}</p>
              <p class="item_list_title" v-if="item.type==0">{{item.cam}}</p>
            </div>

          </div>
        </div>
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
    <!-- </van-tab> -->
    <!-- <van-tab title="720全景">
        <div class="overall_view">
          <van-row type="flex" justify="space-around" class="view_row">
            <van-col span="3" class="row_title">序号</van-col>
            <van-col span="12" class="row_title">项目名称</van-col>
            <van-col span="11" class="row_title">标段</van-col>
          </van-row>
          <van-row type="flex" justify="space-around" class="view_row" v-for="(item,index) in lists" :key="index"
            @click="goPanoramicUrl(item)">
            <van-col span="3" class="obj_idx row_cont">{{index+1}}</van-col>
            <van-col span="12" class="obj_name row_cont text-cut">{{item.projectName}}</van-col>
            <van-col span="11" class="step row_cont text-cut">{{item.tenders}}</van-col>
          </van-row>
        </div>
      </van-tab> -->
    <!-- </van-tabs> -->
  </div>
</template>

<script>
import loading from "../../components/loading";
import { Search, Tab, Tabs, Col, Row, Toast } from "vant";
export default {
  components: {
    loading,
    [Search.name]: Search,
    [Tab.name]: Tab,
    [Tabs.name]: Tabs,
    [Col.name]: Col,
    [Row.name]: Row
  },
  data() {
    return {
      imgUrl: require("../../assets/img/engineering/eng.jpg"),
      active: 0,
      videoNum: "",
      projectTotal: "",
      urls: "",
      videoList: [],
      list: [],
      loadingShow: true
    };
  },
  created() {
    // this.queryProjectList()
    this.getVideoList();
  },
  
  methods: {
    goVedioDetail(item) {
      this.loadingShow = true;
      if (item.type == 0) {
        this.$api.site.getVideoDetail(item.cam).then(res => {
          if (res.state.code === 10000) {
            if (res.body.code === 0) {
              let url = res.body.data.url;
              url = url.replace("api.welink.qq.com", "219.135.193.190:8088");
              this.urls = url;
              if (url) {
                this.loadingShow = false;
              }
              url = encodeURIComponent(url);
              window.location.href =
                "https://dt.gdhchina.com/hls.html?url=" + url;
              this.initVideo(url);
            } else {
              Toast("码流地址获取失败！");
              this.loadingShow = false;
            }
          } else {
            Toast("暂无数据");
            this.loadingShow = false;
          }
        });
      } else if (item.type == 1) {
        this.loadingShow = false;
        let url=encodeURIComponent(item.cam)
        window.location.href = `https://dt.gdhchina.com/hls.html?url=${url}`;
      }
    },
    //获取视频列表
    getVideoList() {
      this.loadingShow = true;
      this.$api.site.getVideoList().then(res => {
        this.loadingShow = false;
        if (res.state.code === 10000) {
          this.videoNum = res.body.totalCount;
          this.videoList = [];
          res.body.list.forEach(element => {
            this.videoList.push(element.videoCofing);
          });
          // console.log(this.videoList, "videoList--------");
        }
      });
    },
    // 全景详情
    goPanoramicUrl(item) {
      window.location.href = item.panoramicUrl;
    },
    // 720全景列表
    queryProjectList(params = {}) {
      this.$api.site.get720list(params).then(res => {
        if (res.state.code === 10000) {
          this.projectTotal = res.body.totalCount;
          res.body.list.forEach(element => {
            this.list.push(element.panorama);
          });
        }
      });
    },
    getSearchParams(data) {
      this.queryProjectList(data);
    },
    tabClick(e) {
      this.active = e;
    },
    stageConfirm() {},
    onSearch() {},
    //查看更多
    goMore() {
      this.$router.push({
        name: "more",
        query: {
          type: "more"
        }
      });
    }
  }
};
</script>
<style lang='scss' scoped>
/deep/.van-hairline--top-bottom::after,
.van-hairline-unset--top-bottom::after {
  width: 0;
}

.video_count {
  background: url("../../assets/img/vacation/banner2.png");
  background-size: cover;
}

.site {
  margin: 20px;
}

.parorama {
  background: url("../../assets/img/vacation/banner2.png");
  background-size: cover;
  height: 250px;
  border-radius: 10px;
  padding: 20px 0px 20px 40px;
  width: 100%;
  color: #fff;
  margin: 20px 0px;

  .count_name {
    font-size: 38px !important;
  }

  .count {
    font-size: 60px !important;
    text-align: center;
    margin-top: 40px;
  }
}
.nuit {
  font-size: 36px;
  margin-left: 5px;
  position: relative;
  top: -5px;
}
@import "./css/index.scss";
</style>