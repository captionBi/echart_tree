<template>
  <div class="card-item">
    <div class="card-item--dh">
      <div class="item--dh--title text-sub text-df">
        {{dataItem.projectName}}
        <span>({{dataItem.count}})</span>
      </div>
      <!-- <a class="item--dh--more text-df" v-if="showMore" @click="clickMore">{{currentMoreText}}</a> -->
    </div>
    <div class="card-item--bd">
      <template v-if="dataItem.list && dataItem.list.length>0">
        <div class="card-sub" v-for="(child,index) in dataItem.list" :key="child.id" :id="index">
          <div class="card_box" @click="goVedioDetail(child)">
            <img :src="child.bgImg?child.bgImg:require('../../../assets/img/site/collectImg.jpg')" class="card-sub--img" />
            <p class="card-sub--text text-sub text-sm text-cut">{{child.videoName}}</p>
          </div>
          <div class="text-xs flex-between text-gray">
            <span>点击量: {{child.clicks}}</span>
            <p class="flex-center" @click="collect_save(child)">
              <span>收藏</span>
              <!-- <img :src="(index%2)==1?noimgsrc:imgsrc" alt="" class="collection" @click="collect_fun(child)"> -->
              <img
                :src="child.isCollect?imgsrc:noimgsrc"
                alt
                class="collection" />
            </p>
          </div>
        </div>
        <!-- <div class="card-sub" v-for="(child,index) in item.list" :key="child.id" :id="index"
          @click="goVedioDetail(child)">
          <img :src="child.bgImg" class="card-sub--img" />
          <span class="card-sub--text text-sub text-df text-cut">{{child.projectName}}</span>
        </div>-->
      </template>
      <p v-else class="no-data">暂无数据</p>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>


<script>
import loading from "@/components/loading";
import { Toast } from "vant";
export default {
  components: { loading },
  data() {
    return {
      loadingShow: false,
      dataItem: {},
      imgsrc: require("../../../assets/img/site/collection.png"),
      noimgsrc: require("../../../assets/img/site/nocollection.png"),
    };
  },
  props: {
    item: {
      type: Object,
      default: () => ({}),
    },
    showMore: {
      type: Boolean,
      default: false,
    },
    moreText: {
      type: String,
      default: "",
    },
  },
  computed: {
    currentMoreText() {
      return this.moreText || "滑动查看更多";
    },
  },
  mounted() {
    this.dataItem = this.item;
    // console.log(this.dataItem);
  },
  methods: {
    //更多
    clickMore() {
      return;
    },
    // 跳转到播放器页面（public里面的hls.html）
    goVedioDetail(item) {
      let BASE_URL = location.protocol + "//" + document.domain + "/";
      let url = encodeURIComponent(item.cam);
      window.location.href = `${BASE_URL}hls.html?cam=${url}&type=${item.type}&id=${item.id}&name=${item.videoName}`;

      // let BASE_URL = 'https://itest.gdhchina.com/';
      // let BASE_URL = location.protocol + "//" + document.domain + "/"; //'https://dt.gdhchina.com/';
      // let url = encodeURIComponent(item.cam);
      // window.location.href = `${BASE_URL}hls.html?cam=${url}&type=${item.type}`;

      // this.loadingShow = true;
      // if (item.type == 0) {
      //   this.$api.site.getVideoDetail(item.cam).then(res => {
      //     if (res.state.code === 10000) {
      //       if (res.body.code === 0) {
      //         let url = res.body.data.url;
      //         url = url.replace("api.welink.qq.com", "219.135.193.190:8088");
      //         this.urls = url;
      //         if (url) {
      //           this.loadingShow = false;
      //         }
      //         url = encodeURIComponent(url);
      //         window.location.href = `${BASE_URL}hls.html?url=${url}`;
      //         this.initVideo(url);
      //       } else {
      //         Toast("码流地址获取失败！");
      //         this.loadingShow = false;
      //       }
      //     } else {
      //       Toast("暂无数据");
      //       this.loadingShow = false;
      //     }
      //   });
      // } else if (item.type == 1) {
      //   this.loadingShow = false;
      //   let url = encodeURIComponent(item.cam)
      //   window.location.href = `${BASE_URL}hls.html?url=${url}`;
      // }
    },

    //点击收藏
    collect_save(child){
      this.$api.site.collectCollect({
        videoCollect: {
        //   userId: window.localStorage.getItem('userId'),
        //   userName: window.localStoe.getItem('userName'),
          videoId: child.id,
        }
      }).then(res=>{
        //   window.alert(child.id,"视频ID")
        if(res.state.code == 10000){
          this.$emit('collectList')
          Toast('操作成功');
        }else{
          Toast(res.body?res.body.message:'')
        }
      })
    },
    //取消收藏
    collect_delete(item){
      this.$api.site.collectDelete({
        id: item.id
      }).then(res=>{
        if(res.state.code == 10000){
          this.$emit('collectList')
          Toast('取消成功');
        }else{
          Toast(res.body?res.body.message:'')
        }
      })
    },
  },
};
</script>

<style lang="scss" scoped>
.card-item {
  background-color: var(--white);
  padding: 15px 20px;
  border-radius: 20px;
  width: 100%;
  clear: both;
  overflow: hidden;
  margin-bottom: 2vw;
  .card-item--dh {
    position: relative;
    .item--dh--title {
      padding-left: 25px;
      &::before {
        content: "";
        position: absolute;
        left: 0;
        top: 3px;
        bottom: 3px;
        display: inline-block;
        width: 10px;
        background-color: var(--main);
      }
    }
    .item--dh--more {
      position: absolute;
      top: 0;
      right: 0;
      color: var(--main);
      z-index: 10;
    }
  }
  .card-item--bd {
    padding-top: 25px;
    // display: block;
    margin-left: -20px;
    display: flex;
    justify-content: flex-start;
    flex-wrap: wrap;
    // overflow-y: hidden;
    // overflow-x: scroll;

    .card-sub {
      margin-left: 20px;
      width: 30%;
      // flex-basis: 30%;
      flex-grow: 0;
      padding-bottom: 20px;
      .card-sub--img {
        margin-right: 20px;
        width: 26.5vw;
        margin-bottom: 10px;
        height: 200px;
        background-color: #eee;
        border: none;
        @media screen and(min-width:700px){ height: 200px !important; }
      }

      .card-sub--text {
        width: 100%;
        display: block;
      }
    }
    .collection {
      width: 20px;
      margin-left: 10px;
    }
  }
  .no-data {
    font-size: 0.8rem;
    color: #666;
    text-align: center;
  }
}
.card_box {
  overflow: hidden;
  clear: both;
}
</style>
