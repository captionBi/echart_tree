<template>
    <div class="more">
        <div class="video_list">
            <div class="video_item">
                <div class="item_title flex justify-between">
                    <div class="item_title_cont">
                        <span class="dot"></span>
                        <span>我的收藏</span>
                        <span>({{listLen}})</span>
                    </div>
                </div>
                <div class="item_list">
                    <template v-if="list&&list.length>0">
                        <div class="item_box" v-for="(item,index) in list" :key="index">
                            <div class="item_video" @click="goVedioDetail(item)">
                                <img class="item_list_img" :src="item.bgImg?item.bgImg:require('../../assets/img/site/collectImg.jpg')" alt="">
                                <p class="item_list_title">{{item.videoName}}</p>
                            </div>
                        </div>
                    </template>
                    <div class="no_collect" v-else>暂无收藏</div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        components: {

        },
        data() {
            return {
                list: [],
                listLen: 0,
                list2: [
                    {
                        videoCofing: {
                            cam: "200900000000002464",
                            createDate: "2020-07-01 11:18:35",
                            createUser: "anonymousUser",
                            createUserName: "匿名用户",
                            id: "d6c61b4e5f9a445888c1081a125b45e5",
                            projectId: "81719f75231741708ed07f9e824401d7",
                            projectName: "珠三角水资源配置工程",
                            tenantId: "",
                            tenders: "A2标",
                            updateDate: "2020-07-01 11:18:35",
                            updateUser: "anonymousUser",
                            updateUserName: "匿名用户",
                            version: 1,
                            videoName: "A2标-2#工作井",
                        }
                    },
                    {
                        videoCofing: {
                            am: "200900000000002098",
                            createDate: "2020-07-01 11:18:00",
                            createUser: "anonymousUser",
                            createUserName: "匿名用户",
                            id: "a3260c6e9004458ab2bc18811eefce39",
                            projectId: "81719f75231741708ed07f9e824401d7",
                            projectName: "珠三角水资源配置工程",
                            tenantId: "",
                            tenders: "C1标",
                            updateDate: "2020-07-01 11:18:00",
                            updateUser: "anonymousUser",
                            updateUserName: "匿名用户",
                            version: 1,
                            videoName: "C1标-TBM-制高点球机",
                        }
                    }
                ]
            }
        },
        mounted() {
            this.getCollection();
        },
        methods: {
            getCollection(){
                let str = window.localStorage.getItem('collection');
                this.list = str&&str.length>0?JSON.parse(str):[];
                this.listLen = this.list.length;
                // console.log(this.list)
            },
            // 全景详情
            goVedioDetail(item) {
                // let BASE_URL = 'https://itest.gdhchina.com/';
                let BASE_URL =  location.protocol + "//" + document.domain + "/";//'https://dt.gdhchina.com/';
                let url = encodeURIComponent(item.cam)
                window.location.href = `${BASE_URL}hls.html?cam=${url}&type=${item.type}`;
            },
            playVideo(i) {
                this.$router.push({
                    name: "site-detail",
                    query: {
                        index: i
                    }
                })
            }
        }
    }
</script>
<style lang="scss" scoped>
    .video_list {
        padding: 0px 20px;
        margin-top: 32px;

        .dot {
            display: inline-block;
            height: 36px;
            width: 10px;
            background: #0075EF;
            position: absolute;
            left: -15px;
            top: 0;
        }

        .item_more {
            color: rgba(0, 117, 239, 1);
            font-size: 32px;
        }

        .item_title_cont {
            color: rgba(95, 97, 101, .9);
            font-size: 32px;
            position: relative;
        }

        .video_item {
            padding: 26px 10px;
            border-radius: 10px;
            background: #fff;
            margin-bottom: 16px;
            overflow: hidden;
        }

        .item_list {
            margin-top: 39px;
            .item_box{
                padding: 0 10px;
                width: 33%;
                float: left;
                overflow: hidden;
            }
            .item_video {
                // padding-bottom: 20px;
                overflow: hidden;
                .item_list_img {
                    width: 26.5vw;
                    height: 21.33333vw;
                    overflow: hidden;
                }

                .item_list_title {
                    color: rgba(95, 97, 101, .9);
                    font-size: 30px;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    padding-top: 15px;
                    padding-bottom: 40px;
                }
            }

        }
    }
    .no_collect{
        font-size: 0.8rem;
        font-family: '微软雅黑';
        text-align: center;
    }
</style>