<template>
  <div class="legalContract">
    <div class="flexDiv">
      <div :class="typesShow === 1 ? 'activeClass' : ''">合同签订统计</div>
      <!-- <div @click="typeClick(1)" :class="typesShow === 1 ? 'activeClass' : ''">
        合同签订统计
      </div>
      <div @click="typeClick(2)" :class="typesShow === 2 ? 'activeClass' : ''">
        合同履约的统计
      </div> -->
    </div>
    <div class="timeDiv">
      <div><img src="../../assets/img/sandian.png" alt="" /></div>
      <div>
        {{ typesShow === 1 ? "合同金额统计图" : "正常履约金额数量占比图" }}
      </div>
      <div @click="selectYear">
        <img src="../../assets/img/date.png" alt="" />
        <div>{{ sureTimeYear }}</div>
      </div>
    </div>
    <div class="leftDivs" v-if="typesShow === 1">
      <div class="tuClass">
        <div id="leftPicChart" style="height: 100%; width: 100%"></div>
      </div>
      <div class="contentDiv">
        <div class="topfonts">
          <div><img src="../../assets/img/fenzu.png" alt="" /></div>
          <div>签订单位: <span>全部</span></div>
        </div>
        <div class="contentData">
          <div v-for="(item, index) in oneTypeList" :key="index">
            <div>
              <div class="divColor"></div>
              <div class="months">{{ item.month }}月</div>
              <div class="nums">
                签订数量: <span>{{ item.qdsl }}</span>
              </div>
            </div>
            <div>
              <div>
                签订金额:
                <span
                  >{{ (item.qdje / 10000).toFixed(1) }} <span>万元</span></span
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="rightDivs" v-if="typesShow === 2">
      <div class="rightTuClass">
        <!-- <dbpiccom
          ids="yearChart"
          :dataList="topPicList"
          :picName="topPicName"
        ></dbpiccom> -->
        <div id="onerightChart" style="height: 200px; width: 100%"></div>
        <div id="tworightChart" style="height: 200px; width: 100%"></div>
      </div>
      <div class="rightcontentDiv">
        <div class="topfonts">
          <div><img src="../../assets/img/fenzu.png" alt="" /></div>
          <div>签订单位: <span>全部</span></div>
        </div>
        <div class="rightcontentData">
          <div v-for="(item, index) in twoTypeList" :key="index">
            <div class="tistop">
              <div class="colorDivs"></div>
              <div class="fonweig">
                <span>{{ item.zclvrwzs }}月</span> 正常履约率{{ item.zclvl }}
              </div>
            </div>
            <div class="dataTis">
              <div>
                <div class="diandian"></div>
                <div>正常履约任务总数: {{ item.zclvrwzs }}</div>
              </div>
              <div>
                <div>总金额:</div>
                <div>
                  <span>{{ item.zclvrwzje }}</span>
                </div>
              </div>
            </div>
            <div class="dataTis">
              <div>
                <div class="diandian"></div>
                <div>计划履约任务总数: {{ item.jhlvrwzs }}</div>
              </div>
              <div>
                <div>总金额:</div>
                <div>{{ item.jhlvrwzje }} <span>元</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="cover" v-if="showTimeDiv"></div>
    <div id="modal" v-if="showTimeDiv">
      <div class="stopfont">当前选择:{{ numok }}年</div>
      <div class="timecontent">
        <div class="clickleft" @click="leftTime">
          <van-icon name="arrow-left" />
        </div>
        <div class="numdiv" @click="selectTime($event)">
          <span
            :class="item == numok ? 'selectedTime' : ''"
            v-for="(item, index) in yearArray"
            :key="index"
            >{{ item }}</span
          >
        </div>
        <div class="clickright" @click="rightTime">
          <van-icon name="arrow" />
        </div>
      </div>
      <div class="funcbottom">
        <div @click="timeOkSelect">确 定</div>
        <div @click="timeCleSelect">取 消</div>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
export default {
  components: {},
  data() {
    return {
      hisName: [],
      hisDataList: [],
      topPicList: [],
      topPicName: [],
      bottomPicList: [],
      bottomPicName: [],
      twoTypeList: [],
      oneTypeList: [],
      typesShow: 1,
      junpan: 7,
      yearArray: [],
      numok: "",
      showTimeDiv: false,
      currName: "",
      sureTimeYear: "", //选择完成之后确定的时间
    };
  },
  mounted() {
    var myDate = new Date();
    var tYear = myDate.getFullYear();
    this.numok = tYear;
    this.sureTimeYear = tYear;
    let jiannewNumArry = [];
    let jianewNumArry = [];

    for (let index = 7; index >= 1; index--) {
      jiannewNumArry.push(tYear - index);
    }
    for (let index = 1; index <= 7; index++) {
      jianewNumArry.push(tYear + index);
    }
    this.yearArray = jiannewNumArry.concat(tYear).concat(jianewNumArry);
    console.log("ttttttt", this.yearArray);
    this.histypeIp();
  },
  methods: {
    currTime() {
      var myDate = new Date();
      var tYear = myDate.getFullYear();
      this.numok = tYear;
      this.sureTimeYear = tYear;
    },
    _dySum(list) {
      let dySum = 0,
        arr = [];
      list.map((item) => {
        dySum += Number(item.value);
      });

      list &&
        list.map((item) => {
          let val = ((Number(item.value) / dySum) * 100).toFixed(2);
          arr.push({
            name: item.name,
            value: val,
          });
        });
      console.log("arrarrarr", arr);
      return arr;
    },
    _getCenterData(list) {
      let dtS = this._dySum(list);

      if (this.currName !== "") {
        return (
          dtS &&
          dtS.filter((item) => {
            return item.name === this.currName;
          })
        );
      } else {
        return [dtS && dtS[0]];
      }
    },
    _colors() {
      return [
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#f3705a" }, //2
            { offset: 1, color: "#f3705a" },
          ],
          false
        ),
        new this.$echarts.graphic.LinearGradient(
          0,
          0,
          0,
          1,
          [
            { offset: 0, color: "#6ebbff" }, // 1
            { offset: 1, color: "#266dff" },
          ],
          false
        ),
      ];
    },
    pieApi(id, lists, names) {
      setTimeout(() => {
        let centerData = this._getCenterData(lists);
        let colors = this._colors();
        let myChart = this.$echarts.init(document.getElementById(id));
        let option = {
          color: colors,
          tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b}: {c} ({d}%)",
          },
          legend: {
            orient: "vertical",
            x: "letf", //可设定图例在左、右、居中
            y: "top", //可设定图例在上、下、居中
            // left: "50%",
            data: names,
          },
          series: [
            {
              name: "访问来源",
              type: "pie",
              radius: ["70%", "100%"],
              center: ["50%", "50%"],
              avoidLabelOverlap: false,
              hoverAnimation: false,
              label: {
                show: false,
                position: "center",
              },
              emphasis: {
                label: {
                  show: false,
                  fontSize: "30",
                  fontWeight: "bold",
                },
              },
              labelLine: {
                show: false,
              },
              data: lists,
            },
            {
              name: "内框",
              type: "pie",
              hoverAnimation: false,
              radius: ["60%", "70%"],
              center: ["50%", "50%"],
              label: {
                normal: {
                  show: true,
                  position: "center",
                  formatter: [
                    `{a|${centerData[0].name}}`,
                    `{b|${centerData[0].value + "%"}}`,
                  ].join("\n"),
                  rich: {
                    a: {
                      color: "#a8b0bb",
                      fontSize: 14,
                    },
                    b: {
                      color: "#2d75ff",
                      fontSize: 14,
                      textShadowColor: "#2d75ff",
                      margin: 10,
                      lineHeight: 24,
                    },
                  },
                },
              },
              labelLine: {
                normal: {
                  show: false,
                },
              },
              itemStyle: {
                normal: {
                  color: "#2bb0eb",
                  shadowColor: "#2bb0eb",
                  borderWidth: 9,
                  borderColor: "#d3e8ff",
                  // 	shadowBlur: 2,
                  // 	opacity:0.3
                },
              },
              data: [
                {
                  value: 100,
                  tooltip: {
                    show: false,
                  },
                },
              ],
            },
          ],
        };
        myChart.setOption(option);
        myChart.on("mouseover", (params) => {
          this.currName = params.name;
          let op = myChart.getOption();
          if (params.seriesIndex === 0) {
            let _label = {
              normal: {
                show: true,
                position: "center",
                formatter: [
                  `{a|${params.name}}`,
                  `{b|${params.percent + "%"}}`,
                ].join("\n"),
                rich: {
                  a: {
                    color: "#a8b0bb",
                    fontSize: 14,
                  },
                  b: {
                    color: "#2d75ff",
                    fontSize: 14,
                    textShadowColor: "#2d75ff",
                    margin: 10,
                    lineHeight: 24,
                  },
                },
              },
            };

            op.series[1].label = _label;
            myChart.setOption(op, true);
          }
        });
      }, 200);
    },
    typeClick(e) {
      this.typesShow = e;
      this.currTime();
      if (e === 1) {
        this.histypeIp();
      } else {
        this.picTypeIp();
      }
    },
    histypeIp() {
      this.$api.legalcontract
        .hasContractSign(this.sureTimeYear)
        .then((data, index) => {
          console.log("sdadad");
          this.hisName = data.body.values;
          this.hisDataList = data.body.xList;
          this.oneTypeList = data.body.dataList;
          this.$nextTick(() => {
            this.hisClick(this.hisName, this.hisDataList);
          });
        });
    },
    picTypeIp() {
      this.$api.legalcontract
        .hasContractPer(this.sureTimeYear)
        .then((data, index) => {
          this.topPicList = data.body.moneys.jeList;
          this.topPicName = data.body.moneys.jeNames;
          this.bottomPicList = data.body.counts.countList;
          this.bottomPicName = data.body.counts.countNames;
          this.twoTypeList = data.body.dataList;
          this.$nextTick(() => {
            this.pieApi("onerightChart", this.topPicList, this.topPicName);
            this.pieApi(
              "tworightChart",
              this.bottomPicList,
              this.bottomPicName
            );
          });
        });
    },
    selectYear() {
      this.showTimeDiv = true;
    },
    timeOkSelect() {
      this.showTimeDiv = false;
      this.sureTimeYear = this.numok;
      if (this.typesShow === 1) {
        this.histypeIp();
      } else {
        this.picTypeIp();
      }
    },
    timeCleSelect() {
      this.showTimeDiv = false;
    },
    leftTime() {
      let smallNum = this.yearArray[0];
      let smallNumArry = [];
      for (let index = 15; index >= 1; index--) {
        smallNumArry.push(smallNum - index);
      }
      this.yearArray = smallNumArry;
    },
    rightTime() {
      let bigNum = this.yearArray[14];
      let bigNumArry = [];
      for (let index = 1; index <= 15; index++) {
        bigNumArry.push(bigNum + index);
      }
      this.yearArray = bigNumArry;
    },
    selectTime(even) {
      console.log("ssssssss", even.target.innerHTML);
      this.numok = even.target.innerHTML;
    },
    hisClick(list, name) {
      setTimeout(() => {
        let myChart = this.$echarts.init(
          document.getElementById("leftPicChart")
        );
        let option = {
          color: [
            new this.$echarts.graphic.LinearGradient(
              0,
              0,
              0,
              1,
              [
                { offset: 0, color: "#327bfa" }, // 1
                { offset: 1, color: "#77a6f8" },
              ],
              false
            ),
          ],
          xAxis: {
            type: "category",
            splitLine: { show: false },
            data: name,
          },
          yAxis: {
            type: "value",
            axisLabel: {
              formatter: function () {
                return "";
              },
            },
            splitLine: { show: false },
            axisLine: {
              show: false,
            },

            axisTick: {
              show: false,
            },
          },
          grid: {
            left: "3%",
            right: "3%",
            bottom: "20%",
            top: "10%",
            containLabel: true,
          },
          tooltip: {
            formatter: (res) => {
              return `${res.name}月 <br/>${(res.value / 10000).toFixed(1)}万元`;
            },
          },
          dataZoom: [
            {
              type: "inside",
              show: true,
              realtime: true,
              start: 1,
              end: 50,
            },
            {
              type: "slider",
            },
          ],
          series: [
            {
              data: list,
              type: "bar",
              showBackground: true,
            },
          ],
        };
        myChart.setOption(option);
      }, 200);
    },
  },
};
</script>

<style lang="scss" scoped>
.flexDiv {
  // position: fixed;
  // z-index: 10;
  // top: 30px;
  // left: 3%;
  // display: flex;
  height: 80px;
  line-height: 80px;
  width: 100%;
  background: white;
  box-shadow: 0px 10px 50px 0px rgba(0, 0, 0, 0.1);
  & > div {
    text-align: center;
    color: #aeb0c4;
    font-size: 28px;
  }
}
.activeClass {
  height: 80px;
  line-height: 80px;
  background: #3c8bfb;
  // border-radius: 16px 16px 0 0;
  // position: relative;
  // top: -20px;
  color: white !important;
}
.timeDiv {
  // margin-top: 120px;
  display: flex;
  padding: 0 20px;
  align-items: center;
  background: #f7f8fd;
  height: 100px;
  & > div:nth-child(1) {
    height: 40px;
    line-height: 40px;
    margin-right: 20px;
    img {
      width: 40px;
      height: 40px;
    }
  }
  & > div:nth-child(2) {
    flex: 1;
    color: #3899f6;
  }
  & > div:nth-child(3) {
    padding: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    box-shadow: 10px 10px 50px 10px rgba(218, 230, 248, 0.5);
    img {
      width: 30px;
      height: 30px;
      margin-right: 40px;
    }
  }
}
.leftDivs {
  .tuClass {
    background: white;
    height: 400px;
  }
  .contentDiv {
    background: white;
    padding: 20px;
    width: 100%;
    .topfonts {
      width: 100%;
      margin: 0 auto;
      display: flex;
      align-items: center;
      background: #f7f8fd;
      height: 100px;
      line-height: 100px;
      border-bottom: 1px solid #349ef6;
      & > div:nth-child(1) {
        width: 40px;
        height: 40px;
        line-height: 40px;
        margin-right: 20px;
        img {
          width: 40px;
          height: 40px;
        }
      }
      & > div:nth-child(2) {
        flex: 1;
        color: #369bf6;
        span {
          color: #ccc;
        }
      }
    }
    .contentData {
      padding-top: 20px;
      padding-bottom: 40px;
      & > div {
        display: flex;
        font-size: 26px;
        height: 80px;
        line-height: 80px;
        border-top: 1px solid #ccc;
        & > div:nth-child(1) {
          display: flex;
          .divColor {
            background: #3f92f6;
            width: 10px;
            height: 30px;
            margin-top: 25px;
          }
          .months {
            color: #3f92f6;
            margin: 0 10px;
          }
          .nums {
            color: #97aab0;
            span {
              color: #f8bd6a;
              margin-left: 10px;
            }
          }
        }
        & > div:nth-child(2) {
          flex: 1;
          margin-left: 60px;
          & > div {
            color: #97aab0;
            span {
              color: #f8bd6a;
              margin-left: 10px;
            }
          }
        }
      }
      & > div:nth-child(even) {
        background: #f7f8fd;
      }
      & > div:last-child {
        border-bottom: 1px solid #ccc;
      }
    }
  }
}
.rightDivs {
  .rightTuClass {
    width: 100%;
    background: white;
    & > div {
      padding: 20px 0;
      margin-bottom: 10px;
      border-bottom: 1px solid #ccc;
    }
  }
  .rightcontentDiv {
    background: white;
    padding: 20px;
    width: 100%;
    .topfonts {
      width: 100%;
      margin: 0 auto;
      display: flex;
      align-items: center;
      background: #f7f8fd;
      height: 100px;
      line-height: 100px;
      border-bottom: 1px solid #349ef6;
      & > div:nth-child(1) {
        width: 40px;
        height: 40px;
        line-height: 40px;
        margin-right: 20px;
        img {
          width: 40px;
          height: 40px;
        }
      }
      & > div:nth-child(2) {
        flex: 1;
        color: #369bf6;
        span {
          color: #ccc;
        }
      }
    }
    .rightcontentData {
      padding-top: 20px;
      padding-bottom: 40px;

      & > div {
        padding: 20px;
        border-top: 1px solid #ccc;
        .tistop {
          display: flex;
          font-size: 28px;
          font-weight: 600;
          color: #3c8bfb;
          .colorDivs {
            background: #3f92f6;
            width: 10px;
            height: 30px;
            margin-top: 2px;
            margin-right: 10px;
          }
          .fonweig {
            span {
              width: 40px;
            }
          }
        }
        .dataTis {
          display: flex;
          font-size: 20px;
          margin-top: 12px;
          & > div {
            display: flex;
            align-items: center;
          }
          & > div:nth-child(1) {
            width: 60%;
            .diandian {
              width: 4px;
              height: 4px;
              margin-right: 10px;
              background: #367fff;
              border-radius: 50%;
            }
          }
          & > div:nth-child(2) {
            flex: 1;
            text-align: right;
            & > div:nth-child(2) {
              color: #f6aa3f;
            }
          }
        }
      }
      & > div:nth-child(even) {
        background: #f7f8fd;
      }
      & > div:last-child {
        border-bottom: 1px solid #ccc;
      }
    }
  }
}
.timeBox {
  position: fixed;
  top: 20%;
  left: 10%;
  width: 80%;
  height: 400px;
  background: white;
  border-radius: 18px;
}
#cover {
  position: absolute;
  left: 0px;
  top: 0px;
  background: rgba(0, 0, 0, 0.4);
  width: 100%; /*宽度设置为100%，这样才能使隐藏背景层覆盖原页面*/
  height: 100%;
  filter: alpha(opacity=60); /*设置透明度为60%*/
  opacity: 0.6; /*非IE浏览器下设置透明度为60%*/
  display: block;
  z-index: 999;
}
#modal {
  position: absolute;
  top: 20%;
  left: 5%;
  width: 90%;
  height: 450px;
  background: white;
  border-radius: 18px;
  display: block;
  cursor: pointer;
  z-index: 9999;
  .stopfont {
    text-align: center;
    height: 80px;
    line-height: 80px;
  }
  .timecontent {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
    .clickleft {
      width: 10%;
      text-align: center;
      font-size: 42px;
      font-weight: 600;
    }
    .numdiv {
      width: 100%;
      flex: 1;
      display: flex;
      justify-content: space-between;
      flex-direction: row;
      flex-wrap: wrap;
      & > span {
        width: 20%;
        height: 80px;
        line-height: 80px;
        text-align: center;
      }
    }
    .clickright {
      width: 10%;
      text-align: center;
      font-size: 42px;
      font-weight: 600;
    }
  }
  .funcbottom {
    width: 100%;
    display: flex;
    justify-content: center;
    border-top: 1px solid #ccc;
    padding-top: 20px;
    & > div {
      width: 120px;
      height: 80px;
      line-height: 80px;
      border: 1px solid #ccc;
      text-align: center;
      border-radius: 18px;
    }
    & > div:nth-child(1) {
      background: #2870ff;
      color: white;
      margin-right: 20px;
      width: 40%;
    }
    & > div:nth-child(2) {
      width: 40%;
    }
  }
}
.selectedTime {
  border-radius: 16px;
  background: red;
  color: white;
}
</style>
