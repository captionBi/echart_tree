<template>
  <div class='progress'>
    <screen @searchParams='getSearchParams' @chooseItem='chooseItem' @cancle='cancle'></screen>
    <div class="panel">
      <van-tabs @click="tabClick" color="#0076F0" v-model="active">
        <van-tab title="计划投资">
          <div class="plan">
            <div class="flex-center padding">
              <div class="padding-lr">
                <div><img src="../../assets/images/progress/total.png" alt="" class="plan_img"></div>
                <p> <span class="text-main text-xl">{{investmentData.totalCount | currency}}</span><span
                    class="text-sm">万元</span></p>
                <p class="text-dfs margin-top-xs">总投资</p>
              </div>
              <div class="padding-lr">
                <div><img src="../../assets/images/progress/year.png" alt="" class="plan_img"></div>
                <p> <span class="text-green text-xl">{{investmentData.yearCount| currency}}</span><span
                    class="text-sm">万元</span></p>
                <p class="text-dfs  margin-top-xs">本年投资</p>
              </div>
            </div>
            <div class="bg-grey padding-top text-main">
              <p class="plan_title">累计投资与总投资的比例</p>
              <div id="myChart" :style="{height: height+'px'}"></div>
            </div>
          </div>
        </van-tab>
        <van-tab title="实际投资">
          <div class="plan">
            <div class="flex-center padding">
              <div class="padding-lr-sm">
                <div><img src="../../assets/images/progress/total.png" alt="" class="plan_img"></div>
                <p> <span
                    class="text-main text-xl">{{investmentDatas.topData.totalInvestmentCount | currency}}</span><span
                    class="text-sm">万元</span></p>
                <p class="text-dfs margin-top-xs">累计投资</p>
              </div>
              <div class="padding-lr-sm">
                <div><img src="../../assets/images/progress/year.png" alt="" class="plan_img"></div>
                <p> <span
                    class="text-green text-xl">{{investmentDatas.topData.totalInvestmentYearCount | currency}}</span><span
                    class="text-sm">万元</span></p>
                <p class="text-dfs margin-top-xs">本年投资</p>
              </div>
              <div class="padding-lr-sm">
                <div><img src="../../assets/images/progress/year.png" alt="" class="plan_img"></div>
                <p> <span
                    class="text-purple text-xl">{{investmentDatas.topData.totalInvestmentMonthCount | currency}}</span><span
                    class="text-sm">万元</span></p>
                <p class="text-dfs margin-top-xs">本月投资</p>
              </div>
            </div>
            <div class="bg-grey padding-top text-main">
              <p class="plan_title plan_title_min">月投资进度</p>
              <div id="month" :style="{height: height+'px'}"></div>
            </div>
            <div class="bg-grey padding-top text-main">
              <p class="plan_title plan_title_min">年投资进度</p>
              <div id="year" :style="{height: height+'px'}" class="chart"></div>
            </div>
            <div class="bg-grey padding-top text-main">
              <p class="plan_title plan_title_min">累计投资进度</p>
              <div id="total" :style="{height: height+'px'}" class="chart"></div>
            </div>
          </div>
        </van-tab>
        <van-tab title="形象进度">
          <div v-if="tab3" class="text-center  margin-top-xxl">
            {{html}}
          </div>
          <div class="plan" v-if="!tab3">
            <div class="flex-between padding">
              <div class="padding-lr-sm">
                <div><img src="../../assets/images/progress/total.png" alt="" class="plan_img"></div>
                <p class="text-dfs margin-top-xs step_title">年度进度计划展示</p>
              </div>
              <div class="padding-lr-sm">
                <div><img src="../../assets/images/progress/year.png" alt="" class="plan_img"></div>
                <p class="text-dfs margin-top-xs step_title">实际进度情况展示</p>
              </div>
            </div>
            <div class="steps">
              <div class="step_item flex justify-between" v-for="(item,index) in stepList1" :key="index">
                <div class="item_left">
                  <div class="item_title">
                    <span class="idx">{{index+1}}</span>
                    <span class="item_time">{{item.plan.imagePlanTime}}</span>
                  </div>
                  <div class="left_cont">{{item.plan.imagePlanContent}}</div>
                </div>
                <div class="item_center">
                  <div class="item_dot"></div>
                  <div class="item_line" v-if="index<(stepList1.length-1)"></div>
                </div>
                <div>
                  <div class="item_right" v-for="(ite,idx) in item.progresses" :key="idx">
                    <!-- {{ite}} -->
                    <div class="item_status" @click="detailShow(ite,idx)">
                      <span class="item_arrow" :class="ite.imageStatus==0?'item_arrow_red':'item_arrow_green'"></span>
                      <span class="status"
                        :class="ite.imageStatus==0?'item_dot_red':'item_dot_green'">{{ite.imageStatus==0?'未完成':'已完成'}}</span>
                      <span :class="ite.tag?'item_arrow_t':'item_arrow_b'"></span>
                    </div>
                    <div class="right_cont" v-if="ite.tag">
                      <div class="item_title" v-if="ite.imageStatus==0">
                        <span class="item_det">{{ite.delayTime}}</span>
                      </div>
                      <div>{{ite.imageProgressTime}}</div>
                      <div class="right_detail">{{ite.imageRealContent}} </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </van-tab>
      </van-tabs>
    </div>
    <loading v-show="loading" />
  </div>
</template>
<script>
  import screen from '../../components/screen'
  import loading from "../../components/loading";
  import {
    Search,
    Tab,
    Tabs,
    Toast
  } from 'vant';
  // import { thistle } from 'color-name';
  export default {
    components: {
      screen,
      loading,
      [Search.name]: Search,
      [Tab.name]: Tab,
      [Tabs.name]: Tabs,
      [Toast.name]: Toast,
    },
    data() {
      return {
        ljCount: 0, //累计投资
        zCount: 0, //总投资
        loading: false,
        active: 2,
        height: 280,
        option: '',
        itemArrow: 0,
        investmentData: {
          totalCount: '',
          yearCount: '',
        },

        investmentDatas: {
          monthInvestment: '',
          topData: {
            totalInvestmentCount: '',
            totalInvestmentYearCount: '',
            totalInvestmentMonthCount: ''
          },
          yearInvestment: {
            monthData: [],
            investmentPlanCount: "",
          },
          totalInvestment: ""
        },
        html: '请选择筛选单个项目查看数据~',
        actualMonthData: '',
        actualYearData: '',
        actualTotalData: '',
        stepList1: [],
        tab3: true,
        pID: '',
      }
    },
    created() {
      // this.getData({
      //   projectName: ""
      // }, 0)
      // this.getDatas({
      //   projectName: ""
      // }, 1)

      this.getStep('3accff1fc2164d52a70cb2d6529c3d59')
    },
    mounted() {},
    methods: {
      cancle() {
        if (this.active === 0) {
          this.getData({}, this.active)
        } else if (this.active === 1) {
          this.getDatas({}, this.active)
        }
      },
      chooseItem(data) {
        let id = data.id
        // let array = [data]
        if (this.active == 2) {
          this.getStep(id)
        } else if (this.active === 0) {
          this.getData({
            projectName: data.projectName
          }, this.active)
        } else if (this.active === 1) {
          this.getDatas({
            projectName: data.projectName
          }, this.active)
        }
      },
      // 获取形象进度
      getStep(id) {
        this.$api.progress.steps(id).then(res => {
          if (res.state.code === 10000) {
            res.body.map(item => {
              this.tab3 = false
              let len = item.progresses.length
              item.progresses.map(ite => {
                ite.tag = false
              })
              item.progresses = item.progresses.sort((a, b) => a.node - b.node)
              item.progresses = [item.progresses[len - 1]]
            })
            this.stepList1 = res.body
          } else {
            this.html = "暂无数据"
          }

        })
      },
      // 切换
      tabClick(e) {
        this.active = e
        if (e == 1) {
          this.getDatas(this.datas, this.active)
        } else if (e == 2) {
          this.tab3 = false
        } else {
          this.getData(this.datas, this.active)
        }
      },
      // 筛选
      getSearchParams(data) {
        this.datas = data
        if (data.projectName && data.projectName.length) return
        if (this.active === 0) {
          this.getData(data, this.active)
        } else if (this.active === 1) {
          this.getDatas(data, this.active)
        }

      },
      // 获取数据
      // 计划投资
      getData(params = {}) {
        this.$api.progress.investment(params, this.active).then(res => {
          this.loading = false
          if (res.state.code === 10000) {
            this.investmentData = res.body;
            this.zCount = res.body ? res.body.totalCount : 0;
            let planDatas = [{
              value: this.ljCount,
              name: '累计投资'
            }, {
              value: (this.zCount - this.ljCount),
              name: '总投资'
            }]
            this.$nextTick(function () {
              this.drawPieChart(['#3274FF', '#FEA700'], 'myChart', planDatas)
            })
          }
        })
      },
      
      //实际投资
      getDatas(params = {}) {
        this.$api.progress.investment(params, this.active).then(res => {
          this.loading = false
          if (res.state.code === 10000) {
            this.investmentDatas = res.body;
            this.ljCount = res.body ? res.body.totalInvestment.investmentFinishCount : 0;
            // this.investmentDatas = {
            //   "monthInvestment": {
            //     "totalInvestmentMonthCount": 100,
            //     "investmentPlanCount": 989858
            //   },
            //   "topData": {
            //     "totalInvestmentYearCount": 257468,
            //     "totalInvestmentCount": 1580937,
            //     "totalInvestmentMonthCount": 100
            //   },
            //   "yearInvestment": {
            //     "monthData": [{
            //         "month": 6,
            //         "count": 100,
            //         percent: 2054,
            //       },
            //       {
            //         "month": 5,
            //         "count": 103629,
            //         percent: 3253,
            //       }
            //     ],
            //     "investmentPlanCount": 989858
            //   },
            //   "totalInvestment": {
            //     "investmentFinishCount": 1580937,
            //     "investmentCount": 4500283
            //   }
            // }


            // 月投资
            this.actualMonthData = [{
                value: this.investmentDatas.monthInvestment.totalInvestmentMonthCount,
                name: '本月累计投资额'
              },
              {
                value: (this.investmentDatas.monthInvestment.investmentPlanCount - this.investmentDatas
                  .monthInvestment.totalInvestmentMonthCount),
                name: '本年计划投资额'
              }
            ]

            // 累计投资
            this.actualTotalData = [{
                value: parseInt(this.investmentDatas.totalInvestment.investmentCount),
                name: '剩余未完成投资'
              },
              {
                value: parseInt(this.investmentDatas.totalInvestment.investmentFinishCount),
                name: '累计已完成投资'
              }
            ]
            // 年投资
            let list = this.investmentDatas.yearInvestment.monthData.sort((a, b) => a.month - b.month)
            list.map(item => {
              item.percent = (item.count / parseInt(this.investmentDatas.yearInvestment.investmentPlanCount) *
                  100)
                .toFixed(0)
            })
            let months = list.map(n => `${n.month}月`);
            let counts = list.map(n => n.count + "");
            let percents = list.map(n => n.percent);
            let array = []
            for (var i = 0; i < list.length; i++) {
              array.push(this.investmentDatas.yearInvestment.investmentPlanCount)
            }
            this.actualYearData = {
              months: months,
              value: counts,
              percents: percents,
              array: array
            }
            this.$nextTick(function () {
              this.drawPieChart(['#945CDE', '#00CEC5'], 'month', this.actualMonthData)
              this.drawBArChart()
              this.drawPieChart(['#F19D0A', '#4D84F7'], 'total', this.actualTotalData)
            })
          }
        })
      },
      drawPieChart(color, id, datas) {
        let monthChart = this.$echarts.init(document.getElementById(id));
        let array = []
        datas.map(item => {
          array.push(item.name)
          if (item.name == "总投资" || item.name == "本年计划投资额" || item.name == '剩余未完成投资') {
            item.label = {
              show: false
            }
            item.labelLine = {
              show: false
            }
          }
        })
        this.option = {
          // tooltip: {
          //   trigger: 'item',
          //   formatter: '{b}: {c}%'
          // },
          clickable: false,
          color: color,
          // legend: {
          //   x: 'center',
          //   bottom: '15',
          //   icon: 'rect',
          //   itemWidth: 15,
          //   itemHeight: 15,
          //   itemGap: 20,
          //   data: array
          // },
          series: [{
            name: "",
            type: 'pie',
            clickable: false,
            radius: ['35%', '55%'],
            // hoverAnimation: false,
            avoidLabelOverlap: true,
            label: {
              normal: {
                show: true,
                // position: 'outer',
                // alignTo: 'edge',
                fontSize: '18',
                color: '#606266',
                margin: 25,
                formatter: function (params) {
                  return '{top|' + params.name + '}' + '\n' + '{bottom|' + params.percent.toFixed(0) + '%}'
                },
                rich: {
                  top: {
                    color: '#606266',
                    lineHeight: 10
                  },
                  bottom: {
                    color: '#606266',
                    fontSize: 18,
                    height: 40
                  }
                }
              },
            },
            labelLine: {
              show: true,
              length2: '20%',
              lineStyle: {
                color: '#D6D6D6'
              }
            },
            top: '0',
            bottom: '30',
            data: datas
          }]
        }

        monthChart.setOption(this.option)
        //设置默认选中高亮部分
        monthChart.dispatchAction({
          type: 'highlight',
          seriesIndex: 0,
          dataIndex: 0
        });
        // let index = 0; // 高亮索引
        // monthChart.dispatchAction({
        //   type: "highlight",
        //   seriesIndex: index,
        //   dataIndex: index
        // });
        // monthChart.on("click", function (e) {
        //   if (e.dataIndex == index) {
        //     monthChart.dispatchAction({
        //       type: "highlight",
        //       seriesIndex: 0,
        //       dataIndex: e.dataIndex
        //     });
        //   } else {
        //     monthChart.dispatchAction({
        //       type: "downplay",
        //       seriesIndex: e.seriesIndex,
        //       dataIndex: e.dataIndex
        //     });
        //   }

        // });
        // monthChart.on("click", function (e) {
        //   index = e.dataIndex;
        //   monthChart.dispatchAction({
        //     type: "highlight",
        //     seriesIndex: 0,
        //     dataIndex: e.dataIndex
        //   });
        // });
      },
      drawBArChart() {
        let yearChart = this.$echarts.init(document.getElementById('year'));
        var colors = ['#00CEC5', '#945CDE'];
        let option = {
          color: colors,
          right: 0,
          legend: {
            x: 'center',
            bottom: '10',
            width: '100%',
            icon: 'rect',
            itemWidth: 10,
            itemHeight: 10,
            itemGap: 20,
            data: ['本年度计划投资额', '本月投资额']
          },
          grid: {
            left: '40'
          },
          xAxis: [{
            type: 'category',
            axisTick: {
              show: false
            },
            data: this.actualYearData.months,
            axisLine: {
              lineStyle: {
                color: 'rgba(115,115,115,.5)',
              }
            },
            axisLabel: {
              rotate: 40,
              textStyle: {
                fontSize: 8,
                color: '#333'
              }
            },
            splitLine: {
              show: true,
              lineStyle: {
                color: ['#F0F0F0']
              }
            }
          }],
          yAxis: [{
            type: 'value',
            // name: '温度',
            min: 0,
            max: 100,
            // interval: 5,
            axisLine: {
              lineStyle: {
                color: 'rgba(115,115,115,.5)',
              },
            },
            axisLabel: {
              formatter: '{value}%',
              textStyle: {
                fontSize: 12,
                color: '#333'
              }
            },
            axisTick: {
              show: false
            },
          }, {
            show: false
          }],
          series: [{
              name: '本年度计划投资额',
              type: 'bar',
              barWidth: 10,
              barCategoryGap: '80%',
              yAxisIndex: 1,
              itemStyle: {
                barBorderRadius: 5
              },
              data: this.actualYearData.array
              // data: [222,323,545,767,32,324,325,554,767,645,322,32],
            },
            {
              name: '本月投资额',
              type: 'bar',
              barWidth: 10,
              barCategoryGap: '80%',
              yAxisIndex: 1,
              itemStyle: {
                barBorderRadius: 5
              },
              data: this.actualYearData.value
              // data: [111,32,434,656,43,657,787,434,878,989,324,324],
            },

            {
              name: '百分比',
              type: 'line',
              smooth: true,
              yAxisIndex: 0,
              data: this.actualYearData.percents
            }
          ]
        };
        yearChart.setOption(option)
      },
      //展示进度日志
      detailShow(item) {
        item.tag = !item.tag
      }
    },
  }
</script>
<style lang='scss' scoped>
  /deep/.van-hairline--top-bottom::after,
  .van-hairline-unset--top-bottom::after {
    width: 0;
  }

  /deep/.van-tabs__line {
    width: 30% !important;
  }

  .plan {
    text-align: center;

    .plan_img {
      width: 164px;
      height: 164px;
    }

    .plan_title {
      position: relative;
      margin: 0 auto;
      width: 50%;
      height: 50px;
      line-height: 50px;
      color: #3274ff;

      &.plan_title_min {
        width: 30%;
      }

      &::before {
        position: absolute;
        left: -130px;
        top: 25px;
        width: 130px;
        height: 4px;
        content: '';
        background: linear-gradient(90deg, rgba(111, 166, 255, 0), rgba(50, 127, 255, 1));
        opacity: 0.5;
      }

      &::after {
        position: absolute;
        right: -130px;
        top: 25px;
        width: 130px;
        height: 4px;
        content: '';
        background: linear-gradient(90deg, rgba(50, 127, 255, 1), rgba(111, 166, 255, 0));
        opacity: 0.5;
      }
    }

    .step_title {
      color: #457df7;
      font-size: 30px;
    }
  }

  // 形象进度样式
  .steps {
    background: #fff;
    margin-top: 60px;
    text-align: left;

    .step_item {
      margin-bottom: 36px;

      .item_dot_red {
        background: #f00 !important;
      }

      .item_dot_green {
        background: #0f0 !important;
      }

      .item_center {
        .item_dot {
          width: 35px;
          height: 35px;
          background: #f00;
          border-radius: 50%;
          box-shadow: 0px 0px 20px #999;
          border: 5px solid #fff;
        }

        .item_line {
          width: 10px;
          background: #427bf8;
          height: 100%;
          position: relative;
          left: 12px;
        }
      }

      .item_left,
      .item_right {
        width: 300px;
        border-radius: 10px;
        padding: 30px 20px;
        color: #417af8;
        font-size: 30px;
        font-weight: 400;
      }

      .item_left {
        background: #eaf2fc;
        height: 100%;
      }

      .item_right {
        padding-top: 0px;
      }

      .item_status {
        font-size: 32px;
        color: #fff;
        border-radius: 10px;

        .status {
          display: inline-block;
          border-radius: 10px;
          background: #f00;
          font-size: 32px;
          padding: 10px 50px 10px 20px;
        }

        .item_arrow {
          display: inline-block;
          width: 0px;
          height: 0px;
          border-left: 10px solid transparent;
          border-top: 10px solid transparent;
          border-right: 15px solid #f00;
          border-bottom: 10px solid transparent;
        }

        .item_arrow_red {
          border-right: 15px solid #f00 !important;
        }

        .item_arrow_green {
          border-right: 15px solid #0f0 !important;
        }

        .item_arrow_t {
          display: inline-block;
          width: 0px;
          height: 0px;
          border-left: 10px solid transparent;
          border-top: 10px solid transparent;
          border-right: 10px solid transparent;
          border-bottom: 10px solid #fff;
          position: relative;
          right: 32px;
          bottom: 6px;
        }

        .item_arrow_b {
          display: inline-block;
          width: 0px;
          height: 0px;
          border-left: 10px solid transparent;
          border-top: 10px solid #fff;
          border-right: 10px solid transparent;
          border-bottom: 10px solid transparent;
          position: relative;
          right: 32px;
          bottom: -4px;
        }
      }

      .idx {
        display: inline-block;
        width: 34px;
        height: 34px;
        text-align: center;
        line-height: 34px;
        border-radius: 50%;
        color: #fff;
        font-size: 28px;
        background: linear-gradient(180deg, rgba(111, 166, 255, 1), rgba(54, 112, 246, 1));
        margin-right: 18px;
      }

      .left_cont {
        margin-top: 34px;
        font-size: 25px;
        color: #606266;
        font-weight: 800;
        text-indent: 2em;
      }

      .item_det {
        color: #f00;
      }

      .right_detail {
        margin-top: 27px;
      }

      .right_cont {
        margin-top: 34px;
        font-size: 25px;
        color: #606266;
        font-weight: 800;
        background: #eaf2fc;
        padding: 30px 20px;
        border-radius: 10px;
      }
    }
  }

  .repanel {
    margin: 0px !important;
    border-radius: none;
  }
</style>