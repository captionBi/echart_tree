<template>
  <div class="base_info">
    <div>
      <div class="base_info_head flex justify-start">
        <img class="base_img basis-xs" :src="imgUrl" alt="" />
        <div class="basis-xl">
          <p class="base_info_title">{{ basicInfo.projectName }}</p>
          <div class="base_info_base flex justify-start">
            <div
              :class="
                basicInfo.projectStatus == 0 ? 'green_status' : 'red_status'
              "
            >
              <span
                class="dot"
                :class="basicInfo.projectStatus == 0 ? 'greenDot' : 'redDot'"
              ></span
              >{{ basicInfo.projectStatus == 0 ? "正常" : "已延期" }}
            </div>
            <!-- <span class="name">负责人:{{basicInfo.projectManager?basicInfo.projectManager:""}}</span> -->
            <span class="step margin-left">{{
              basicInfo.projectPeriod | projectPeriod
            }}</span>
          </div>
        </div>
      </div>
      <img class="project_img" :src="imgUrl" alt="" />
      <div class="base_detail">
        <div class="base_detail_item">
          <h1 class="h">01</h1>
          <p class="detail_title text-center">项目概况</p>
          <div class="bot_line"></div>
          <p
            class="detail_cont detail_content"
            :class="more ? 'detail_cont_hidden' : ''"
            v-html="basicInfo.projectSummary"
          >
            {{ basicInfo.projectSummary }}
          </p>
          <p class="show_more" @click="more = !more">
            {{ more ? "查看全文" : "收起" }}
          </p>
        </div>
        <div class="base_detail_item">
          <h1 class="h">02</h1>
          <p class="detail_title text-center">项目计划</p>
          <div class="bot_line"></div>
          <p
            class="detail_cont"
            :class="planMore ? 'detail_cont_hidden' : ''"
            v-html="basicInfo.projectPlan"
          >
            {{ basicInfo.projectPlan }}
          </p>
          <p class="show_more" @click="planMore = !planMore">
            {{ planMore ? "查看全文" : "收起" }}
          </p>
        </div>
        <div class="base_detail_item">
          <h1 class="h">03</h1>
          <p class="detail_title text-center">投资进度情况</p>
          <div class="bot_line"></div>
          <div id="myChart" :style="{ height: height + 'px' }"></div>
        </div>
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import loading from "@/components/loading";
export default {
  components: {
    loading,
  },
  data() {
    return {
      standSize: 150,
      imgUrl: require("../../../assets/img/engineering/eng.jpg"),
      more: true,
      planMore: true,
      id: "",
      projectName: "",
      detail: {},
      height: 220,
      data: [
        {
          name: "无",
          value: 10000,
          num: 10000 + "",
        },
        {
          name: "当月完成额",
          value: 20000,
          num: 20000 + "",
        },
        {
          name: "往月累计完成额",
          value: 30000,
          num: 30000 + "",
        },
      ],
      loadingShow: false,
      basicInfo: {
        projectManager: "",
        projectName: "",
        projectPeriod: "",
        projectPlan: "",
        projectStatus: "",
        projectSummary: "",
      },
      investmentProgressDetail: {}, //详情饼图
    };
  },
  mounted() {
    this.id = this.$route.query.id;
    this.getProjectDetail();
  },
  methods: {
    // 工程详情内容
    getProjectDetail() {
      this.loadingShow = true;
      this.$api.engineering
        .getEngineeringDetail({
          id: this.id,
        })
        .then((res) => {
          this.loadingShow = false;
          if (res.state.code === 10000) {
            let reg = /[*]/g;
            res.body.basicInfo.projectSummary = res.body.basicInfo.projectSummary.replace(
              reg,
              "<br>"
            );
            res.body.basicInfo.projectPlan = res.body.basicInfo.projectPlan.replace(
              reg,
              "<br>"
            );
            this.detail = res.body;
            this.basicInfo = res.body.basicInfo;
            let dataObj = res.body ? res.body.investmentProgressDetail : {};
            // dataObj = {
            //     nvestmentPlanCount: 323,
            //     progressMonthCount: 1111,
            //     progressMonthTotalCount: 2222,
            // }
            let planData = [
              {
                value: dataObj.progressMonthTotalCount,
                name: "往月累计完成额",
              },
              {
                value: dataObj.progressMonthCount,
                name: dataObj.specificMonth
                  ? dataObj.specificMonth + "月累计完成额"
                  : "月累计完成额",
              },
              {
                value:
                  dataObj.investmentPlanCount -
                  dataObj.progressMonthTotalCount -
                  dataObj.progressMonthCount,
                name: "无",
              },
            ];
            this.$nextTick(function () {
              this.drawChart(planData);
            });
          }
        });

      // this.loadingShow = false
      // let dataObj = {
      //     investmentPlanCount: 234323,
      //     progressMonthCount: 112213,
      //     progressMonthTotalCount: 232233,
      // }
      // let planData = [{
      //     value: dataObj.progressMonthTotalCount,
      //     name: '往月累计完成额',
      // }, {
      //     value: dataObj.progressMonthCount,
      //     name: '当月累计完成额',
      // }, {
      //     value: dataObj.investmentPlanCount,
      //     name: '无'
      // }]
      // this.$nextTick(function () {
      //     this.drawChart(planData)
      // })
    },
    // echart饼图
    drawChart(data) {
      let myChart = this.$echarts.init(document.getElementById("myChart"));
      data.map((item) => {
        if (item.name == "无") {
          item.label = {
            show: false,
          };
          item.labelLine = {
            show: false,
          };
        }
      });
      let option = {
        color: ["#945CDE", "#FEA700", "#3274FF"],
        series: [
          {
            name: "",
            type: "pie",
            radius: ["40%", "60%"],
            avoidLabelOverlap: true,
            clickable: false,
            silent: true,
            startAngle: 90,
            // minAngle: 30,
            label: {
              // position: "outside",
              // alignTo: "edge",
              fontSize: "18",
              align: "left",
              color: "#606266",
              margin: 0,
              formatter: function (a) {
                var arr = [
                  "{a|" + a.name + "}",
                  "{b|" + parseInt(a.value).toLocaleString() + "万元" + "}",
                  "{c|" + a.percent.toFixed(0) + "%" + "}",
                ].join("\n");
                return arr;
              },
              rich: {
                a: {
                  lineHeight: 16,
                  fontSize: 12,
                  align: "left",
                },
                b: {
                  lineHeight: 20,
                  fontSize: 12,
                  align: "left",
                },
                c: {
                  lineHeight: 12,
                  height: 15,
                  align: "left",
                },
              },
            },
            labelLine: {
              show: true,
              length: this.standSize / 15,
              length2: this.standSize / 10,
              lineStyle: {
                color: "#D6D6D6",
              },
            },
            data: data,
          },
        ],
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./css/base-info/base-info.scss";

.detail_cont_hidden {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 5;
  overflow: hidden;
}

.h {
  color: #949494;
  text-align: center;
  font-size: 50px;
}
</style>