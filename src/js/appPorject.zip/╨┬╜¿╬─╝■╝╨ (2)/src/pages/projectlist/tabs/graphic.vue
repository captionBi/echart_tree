<template>
  <div class="content">
    <div class="plan">
      <div class="banner">
        <img :src="require('../../../assets/images/project/banner_bg.png')" />
      </div>
      <div class="flex-between bannerTitle">
        <div class="padding-lr-sm">
          <p class="text-dfs margin-top-xs step_title">年度进度计划展示</p>
        </div>
        <div class="padding-lr-sm">
          <p class="text-dfs margin-top-xs step_title">实际进度情况展示</p>
        </div>
      </div>
      <div class="steps">
        <div class="step_item justify-between" v-for="(item,index) in stepList1" :key="index">
          <!-- 左边 -->
          <div class="item_left">
            <div class="item_title">
              <span class="idx">{{index+1}}</span>
              <span class="item_time">{{item.plan.imagePlanTime}}</span>
            </div>
            <div class="left_cont">{{item.plan.imagePlanContent}}</div>
          </div>
          <!-- 中间 -->
          <div class="item_center" v-if="index<=(stepList1.length-1)">
            <div class="item_dot" :class="index==stepListLen-1?'item_dot_big':''"></div>
            <div class="item_line" v-if="index<=(stepList1.length-2)"></div>
          </div>
          <!-- 右边盒子 -->
          <div class="wpsReport" v-if="item.progresses&&item.progresses.length>0">
            <!-- v-if="item.progresses.reportType===0? monthlyReport=true:weekly=true" -->
            <div class="item_title item_text" v-if="item.plan.imageRealTimeContent!=''">
                    <!-- <span class="item_det">{{item.delayTime}}</span>
                  </div> 
                  <div>{{item.plan}}</div>-->
                  <div class="right_detail" v-html="item.plan.imageRealTimeContent"></div>
          </div>
            <div v-for="(iten,imdex) in item.progresses" :key="imdex">
              <div class="item_right">
                <div
                  :class="iten.reportType == 1 ? 'Monthlyreport':'weekly'"
                  v-if="iten.docName != null && iten.docName != ''"
                >
                  <a :id="`docUrl_${index}_${imdex}`" href="javascript:void(null);">{{iten.docName}}</a>
                </div>
              </div>
              <div class="stealth"></div>
            </div>
          </div>
          <template v-else>
            <div class="item_right"></div>
          </template>
        </div>
      </div>
      <!-- loading -->
      <loading v-if="loadingShow"></loading>
    </div>
  </div>
</template>


<script>
import loading from "@/components/loading";
import { get } from "../../../api/config";
export default {
  components: {
    loading,
  },
  data() {
    return {
      projectId: "",
      stepList1: {},
      stepListLen: "",
      loadingShow: true,
      wpsId: {},
      item_leftbgc: 0,
      wps_document: "",
      weekly: false,
      monthlyReport: false,
      waitGetUrlIds: [],
      asdasd: false,
    };
  },
  mounted() {
    this.projectId = this.$route.query.id;
    this.getStep();
  },
  progress() {},
  methods: {
    // 获取形象进度
    getStep() {
      this.loadingShow = true;
      this.$api.progress.steps(this.projectId).then((res) => {
        console.log(res, "yiqian");
        this.loadingShow = false;
        if (res && res.state && res.state.code === 10000) {
          res.body && JSON.stringify(res.body) != "{}" ? res.body : [];
          if (res.body.length) {
            console.log(res.body, "res.body==========");
            res.body.map((item, index) => {
              let len = item.progresses.length;
              item.plan.imageRealTimeContent = "";
              item.plan.bgDivColor = "item_left";
              if (len > 0) {
                item.plan.bgDivColor = item.progresses[len - 1].imageStatus
                  ? "green"
                  : "red";
                var docWeekIndex = 0;

                // 按时间排序

                for (var i = item.progresses.length - 1; i >= 0; i--) {
                    if (item.progresses[i].imageRealContent != null && item.progresses[i].imageRealContent != "") {
                        item.plan.imageRealTimeContent += item.progresses[i].imageProgressTime + "\n" + item.progresses[i].imageRealContent + "\n";
                    }
                  if (
                    item.progresses[i].report != null &&
                    item.progresses[i].report != ""
                  ) {
                    let waitGetUrlId = {
                      id: index + "_" + i,
                      docId: item.progresses[i].report,
                    };
                    this.waitGetUrlIds.push(waitGetUrlId);
                    if (item.progresses[i].reportType == 0) {
                      docWeekIndex++;
                      item.progresses[i].docName =
                        "第" + docWeekIndex + "周周报";
                    } else if (item.progresses[i].reportType == 1) {
                      let imageProgressDateArray = item.progresses[
                        i
                      ].imageProgressTime.split("-");
                      item.progresses[i].docName =
                        imageProgressDateArray[0] +
                        imageProgressDateArray[1] +
                        "月报";
                    }
                  }
                }
                 item.plan.imageRealTimeContent =  item.plan.imageRealTimeContent.replace(/\n/g, "<br/>")
              }
            });
          }
          
          this.stepList1 = res.body;
          this.stepListLen = res.body.length;
          console.log(this.stepList1, 33333333333333);
        } else {
          this.html = "暂无数据";
        }
        if (this.waitGetUrlIds.length > 0) {
          this.setDocUrl();
        }
      });
    },
    setDocUrl() {
      this.waitGetUrlIds.map((item) => {
        this.getWps(item.id, item.docId);
      });
    },
    // 请求wps接口
    getWps(hrefId, wpsId) {
      get(
        `gdh-com-hk-digital-fileauthcomputesvc/api/service/filePreview/${wpsId}`
      ).then((res) => {
        if (res.body != null && res.body.url != null) {
          document.getElementById("docUrl_" + hrefId).href = res.body.url;
        }
      });
    },
  },
};
</script>

<style scoped lang="scss">
.plan {
  text-align: center;

  .plan_img {
    width: 164px;
    height: 164px;
  }

  .plan_title {
    position: relative;
    margin: 0 auto;
    width: 50%;
    height: 50px;
    line-height: 50px;
    color: #3274ff;

    &.plan_title_min {
      width: 30%;
    }

    &::before {
      position: absolute;
      left: -130px;
      top: 25px;
      width: 130px;
      height: 4px;
      content: "";
      background: linear-gradient(
        90deg,
        rgba(111, 166, 255, 0),
        rgba(50, 127, 255, 1)
      );
      opacity: 0.5;
    }

    &::after {
      position: absolute;
      right: -130px;
      top: 25px;
      width: 130px;
      height: 4px;
      content: "";
      background: linear-gradient(
        90deg,
        rgba(50, 127, 255, 1),
        rgba(111, 166, 255, 0)
      );
      opacity: 0.5;
    }
  }

  .step_title {
    color: #457df7;
    font-size: 38px;
    width: 170px;
    position: relative;
    padding: 25px 0;

    &::after {
      content: "";
      position: absolute;
      bottom: 0;
      width: 102px;
      left: 50%;
      margin-left: -51px;
      height: 1px;
      background: #0075ef;
    }
  }
}

.banner {
  padding: 30px 0;

  img {
    width: 100%;
    display: block;
  }
}

.bannerTitle {
  padding: 0 60px;
  .item_left {
    //   width: 300px;
      border-radius: 10px;
      padding: 30px 20px;
      color: #417af8;
      font-size: 36px;
      font-weight: 400;
    }
}

// 形象进度样式
.steps {
  background: #fff;
  margin-top: 60px;
  text-align: left;

  .step_item {
    .item_dot_red {
      background: -webkit-linear-gradient(left, #f26933, #ea3030) !important;
      background: -o-linear-gradient(right, #f26933, #ea3030) !important;
      background: -moz-linear-gradient(right, #f26933, #ea3030) !important;
      background: linear-gradient(to right, #f26933, #ea3030) !important;
    }

    .item_dot_green {
      background: -webkit-linear-gradient(left, #06c449, #08ba32) !important;
      background: -o-linear-gradient(right, #06c449, #08ba32) !important;
      background: -moz-linear-gradient(right, #06c449, #08ba32) !important;
      background: linear-gradient(to right, #06c449, #08ba32) !important;
    }

    .item_center {
      .item_dot {
        width: 35px;
        height: 35px;
        background: #f00;
        border-radius: 50%;
        box-shadow: 0px 0px 20px #999;
        border: 5px solid #fff;
      }
      .item_dot_big {
        width: 38px;
        height: 38px;
        background: #0075ef;
        border-radius: 50%;
        box-shadow: 0px 0px 20px #999;
        border: 5px solid #fff;
      }
      .item_line {
        width: 10px;
        background: #427bf8;
        height: 100%;
      }
    }

    // 

    .green {
      background-color: #08bc36 !important;
      .item_title {
        .idx {
          background: #fff;
          color: #08bc36;
          font-size: 4vw !important;
        }
        .item_time {
          color: #fff !important;
        }
      }
      .left_cont {
        color: #fff !important;
      }
    }
    .red {
      background-color: #ec3e31 !important;
      .item_title {
        color: #fff !important;
        .idx {
          background: #fff !important;
          color: red !important;
          font-size: 4vw !important;
          font-weight: 700 !important;
        }
      }
      .left_cont {
        color: #fff !important;
        font-weight: 800 !important;
        font-size: 4vw !important;
      }
    }
    .item_left {
      background: #eaf2fc;
      height: 100%;
    }

    .item_right {
      padding: 0;
    }

    .item_status {
      font-size: 32px;
      color: #fff;
      border-radius: 10px;
      position: relative;
      bottom: 18px;

      .status {
        display: inline-block;
        border-radius: 10px;
        background: #f00;
        font-size: 32px;
        padding: 10px 70px 10px 30px;
      }

      .item_arrow {
        display: inline-block;
        width: 0px;
        height: 0px;
        border-left: 10px solid transparent;
        border-top: 10px solid transparent;
        border-right: 15px solid #f00;
        border-bottom: 10px solid transparent;
      }

      .item_arrow_red {
        border-right: 15px solid #f26933 !important;
      }

      .item_arrow_green {
        border-right: 15px solid #06c449 !important;
      }

      .item_arrow_t {
        display: inline-block;
        width: 0px;
        height: 0px;
        border-left: 10px solid transparent;
        border-top: 10px solid transparent;
        border-right: 10px solid transparent;
        border-bottom: 10px solid #fff;
        position: relative;
        right: 45px;
        bottom: 6px;
      }

      .item_arrow_b {
        display: inline-block;
        width: 0px;
        height: 0px;
        border-left: 10px solid transparent;
        border-top: 10px solid #fff;
        border-right: 10px solid transparent;
        border-bottom: 10px solid transparent;
        position: relative;
        right: 45px;
        bottom: -4px;
      }
    }

    .idx {
      display: inline-block;
      width: 34px;
      height: 34px;
      text-align: center;
      line-height: 34px;
      border-radius: 50%;
      color: #fff;
      font-size: 28px;
      background: linear-gradient(
        180deg,
        rgba(111, 166, 255, 1),
        rgba(54, 112, 246, 1)
      );
      margin-right: 18px;
    }

    .left_cont {
      margin-top: 15px;
      font-size: 28px;
      color: #606266;
      font-weight: 800;
      text-indent: 2em;
    }

    .item_det {
      color: #f00;
    }

    .right_detail {
      margin-top: .2rem;
      font-size: 28px;
      font-weight: 800;
    }

    .right_cont {
      margin-top: 34px;
      font-size: 36px;
      color: #606266;
      font-weight: 400;
      background: #eaf2fc;
      padding: 30px 20px;
      border-radius: 10px;
    }
  }
  .wpsReport {
      
    .weekly {
      width: 39.33333vw;
    height: 13vw;
      background: url("../../../assets/images/project/weekly.png") no-repeat;
      background-size: 100%;
      margin: 0 10px 15px 0;
      //   img {
      //     width: 29.33333vw;
      //   }
      a {
        margin-left: 11.33333vw;
    border-bottom: 1px solid;
    display: inline-block;
    margin-top: 1.66667vw;
      }
    }
    .Monthlyreport {
      width: 15rem;
    //   min-height: 13vw;
    height: 3.5rem;
      background: url("../../../assets/images/project/Monthlyreport.png")
        no-repeat;
      background-size: 100% 100%;
      margin: 0 10px 15px 0;
      //   img {
      //     width: 29.33333vw;
      //   }
      a {
           margin-left: 11.33333vw;
          border-bottom: 1px solid;
          display: inline-block;
          margin-top: 1rem;
      }
    }
    .item_text{
            width: 40vw;
    border-radius: 1.33333vw;
    color: #606266;
    font-size: 4.8vw;
    font-weight: 400;
    box-sizing: border-box;
    padding: .5rem;
    border-radius: 13px;
    background: #EAF2FC;
    margin-bottom: 20px;
    }
  }
  .stealth {
    width: 40.33333vw;
  }
}
.item_right {
  width: 300px;
  border-radius: 10px;
  padding: 30px 20px;
  color: #417af8;
  font-size: 36px;
  font-weight: 400;
}
.item_status {
  font-size: 32px;
  color: #fff;
  border-radius: 10px;
  position: relative;
  bottom: 18px;

  .status {
    display: inline-block;
    border-radius: 10px;
    background: #f00;
    font-size: 32px;
    padding: 10px 70px 10px 30px;
  }

  .item_arrow {
    display: inline-block;
    width: 0px;
    height: 0px;
    border-left: 10px solid transparent;
    border-top: 10px solid transparent;
    border-right: 15px solid #f00;
    border-bottom: 10px solid transparent;
  }
}


.step_item{
  clear: both;
  padding-bottom: 4.8vw;
  margin-bottom: 0;
  overflow: hidden;
  position: relative;
}
.item_left{
  width: 43% !important;
  float: left;
}
.item_center{
  width: 14%;
  float: left;
  text-align: center;
  .item_dot{
    margin: 0 auto;
  }
  .item_line{
    left: auto;
    margin: 0 auto;
    position: absolute;
    left: 50%;
    margin-left: -5px;
  }
}
.wpsReport{
  width: 43%;
  float: left;
}
.item_right,.Monthlyreport,.item_text{
  width: 100% !important;
}
</style>