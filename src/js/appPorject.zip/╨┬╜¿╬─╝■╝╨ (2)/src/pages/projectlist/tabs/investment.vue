<template>
    <div class="content investment">
        <div class="invTitle">
            <h1>01</h1>
            <h2>计划投资</h2>
        </div>
        <div class="itemBox bg01">
            <p>总投资</p>
            <h1><span>{{investmentData.totalCount | currency}}</span>万元</h1>
            <i class="icon01"></i>
        </div>
        <div class="itemBox bg02">
            <p>本年度计划投资</p>
            <h1><span>{{investmentData.yearCount | currency}}</span>万元</h1>
            <i class="icon02"></i>
        </div>
        <div class="itemBox bg02">
            <p>本年度计划累计投资</p>
            <h1><span>{{investmentData.accumulateYearCount | currency}}</span>万元</h1>
            <i class="icon02"></i>
        </div>
        <div class="chartItem">
            <div class="plan_title">累计投资与总投资的比例</div> 
            <div id="investChart" :style="{height: height+'px'}"></div>
        </div>
        <div class="invTitle">
            <h1>02</h1>
            <h2>实际投资</h2>
        </div>
        <div class="itemBox bg01">
            <p>累计完成投资</p>
            <h1><span>{{investmentDatas.topData.totalInvestmentCount | currency}}</span>万元</h1>
            <i class="icon04"></i>
        </div>
        <div class="itemBox bg02">
            <p>本年度累计完成投资</p>
            <h1><span>{{investmentDatas.topData.totalInvestmentYearCount | currency}}</span>万元</h1>
            <i class="icon02"></i>
        </div>
        <div class="itemBox bg03">
            <p>{{investmentDatas.topData.specificMonth}}月完成投资</p>
            <h1><span>{{investmentDatas.topData.totalInvestmentMonthCount | currency}}</span>万元</h1>
            <i class="icon03"></i>
        </div>
        <div class="chartItem">
            <div class="plan_title">月投资进度</div> 
              <div id="month" :style="{height: height+'px'}"></div>
        </div>
        <div class="chartItem">
            <div class="plan_title">年投资进度</div> 
              <div id="year" :style="{height: height+'px'}"></div>
        </div>
        <div class="chartItem">
            <div class="plan_title">累计投资进度</div> 
              <div id="total" :style="{height: height+'px'}"></div>
        </div>
        <!-- loading -->
        <loading v-if="loadingShow"></loading>
    </div>
</template>

<script>
import loading from "@/components/loading";
export default {
    components: { loading },
    data(){
        return{
            loadingShow: true,
            projectName: '',
            active: 0,
            height: 260,
            ljCount: '',
            zCount: '',
            id: '',
            investmentData: { //计划投资
                totalCount: 0,
                yearCount: 0,
                accumulateYearCount: 0,
            },

            investmentDatas: { //实际投资
                monthInvestment: '',
                topData: {
                    totalInvestmentCount: 0,
                    totalInvestmentYearCount: 0,
                    totalInvestmentMonthCount: 0,
                    specificMonth: '',
                },
                yearInvestment: {
                monthData: [],
                investmentPlanCount: "",
                },
                totalInvestment: ""
            },
        }
    },
    created () {
        this.projectName = this.$route.query.projectName;
        this.planInvest_fun({ projectName: this.projectName }, 0);
        this.actualInvest_fun({  projectName: this.projectName }, 1);
    },
    methods: {
        // 计划投资
        planInvest_fun(params = {}) {
            this.loadingShow = false;
            this.$api.progress.investment(params, 0).then(res => {
                this.loadingShow = false;
                if (res && res.state && res.state.code === 10000) {
                    this.investmentData = res.body;
                    this.zCount = res.body ? res.body.totalCount : 0;
                    // this.$nextTick(function () {
                    //     let planDatas = [{
                    //         value: this.ljCount,
                    //         name: '累计投资'
                    //     }, {
                    //         value: (this.zCount - this.ljCount),
                    //         name: '总投资'
                    //     }]
                    //     this.drawPieChart(['#3274FF', '#FEA700'], 'investChart', planDatas)
                    // })
                }
            })
        },
        
        // 实际投资
        actualInvest_fun(params = {}) {
            // this.loadingShow = false;   
            // this.investmentDatas = {
            //     "monthInvestment": {
            //         "totalInvestmentMonthCount": 200,
            //         "totalInvestmentMonthCount2": 500,
            //         "investmentPlanCount": 989858
            //     },
            //     "topData": {
            //         "totalInvestmentYearCount": 257468,
            //         "totalInvestmentCount": 1580937,
            //         "totalInvestmentMonthCount": 100
            //     },
            //     "yearInvestment": {
            //     "monthData": [
            //         {month: 5, count: 69200},
            //         {month: "1", count: 0},
            //         {month: "2", count: 0},
            //         {month: "3", count: 0},
            //         {month: "4", count: 0},
            //         {month: "6", count: 0},
            //         {month: "7", count: 0},
            //         {month: "8", count: 0},
            //         {month: "9", count: 0},
            //         {month: "10", count: 0},
            //         {month: "11", count: 0},
            //         {month: "12", count: 0},
            //     ],
            //     "investmentPlanCount": 460000
            //     },
            //     "totalInvestment": {
            //         "investmentFinishCount": 1580937,
            //         "investmentCount": 4500283
            //     }
            // }         
            this.loadingShow = true;   
            this.$api.progress.investment(params, 1).then(res => {
                this.loadingShow = false;
                if (res && res.state && res.state.code === 10000) {
                    this.investmentDatas = res.body;
                    this.ljCount = res.body ? res.body.totalInvestment.investmentFinishCount : 1;
                    // 月投资
                    let monthTZ = this.investmentDatas.topData.specificMonth?this.investmentDatas.topData.specificMonth+'月累计投资额':'月累计投资额';
                    this.actualMonthData = [{
                        value: this.investmentDatas.monthInvestment.totalInvestmentMonthCount,
                        name: monthTZ
                    },{
                        value: (this.investmentDatas.monthInvestment.investmentPlanCount - this.investmentDatas.monthInvestment.totalInvestmentMonthCount),
                        name: '本年计划投资额'
                    }]
                    // 累计投资
                    this.actualTotalData = [{
                        value: parseInt(this.investmentDatas.totalInvestment.investmentCount),
                        name: '剩余未完成投资'
                    },
                    {
                        value: parseInt(this.investmentDatas.totalInvestment.investmentFinishCount),
                        name: '累计已完成投资'
                    }]
                    // 年投资
                    let list = this.investmentDatas.yearInvestment.monthData.sort((a, b) => a.month - b.month)
                    list.map(item => {
                        item.percent = (item.count / parseInt(this.investmentDatas.yearInvestment.investmentPlanCount) *
                        100)
                        .toFixed(0)
                    })
                    let months = list.map(n => `${n.month}月`);
                    let counts = list.map(n => n.count + "");
                    let percents = list.map(n => n.percent);
                    let array = []
                    for (var i = 0; i < list.length; i++) {
                        if(list[i].count==0){
                            array.push(0)
                        }else{
                            array.push(this.investmentDatas.yearInvestment.investmentPlanCount)
                        }
                    }
                    this.actualYearData = {
                        months: months,
                        value: counts,
                        percents: percents,
                        array: array
                    }
                    this.$nextTick(function () {
                        this.drawPieChart(['#945CDE', '#00CEC5'], 'month', this.actualMonthData)
                        this.drawBArChart()
                        this.drawPieChart(['#F19D0A', '#4D84F7'], 'total', this.actualTotalData)
                        
                        let planDatas = [{
                            value: this.ljCount,
                            name: '累计投资'
                        }, {
                            value: (this.zCount - this.ljCount),
                            name: '总投资'
                        }]
                        this.drawPieChart(['#3274FF', '#FEA700'], 'investChart', planDatas)
                    })
                }
            })
        },
        // 饼图
        drawPieChart (color, id, datas) {
            let monthChart = this.$echarts.init(document.getElementById(id));
            let array = []
            let option = {
                clickable: false,
                silent: true,
                color: color,
                legend: {
                    show: true,
                    y: 'bottom',
                    textStyle: {
                        fontSize: 14
                    },
                },
                series: [{
                    name: "",
                    type: 'pie',
                    clickable: false,
                    center: ['50%', '60%'],
                    radius: ['40%', '65%'],
                    avoidLabelOverlap: true,
                    label: {
                        normal: {
                        show: true,
                        fontSize: '18',
                        color: '#606266',
                        margin: 25,
                        formatter: function (params) {
                            return '{top|' + params.name + '}' + '\n' + '{bottom|' + params.percent.toFixed(0) + '%}'
                        },
                        rich: {
                            top: {
                                color: '#606266',
                                lineHeight: 10
                            },
                            bottom: {
                                color: '#606266',
                                fontSize: 18,
                                height: 40
                            }
                        }
                        },
                    },
                    labelLine: {
                        show: true,
                        length: 10,
                        length2: 5,
                        lineStyle: {
                            color: '#D6D6D6'
                        }
                    },
                    top: '0',
                    bottom: '30',
                    data: datas
                }]
            }
            datas.map(item => {
                array.push(item.name)
                if (item.name == "总投资" || item.name == "本年计划投资额" || item.name == '剩余未完成投资') {
                    item.label = { show: false }
                    item.labelLine = { show: false }
                }
                if (item.name == "总投资" || item.name == "本年计划投资额"){
                    option.legend.show = false
                }
            })
            monthChart.setOption(option);
        },
        // 柱状图
        drawBArChart () {
            let yearChart = this.$echarts.init(document.getElementById('year'));
            var colors = ['#00CEC5', '#945CDE'];
            let option = {
                color: colors,
                right: 0,
                legend: {
                    x: 'center',
                    bottom: '10',
                    width: '100%',
                    icon: 'rect',
                    itemWidth: 10,
                    itemHeight: 10,
                    itemGap: 20,
                    textStyle: {
                        fontSize: 14
                    },
                    data: ['本年度计划投资额', '本月投资额']
                },
                grid: {
                    left: '40'
                },
                xAxis: [{
                type: 'category',
                axisTick: {
                    show: false
                },
                data: this.actualYearData.months,
                axisLine: {
                    lineStyle: {
                    color: 'rgba(115,115,115,.5)',
                    }
                },
                axisLabel: {
                    rotate: 40,
                    textStyle: {
                    fontSize: 8,
                    color: '#333'
                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                    color: ['#F0F0F0']
                    }
                }
                }],
                yAxis: [{
                type: 'value',
                // name: '温度',
                min: 0,
                max: 100,
                // interval: 5,
                axisLine: {
                    lineStyle: {
                    color: 'rgba(115,115,115,.5)',
                    },
                },
                axisLabel: {
                    formatter: '{value}%',
                    textStyle: {
                    fontSize: 12,
                    color: '#333'
                    }
                },
                axisTick: {
                    show: false
                },
                }, {
                show: false
                }],
                series: [
                {
                    name: '本年度计划投资额',
                    type: 'bar',
                    barWidth: 8,
                    barCategoryGap: '80%',
                    yAxisIndex: 1,
                    itemStyle: {
                    barBorderRadius: 5
                    },
                    data: this.actualYearData.array
                    // data: [222,323,545,767,32,324,325,554,767,645,322,32],
                },
                {
                    name: '本月投资额',
                    type: 'bar',
                    barWidth: 8,
                    barCategoryGap: '80%',
                    yAxisIndex: 1,
                    itemStyle: {
                    barBorderRadius: 5
                    },
                    data: this.actualYearData.value
                    // data: [111,32,434,656,43,657,787,434,878,989,324,324],
                },

                {
                    name: '百分比',
                    type: 'line',
                    smooth: true,
                    yAxisIndex: 0,
                    data: this.actualYearData.percents
                }
                ]
            };
            yearChart.setOption(option)
        },
    }
}
</script>

<style scoped lang="scss">
    .invTitle{
        padding-bottom: 40px;
        h1{
            font-size: 50px;
            color: #939393;
            text-align: center;
        }
        h2{
            font-size: 42px;
            font-weight: normal;
            color: #000;
            text-align: center;
            padding: 10px 0 25px 0;
            position: relative;
            &::before{
                content: "";
                height: 5px;
                width: 106px;
                background: #0076f0;
                position: absolute;
                bottom: 0;
                left: 50%;
                margin-left: -53px;
            }
        }
    }
    .investment{
        padding: 40px 20px !important;
    }
    .itemBox{
        text-align: left;
        background: #0076f0;
        padding: 50px 0 50px 60px;
        border-radius: 25px;
        margin-bottom: 40px;
        position: relative;
        p{
            font-size: 40px;
            color: #fff;
            padding-bottom: 15px;
        }
        h1{
            font-size: 50px;
            font-weight: normal;
            color: #fff;
            text-align: left;
            span{
                font-size: 70px;
                font-weight: bold;
                padding-right: 20px;
            }
        }
        i{
            width: 132px;
            height: 100px;
            position: absolute;
            right: 30px;
            top: 50%;
            margin-top: -47px;
            opacity: 0.6;
        }
    }
    .bg01{
        background: url('../../../assets/images/project/bg01.png') no-repeat;
        background-size: 100% 100%;
    }
    .bg02{
        background: url('../../../assets/images/project/bg02.png') no-repeat;
        background-size: 100% 100%;
    }
    .bg03{
        background: url('../../../assets/images/project/bg03.png') no-repeat;
        background-size: 100% 100%;
    }
    .icon01{
        background: url('../../../assets/images/project/icon01.png') no-repeat;
        background-size: contain;
    }
    .icon02{
        background: url('../../../assets/images/project/icon02.png') no-repeat;
        background-size: contain;
    }
    .icon03{
        background: url('../../../assets/images/project/icon03.png') no-repeat;
        background-size: contain;
    }
    .icon04{
        background: url('../../../assets/images/project/icon04.png') no-repeat;
        background-size: contain;
    }
    .chartItem{
        margin-bottom: 40px;
        padding: 40px;
        background: #f2f2f2;
        border-radius: 10px;
    }
    .plan_title{
        font-size: 38px;
        position: relative;
        line-height: 50px;
        color: #000;
        text-align: center;
        &::before {
            content: '';
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #598cf9;
            display: inline-block;
            vertical-align: middle;
            margin-right: 15px;
            position: relative;
            top: -4px;
        }
        &::after {
            content: '';
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #598cf9;
            display: inline-block;
            vertical-align: middle;
            margin-left: 15px;
            position: relative;
            top: -4px;
        }
    }
</style>