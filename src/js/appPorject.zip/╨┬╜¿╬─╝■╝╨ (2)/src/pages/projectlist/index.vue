<template>
  <div class="engineer">
    <div class="engineer_search">
      <screen
        class="screen"
        @getSearchList="screeningRequest"
        @searchParams="getSearchParams"
        @chooseItem="chooseItem"
        @cancle="cancle"
      ></screen>
    </div>
    <ol class="engineer_list">
      <li
        class="list_item"
        v-for="(item, index) in projectList"
        :key="index"
        @click="goDetail(item, index)"
      >
        <div class="li_child flex justify-between">
          <img class="list_item_img" :src="imgUrl" alt="" />
          <div class="list_item_cont">
            <p
              class="list_item_cont_title red bold"
              :class="item.projectStatus == 0 ? 'green_status' : 'red_status'"
            >
              {{ item.projectName }}
            </p>
            <p class="list_item_cont_fee text-md" style="line-height: 15px">
              总投资额:{{ item.investmentCount | currency }}万元
            </p>
            <p class="list_item_cont_status text-md">
              阶段:{{ item.projectPeriod | projectPeriod }}
            </p>
          </div>
          <div class="list_item_status" style="line-height: 15px; width: 90px">
            <span
              class="dot"
              :class="item.projectStatus == 0 ? 'greenDot' : 'redDot'"
            ></span>
            <span
              class="status"
              :class="item.projectStatus == 0 ? 'green_status' : 'red_status'"
              >{{ item.projectStatus == 0 ? "正常" : item.delayTime }}</span
            >
          </div>
        </div>
      </li>
    </ol>
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
import screen from "../../components/screen";
import loading from "../../components/loading";
export default {
  name: "projectlists",
  components: {
    screen,
    loading,
  },
  data() {
    return {
      imgUrl: require("../../assets/img/engineering/eng.jpg"),
      projectList: [],
      active: 0,
      loadingShow: true,
      searchList: [],
    };
  },
  created() {
    document.title = "进度监控";
    this.getEngineeringCount();
  },
  methods: {
    // 跳转到详情页面
    goDetail(item) {
      this.$router.push({
        // name: "engineer-detail",
        name: "project-detail",
        query: {
          id: item.id,
          projectName: item.projectName,
        },
      });
    },
    screeningRequest(param) {
      this.projectList = param;
      //   this.getEngineeringCount()
    },
    // 获取工程概览统计信息
    getEngineeringCount() {
      this.projectList = [];
      this.loadingShow = true;
      this.eChartData1 = [];
      let obj = {
        projectName: "",
        projectType: "",
        projectStatus: "",
        projectPeriod: "",
        projectBoard: "",
      };
      let params = {};
      this.topData = {};
      Object.assign(params, obj, this.datas);
      this.$api.engineering
        .getEngineering(params)
        .then((res) => {
          console.log(res);
          this.loadingShow = false;
          if (res.state.code === 10000) {
            this.topData = {
              ...this.topData,
              ...res.body.topData,
            };
            this.projectList = res.body.projectList;
            let yearFinishCount = parseInt(res.body.topData.yearFinishCount);
            let investmentPlanCount = parseInt(
              res.body.topData.investmentPlanCount
            );
            let rate = "";
            if (investmentPlanCount == 0) {
              rate = 0;
            } else {
              rate = (yearFinishCount / investmentPlanCount) * 100;
            }
            console.log(rate, "rate---------");
            rate = rate.toFixed(1);
            res.body.eChartData.map((item) => {
              this.eChartData1.push({
                name: item.name,
                value: item.count,
                num: item.count + "",
              });
              console.log(this.eChartData1);
              this.$nextTick(function () {
                // this.drawChart(this.eChartData1, "myChart", "investmentCount", '板块总投资概况');
              });
            });
          }
        })
        .catch(() => {
          // console.log('接口请求失败')
          this.loadingShow = false;
        });
    },
    cancle() {
      this.projectList = [];
      this.getEngineeringCount({
        projectName: "",
        projectType: "",
        projectStatus: "",
        projectPeriod: "",
        projectBoard: "",
      });
    },
    //
    chooseItem(data) {
      this.projectList = [];
      this.projectList.push(data);
    },
    getSearchParams(data) {
      this.datas = data;
      if (!data.projectName) {
        this.getEngineeringCount();
      }
    },
  },
};
</script>

<style scoped lang="scss">
@import "./css/index.scss";
.project {
  /deep/.van-tabs {
    .van-tab {
      font-size: 18px;
      color: rgba(0, 0, 0, 0.7);
    }
    .van-tab.van-tab--active {
      color: #000;
    }
    .van-tabs__content {
      padding: 15px 10px;
    }
    .van-tabs__wrap {
      padding-top: 6px;
      background: #fff;
      height: 50px;
    }
  }
  .content {
    background: #fff;
    border-radius: 6px;
    padding: 15px;
    overflow: hidden;
  }
}
</style>