<template>
  <div class="graphicProgress">
    <div class="title">
      <h4>形象进度计划展示</h4>
      <h4>实际形象进度展示</h4>
    </div>
    <div class="content">
      <div class="planList">
        <div
          class="planList_item"
          v-for="(item, key) in planList"
          :key="key"
          :ref="'planList' + key"
          :style="{
            height: item.maxHeight + 'px',
            minHeight: item.planMonth == 12 ? '20px' : '',
          }"
        >
          <h1 :id="'planitem' + Number(item.planMonth)">
            <span v-show="Number(item.planMonth) % 1 === 0">{{
              Number(item.planMonth)
            }}</span>
          </h1>
          <div class="planList_item_info" v-if="item.imagePlanTime">
            <h5>
              <img src="@/assets/img/graphicProgress/time.png" />{{
                item.imagePlanTime
              }}
            </h5>
            <p>{{ item.imagePlanContent }}</p>
          </div>
        </div>
      </div>
      <div class="actualList">
        <div
          class="actualList_item"
          v-for="(item, key) in actualList"
          :key="key"
          :ref="'actualList' + key"
          :style="{
            height: item.maxHeight + 'px',
            minHeight: item.position == 12 ? '20px' : '',
          }"
        >
          <h1 :id="'actualitem' + Number(item.position)">
            <span v-show="Number(item.position) % 1 === 0">{{
              Number(item.position)
            }}</span>
          </h1>
          <div v-for="(val, index) in item.list" :key="index">
            <div
              class="actualList_item_info"
              v-if="val.imageProgressTime"
              :style="!val.imageStatus ? 'background:#fdf4f4' : ''"
            >
              <h5>
                <img src="@/assets/img/graphicProgress/time.png" />{{
                  val.imageProgressTime
                }}
                <span
                  style="background: #d51e2a"
                  v-if="!val.imageStatus && val.delayTime"
                  >迟{{ val.delayTime }}月</span
                >
                <span v-else-if="val.imageStatus">{{
                  val.imageStatus === 1 ? "正常" : "完成"
                }}</span>
              </h5>
              <!-- <p class="predictTime" v-if="val.predictTime">预估时间: {{item.predictTime}}</p> -->
              <p v-html="keepTextStyle(val.imageRealContent)"></p>
            </div>
            <!-- <div class="predictStatus" v-if="!val.imageProgressTime && !val.imageStatus && val.delayTime">预约延期{{val.delayTime}}</div> -->
            <div class="actualList_item_attach">
              <ul>
                <li v-if="val.report">
                  <a
                    :id="`docUrl_${key}_${index}`"
                    href="javascript:void(null);"
                    :style="{ color: val.reportType == 1 ? '#edc316' : '' }"
                    >{{ val.reportType == 1 ? "月报" : "周报" }}</a
                  >
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 划线 -->
    <div
      :class="['line', item.lineColor]"
      v-for="(item, key) in lineList"
      :style="{
        width: item.lineLength + 'px',
        top: item.leftTapPos.YPoint + 'px',
        left: item.leftTapPos.xPoint + 'px',
        transform: `rotate(${item.angle}deg)`,
        transformOrigin: '0 50%',
      }"
    ></div>
    <!-- loading -->
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
import loading from "@/components/loading";
import { get } from "../../api/config";
export default {
  components: {
    loading,
  },
  data() {
    return {
      planList: [],
      actualList: [],
      leftTapPos: null,
      rightTapPos: null,
      lineList: [],
      projectId: "",
      loadingShow: true,
      waitGetUrlIds: [],
    };
  },
  created() {},
  mounted() {
    this.projectId = this.$route.query.id;
    document.title = this.$route.query.projectName;
    this.getStep();
  },
  methods: {
    // 获取形象进度
    getStep() {
      const that = this;
      that.loadingShow = true;
      that.$api.progress.steps(that.projectId).then((res) => {
        that.loadingShow = false;
        if (res && res.state && res.state.code === 10000) {
          res.body && JSON.stringify(res.body) != "{}" ? res.body : [];
          if (res.body.length) {
            // 初始化标尺长度
            let planListArr = [];
            let actualListArr = [];
            let lineArr = []; // 线标起始位置
            for (let i = 0; i < 48; i++) {
              planListArr.push({ planMonth: i / 4 });
              actualListArr.push({ position: i / 4, list: [] });
            }
            planListArr.push({ planMonth: 12 });
            actualListArr.push({ position: 12, list: [] });
            res.body.forEach((item, key) => {
              // 左侧数据置于返回点位
              planListArr.forEach((i, k) => {
                if (Number(item.plan.planMonth) == Number(i.planMonth)) {
                  this.$set(planListArr, k, item.plan);
                }
              });
              let pointStatus = ""; // 最后一位状态
              // 右侧数据置于返回点位
              item.progresses.forEach((val, index) => {
                actualListArr.forEach((i, k) => {
                  if (Number(val.position) == Number(i.position)) {
                    actualListArr[k].list.push(val);
                  }
                });
                pointStatus = val.imageStatus;
              });
              // 起始位置均在配置连线起始点
              if (item.plan.planMonth && item.plan.actualCompletionMonth) {
                // 有起始位置
                lineArr.push({
                  firstPoint: Number(item.plan.planMonth),
                  secondPoint: Number(item.plan.actualCompletionMonth),
                  status: pointStatus, // 终点最后一条数据状态
                });
              }
            });
            // 获取报表
            actualListArr.forEach((item, key) => {
              item.list.forEach((v, k) => {
                if (v.report) {
                  let waitGetUrlId = {
                    id: key + "_" + k,
                    docId: v.report,
                  };
                  that.waitGetUrlIds.push(waitGetUrlId);
                }
              });
            });
            // 赋值
            that.planList = planListArr;
            that.actualList = actualListArr;
            // 获取元素最大高度
            that.$nextTick(() => {
              // 左右两侧高度一致
              that.planList.forEach((item, key) => {
                const planHeight = that.$refs[`planList${key}`][0].offsetHeight;
                const actualHeight =
                  that.$refs[`actualList${key}`][0].offsetHeight;
                const maxHeight = Math.max(planHeight, actualHeight);
                that.$set(item, "maxHeight", maxHeight);
              });
              that.actualList.forEach((item, key) => {
                const planHeight = that.$refs[`planList${key}`][0].offsetHeight;
                const actualHeight =
                  that.$refs[`actualList${key}`][0].offsetHeight;
                const maxHeight = Math.max(planHeight, actualHeight);
                that.$set(item, "maxHeight", maxHeight);
              });
              // 有报表获取报表跳转地址
              if (that.waitGetUrlIds.length > 0) {
                that.setDocUrl();
              }
              // 两点间连线
              that.$nextTick(() => {
                setTimeout(() => {
                  that.leftTapPos = null;
                  that.rightTapPos = null;
                  lineArr.forEach((item, key) => {
                    that.leftTapPos = null;
                    that.rightTapPos = null;
                    let firstPointPos = document
                      .getElementById(`planitem${item.firstPoint}`)
                      .getBoundingClientRect();
                    let secondPointPos = document
                      .getElementById(`actualitem${item.secondPoint}`)
                      .getBoundingClientRect();
                    that.leftTapPos = {
                      xPoint: firstPointPos.left + 15,
                      YPoint: firstPointPos.top + 15,
                    };
                    that.rightTapPos = {
                      xPoint: secondPointPos.left - 15,
                      YPoint: secondPointPos.top + 15,
                    };
                    if (that.leftTapPos && that.rightTapPos) {
                      // 判断左右点连线样式  状态 => 0 延期  1 正常  2 已完成
                      // 终点-起点<= 0 正常/已完成 =》 绿色实线， 延期 =》 不划线
                      // 终点-起点 > 0  正常/已完成 =》 红实线， 延期 =》红虚线
                      if (
                        Number(item.secondPoint) - Number(item.firstPoint) <=
                        0
                      ) {
                        if (item.status == 1 || item.status == 2) {
                          that.setLine();
                        }
                      } else if (
                        Number(item.secondPoint) - Number(item.firstPoint) >
                        0
                      ) {
                        if (item.status == 1 || item.status == 2) {
                          that.setLine("redSolid");
                        } else if (item.status == 0) {
                          that.setLine("redDashed");
                        }
                      }
                    }
                  });
                }, 0);
              });
            });
          }
        } else {
          that.html = "暂无数据";
        }
      });
    },
    setDocUrl() {
      this.waitGetUrlIds.map((item) => {
        this.getWps(item.id, item.docId);
      });
    },
    // 请求wps接口
    getWps(hrefId, wpsId) {
      get(
        `gdh-com-hk-digital-fileauthcomputesvc/api/service/filePreview/${wpsId}`
      ).then((res) => {
        if (res.body != null && res.body.url != null && res.body.url) {
          document.getElementById("docUrl_" + hrefId).href = res.body.url;
        }
      });
    },
    // 链接两点线
    calcLine(firstPoint, secondPoint) {
      // 计算连线
      // 计算出两个点之间的距离
      let line = Math.sqrt(
        Math.pow(firstPoint.xPoint - secondPoint.xPoint, 2) +
          Math.pow(firstPoint.YPoint - secondPoint.YPoint, 2)
      );
      return line;
    },
    getAngle(x1, y1, x2, y2) {
      // 计算角度
      // 获得人物中心和鼠标坐标连线，与y轴正半轴之间的夹角
      var x = x1 - x2;
      var y = y1 - y2;
      var z = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
      var cos = y / z;
      var radina = Math.acos(cos); // 用反三角函数求弧度
      var angle = 180 / (Math.PI / radina); // 将弧度转换成角度
      if (x2 > x1 && y2 === y1) {
        // 在x轴正方向上
        angle = 0;
      }
      if (x2 > x1 && y2 < y1) {
        // 在第一象限;
        angle = angle - 90;
      }
      if (x2 === x1 && y1 > y2) {
        // 在y轴正方向上
        angle = -90;
      }
      if (x2 < x1 && y2 < y1) {
        // 在第二象限
        angle = 270 - angle;
      }
      if (x2 < x1 && y2 === y1) {
        // 在x轴负方向
        angle = 180;
      }
      if (x2 < x1 && y2 > y1) {
        // 在第三象限
        angle = 270 - angle;
      }
      if (x2 === x1 && y2 > y1) {
        // 在y轴负方向上
        angle = 90;
      }
      if (x2 > x1 && y2 > y1) {
        // 在四象限
        angle = angle - 90;
      }
      return angle;
    },
    setLine(lineColor) {
      // 画线
      let lineLength = this.calcLine(this.leftTapPos, this.rightTapPos);
      let angle = this.getAngle(
        this.leftTapPos.xPoint,
        this.leftTapPos.YPoint,
        this.rightTapPos.xPoint,
        this.rightTapPos.YPoint
      );
      this.lineList.push({
        lineLength: lineLength,
        leftTapPos: {
          xPoint: this.leftTapPos.xPoint,
          YPoint: this.leftTapPos.YPoint,
        },
        angle: angle,
        lineColor: lineColor,
      });
      this.leftTapPos = null;
      this.rightTapPos = null;
    },
    // 回车符换行方法
    keepTextStyle(val) {
      return val.replace(/\n/g, "<br/>");
    },
  },
};
</script>
<style lang='scss' scoped>
.graphicProgress {
  width: 100%;
  height: auto;
  overflow: hidden;
  background: #fff;
  .title {
    width: 100%;
    height: 100px;
    line-height: 100px;
    display: flex;
    flex-wrap: wrap;
    font-size: 28px;
    h4 {
      width: 50%;
      text-align: center;
      color: #ecc007;
      &:last-child {
        color: #457ef1;
      }
    }
  }
  .content {
    width: 100%;
    height: auto;
    padding: 0 20px;
    box-sizing: border-box;
    overflow: hidden;
    .planList {
      width: 46%;
      float: left;
      .planList_item {
        background: url("../../assets/img/graphicProgress/yellowBg.png")
          no-repeat right top;
        background-size: 15%;
        h1 {
          right: 30px;
          span {
            color: #ecc007;
          }
        }
      }
    }
    .planList_item,
    .actualList_item {
      width: 100%;
      height: auto;
      min-height: 50px;
      overflow: hidden;
      position: relative;
      padding-bottom: 20px;
      box-sizing: content-box;
      h1 {
        position: absolute;
        top: -8px;
        height: 30px;
        line-height: 30px;
        span {
          font-size: 30px;
        }
      }
      &:first-child {
        .planList_item_info {
          margin-top: 0;
        }
      }
      .planList_item_info {
        float: left;
        background: #f3f7fb;
      }
    }
    .planList_item .planList_item_info,
    .actualList_item .actualList_item_info {
      width: 93%;
      height: auto;
      overflow: hidden;
      border-radius: 20px;
      padding: 20px 15px 15px;
      box-sizing: border-box;
      margin-top: 20px;
      h5 {
        margin-bottom: 10px;
        font-size: 26px;
        color: #333;
        line-height: 40px;
        img {
          width: 30px;
          height: 30px;
          margin-right: 5px;
          vertical-align: middle;
          margin-top: -12px;
        }
      }
      p {
        color: #686868;
        font-size: 24px;
        line-height: 36px;
      }
    }
    .actualList {
      width: 46%;
      float: right;
      .actualList_item {
        background: url("../../assets/img/graphicProgress/blueBg.png") no-repeat
          left top;
        background-size: 12%;
        h1 {
          left: 30px;
          span {
            color: #457ef1;
          }
        }
        .predictStatus {
          width: 93%;
          color: #d9313c;
          float: right;
          font-size: 30px;
          margin-top: 20px;
        }
        &:first-child {
          .actualList_item_info {
            margin-top: 0;
          }
        }
        .actualList_item_info {
          float: right;
          background: #f7faf3;
          .predictTime {
            font-size: 26px;
          }
          h5 {
            span {
              height: 24px;
              line-height: 24px;
              padding: 0 8px;
              background: #5ba20d;
              color: #fff;
              font-size: 20px;
              font-weight: normal;
              margin-top: 4px;
              float: right;
              border-radius: 5px;
            }
          }
        }
        .actualList_item_attach {
          width: 93%;
          float: right;
          ul {
            li {
              width: 50%;
              float: left;
              text-decoration: underline;
              font-size: 23px;
              margin-top: 28px;
              a {
                color: #6e9af4;
              }
            }
          }
        }
      }
    }
  }
  .line {
    position: absolute;
    border-top: 1px solid #5ba20d;
    &:after {
      content: "";
      width: 20px;
      height: 20px;
      border: 4px solid #5ba20d;
      border-left: none !important;
      border-bottom: none !important;
      position: absolute;
      right: 0px;
      bottom: -10px;
      transform: rotate(45deg);
    }
  }
  .redSolid {
    border-top: 1px solid #f00;
    &:after {
      border-color: #f00 !important;
    }
  }
  .redDashed {
    border-top: 1px dashed #f00;
    &:after {
      border-color: #f00 !important;
    }
  }
}
</style>