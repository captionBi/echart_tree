  <template>
  <div class="personnel" :style="{overflowY:scrollcalculate}">
    <!-- 在职人数 -->
    <div class="application">
      <img class="img" src="@/assets/img/partymanage/work.png" alt />
      <div class="info">
        <div class="title">在职人数</div>
        <div class="number">
          <span class="number">{{worknum}}</span>
          <span class="unit">名</span>
        </div>
      </div>
    </div>

    <!-- 离职人数/离职率 -->
    <div class="positive">
      <div class="leftobj">
        <div class="info">
          <div class="title">
            离职人数
            <span class="titletext">(近一个月)</span>
          </div>
          <div class="number">
            <span class="number">{{departurenum}}</span>
            <span class="unit">名</span>
          </div>
        </div>
      </div>
      <div class="rightobj">
        <div class="info">
          <div class="title">
            离职率
            <span class="titletext">(近一个月)</span>
          </div>
          <div class="number">
            <span class="number">{{departurepercentage}}</span>
            <span class="unit" style="display:none;">%</span>
          </div>
        </div>
      </div>
    </div>

    <!-- echart饼图  性别结构 -->
    <div class="chart" id="gender">
      <div class="chart_tit">
        <p class="text-center text-sm chart_title">在职人员性别结构</p>
        <div class="bot_line"></div>
      </div>
      <div id="myChart_gender" :style="{height: height+'px'}"></div>
    </div>
    <!-- echart饼图  全职兼职比例 -->
    <div class="chart" id="distinction">
      <div class="chart_tit">
        <p class="text-center text-sm chart_title">全职兼职比例</p>
        <div class="bot_line"></div>
      </div>
      <div id="myChart_distinction" :style="{height: height+'px'}"></div>
    </div>
    <!-- echart饼图  在职时长统计 -->
    <div class="chart" id="duration">
      <div class="chart_tit">
        <p class="text-center text-sm chart_title">在职时长统计</p>
        <div class="bot_line"></div>
      </div>
      <div id="myChart_duration" :style="{height: height+'px'}"></div>
    </div>

    <!-- tab -->
    <ul class="statistics">
      <li class="itemtext" :class="{'active':currentindex == 1}" @click="handoverhandler('1')">业务线人事</li>
      <li class="itemtext" :class="{'active':currentindex == 2}" @click="handoverhandler('2')">地区人事</li>
      <li class="itemtext" :class="{'active':currentindex == 3}" @click="handoverhandler('3')">公司人事</li>
    </ul>
    <!-- 业务线人事统计 横向图表 -->
    <div class="plate color_1" id="business" v-show="myChart_businessflag">
      <div class="padding-top chart">
        <div class="chart_tit">
          <p class="text-center text-sm plan_title">业务线人事统计</p>
          <!-- <p class="text-center text-xs plan_title plan_title_sub">{{name}}</p> -->
          <!-- <p class="text-right margin text-bold">单位：亿</p> -->
          <!-- <div class="bot_line"></div> -->
          <div class="flex justify-start">
            <div class="index_list">
              <ul>
                <li class="item" v-for="(item,index) in businessarray" :key="index">
                  <span class="index">{{index+1}}</span>
                </li>
              </ul>
            </div>

            <ul class="list">
              <li
                class="item cont_item flex justify-between text-cut"
                v-for="(item,index) in businessarray"
                :key="index"
              >
                <div class="item_cont min_item left">
                  <div class="bg" :style="{width:item.rate}"></div>
                  <div class="text-cut text">{{item.businessName}}</div>
                </div>
                <!-- <div class="item_cont min_item" :style="{width:item.percent+'%'}">{{item.name}}</div> -->
                <div class="percent">{{item.businessCount}}({{item.rate}})</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 地区人事统计 横向图表 -->
    <div class="plate color_2" id="region" v-show="myChart_regionflag">
      <div class="padding-top chart">
        <div class="chart_tit">
          <p class="text-center text-sm plan_title">地区人事统计</p>
          <!-- <p class="text-center text-xs plan_title plan_title_sub">{{name}}</p> -->
          <!-- <p class="text-right margin text-bold">单位：亿</p> -->
          <!-- <div class="bot_line"></div> -->
          <div class="flex justify-start">
            <div class="index_list">
              <ul>
                <li class="item" v-for="(item,index) in regionarray" :key="index">
                  <span class="index">{{index+1}}</span>
                </li>
              </ul>
            </div>
            <ul class="list">
              <li
                class="item cont_item flex justify-between text-cut"
                v-for="(item,index) in regionarray"
                :key="index"
              >
                <div class="item_cont min_item left">
                  <div class="bg" :style="{width:item.rate}"></div>
                  <div class="text-cut text">{{item.areaName}}</div>
                </div>
                <!-- <div class="item_cont min_item" :style="{width:item.percent+'%'}">{{item.name}}</div> -->
                <div class="percent">{{item.areaCount}}({{item.rate}})</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 所在公司人事统计 横向图表 -->
    <div class="plate color_3" id="company" v-show="myChart_companyflag">
      <div class="padding-top chart">
        <div class="chart_tit">
          <p class="text-center text-sm plan_title">所在公司人事统计</p>
          <!-- <p class="text-center text-xs plan_title plan_title_sub">{{name}}</p> -->
          <!-- <p class="text-right margin text-bold">单位：亿</p> -->
          <!-- <div class="bot_line"></div> -->
          <div class="flex justify-start">
            <div class="index_list">
              <ul>
                <li class="item" v-for="(item,index) in companyarray" :key="index">
                  <span class="index">{{index+1}}</span>
                </li>
              </ul>
            </div>
            <ul class="list">
              <li
                @click="enterprisehandler(item.companyName,item.hurMainId)"
                class="item cont_item flex justify-between text-cut"
                v-for="(item,index) in companyarray"
                :key="index"
              >
                <div class="item_cont min_item left">
                  <div class="bg" :style="{width:item.rate}"></div>
                  <div class="text-cut text">{{item.companyName}}</div>
                </div>
                <!-- <div class="item_cont min_item" :style="{width:item.percent+'%'}">{{item.name}}</div> -->
                <div class="percent">{{item.companyCount}}({{item.rate}})</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <transition name="enterprise">
      <!-- 全屏遮罩 -->
      <div class="enterprisedetail" v-show="EnterpriseStaff" @click="shadehandler">
        <!-- 主体内容盒子 -->
        <div class="enterprisecontent">
          <div class="title">{{Enterprisetitle}}(领导班子)</div>
          <ul class="enterpriseinfo" v-show="EnterpriseStaffArr.length">
            <li class="enterprisetitle">
              <div class="name">姓名</div>
              <div class="sex">性别</div>
              <div class="age">年龄</div>
              <div class="effdt">任职日期</div>
              <div class="positionDesc">职位</div>
              <div class="jobDesc">主/兼职</div>
            </li>
            <li
              class="enterpriseitem"
              v-for="(item, index) in EnterpriseStaffArr"
              :key="index"
              :class="disposehandler(index)"
            >
              <div class="name">{{item.name}}</div>
              <div class="sex">{{item.sex}}</div>
              <div class="age">{{item.age}}</div>
              <div class="effdt">{{item.effdt}}</div>
              <div class="positionDesc">{{item.positionDesc}}</div>
              <div class="jobDesc">{{item.jobDesc}}</div>
            </li>
          </ul>
          <div class="enterpriseaccident" v-show="!EnterpriseStaffArr.length">暂无数据!</div>
        </div>
      </div>
    </transition>

    <loading v-if="loadingShow"></loading>
  </div>
</template>
  
<script type="text/ecmascript-6">
import Loading from "../../components/loading";
export default {
  name: "personnel",
  data() {
    return {
      loadingShow: true, //加载图层
      height: 260, //饼图高度
      myChart_businessflag: true,
      myChart_regionflag: false,
      myChart_companyflag: false,
      currentindex: 1,
      worknum: 0, //在职人数
      departurenum: 0, //离职人数
      departurepercentage: 0, //离职率
      genderarray: [], //在职人员性别结构数组
      distinctionarray: [], //全职兼职比例
      durationarray: [], //在职时长统计
      businessarray: [], //业务线人事统计
      // businesstitlearray:[],//业务线人事统计标题数组
      regionarray: [], //地区人事统计
      // regiontitlearray:[],//地区人事统计标题数组
      companyarray: [], //
      //   显示企业人员配置
      EnterpriseStaffArr: [],
      //   显示企业人员配置
      EnterpriseStaff: false,
      //   显示企业人员标题
      Enterprisetitle: "",
      MainId: ""
    };
  },
  mounted() {},
  created() {
    this._personnelrequest();
  },
  computed: {
    scrollcalculate() {
      return this.EnterpriseStaff == false ? "scroll" : "hidden";
    }
  },
  methods: {
    // 点击隐藏弹窗
    shadehandler() {
      this.EnterpriseStaff = false;
    },
    // 用户点击tab切换
    handoverhandler(flag) {
      this.currentindex = flag;
      if (flag == 1) {
        this.myChart_businessflag = true;
        this.myChart_regionflag = false;
        this.myChart_companyflag = false;
      } else if (flag == 2) {
        this.myChart_businessflag = false;
        this.myChart_regionflag = true;
        this.myChart_companyflag = false;
      } else if (flag == 3) {
        this.myChart_businessflag = false;
        this.myChart_regionflag = false;
        this.myChart_companyflag = true;
      }
    },
    // 初始化数据
    _personnelrequest() {
      this.$api.personnel
        .personnelrequest()
        .then(response => {
          console.log(response);
          if (response.state.code == 10000) {
            const { hurMainInfo } = response.body;
            this.worknum = hurMainInfo.inJobCount;
            this.departurenum = hurMainInfo.notJonCount;
            this.departurepercentage = hurMainInfo.notJobRate;
            const manobj = {
              value: hurMainInfo.maleCount,
              rate: hurMainInfo.maleRate,
              name: "男"
            };
            const womanobj = {
              value: hurMainInfo.femaleCount,
              rate: hurMainInfo.femaleRate,
              name: "女"
            };
            this.genderarray.push(manobj, womanobj);
            this.drawChart(this.genderarray, "myChart_gender", [
              "#3175FF",
              "#F8A8EC"
            ]);

            const official = {
              value: hurMainInfo.fullTime,
              rate: hurMainInfo.fullTimeRate,
              name: "全职"
            };
            const informality = {
              value: hurMainInfo.partTime,
              rate: hurMainInfo.partTimeRate,
              name: "兼职"
            };
            this.distinctionarray.push(official, informality);
            this.drawChart(this.distinctionarray, "myChart_distinction", [
              "#FFA200",
              "#00B6D1"
            ]);

            this.durationarray = response.body.onDutyList.map(item => {
              return {
                value: item.itemVal,
                rate: item.itemRate,
                name: item.itemName
              };
            });
            this.drawChart(this.durationarray, "myChart_duration", [
              "#1bb700",
              "#42c1fd",
              "#3176fe",
              "#feaa00",
              "#8c52fe",
              "#f33f50"
            ]);

            this.businessarray = response.body.busList.map(item => {
              return {
                businessCount: item.businessCount,
                businessName: item.businessName,
                businessTotalCount: item.businessTotalCount,
                createDate: item.createDate,
                createUser: item.createUser,
                hurMainId: item.hurMainId,
                id: item.id,
                updateDate: item.updateDate,
                updateUser: item.updateUser,
                version: item.version,
                rate: this.GetPercent(
                  item.businessCount,
                  item.businessTotalCount
                )
              };
            });

            this.regionarray = response.body.areaList.map(item => {
              return {
                areaCount: item.areaCount,
                areaName: item.areaName,
                areaTotalCount: item.areaTotalCount,
                createDate: item.createDate,
                createUser: item.createUser,
                hurMainId: item.hurMainId,
                id: item.id,
                updateDate: item.updateDate,
                updateUser: item.updateUser,
                version: item.version,
                rate: this.GetPercent(item.areaCount, item.areaTotalCount)
              };
            });

            this.companyarray = response.body.companyList.map(item => {
              return {
                companyCount: item.companyCount,
                companyName: item.companyName,
                companyTotalCount: item.companyTotalCount,
                createDate: item.createDate,
                createUser: item.createUser,
                hurMainId: item.hurMainId,
                id: item.id,
                updateDate: item.updateDate,
                updateUser: item.updateUser,
                version: item.version,
                rate: this.GetPercent(item.companyCount, item.companyTotalCount)
              };
            });

            this.loadingShow = false;
            // console.log(this.companyarray);
          } else {
            console.log("状态错误");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    // echart饼图
    // 此函数需要传入 数据数组 颜色数组 id
    drawChart(data, id, color) {
      let myChart = this.$echarts.init(document.getElementById(id));
      let titlelist = [];
      data.forEach(item => {
        titlelist.push(item.name);
      });
      let option = {
        color: color,
        legend: {
          // orient: 'vertical',
          // top: 'middle',
          // bottom: 10,
          // left: "center",
          // x: "center",
          bottom: "0",
          left: "center",
          width: "100%",
          align: "auto"

          // icon: "rect",
          // itemWidth: 20,
          // itemHeight: 20,
          // itemGap: 60,
          // textStyle: {
          //   fontSize: 14
          // },

          // data: titlelist
        },
        series: [
          {
            hoverAnimation: true, //扇区放大高亮
            name: "",
            type: "pie",
            radius: ["32%", "50%"],
            center: ["50%", "40%"],
            avoidLabelOverlap: true,
            label: {
              // position: "outside",
              // alignTo: "edge",
              fontSize: "18",
              align: "left",
              color: "#606266",
              margin: 0,
              formatter: function(value) {
                return [
                  "{a|" + value.data.name + "}",
                  "{b|" + value.data.value + "人" + "}",
                  "{c|" + value.data.rate + "}"
                ].join("\n");
                // var result = [],
                //   counter = 0;
                // var isFloat = String(a.data.num).indexOf(".");
                // if (isFloat != -1) {
                //   var n = parseInt(a.data.num).toFixed(0);
                //   a.data.num = n.toString();
                // }
                // var num_array = a.data.num.split(".");
                // var num = num_array[0];
                // console.log(num_array);
                // var newstr = "";
                // for (var i = num.length - 1; i >= 0; i--) {
                //   counter++;
                //   result.unshift(num[i]);
                //   if (!(counter % 3) && i != 0) {
                //     result.unshift(",");
                //   }
                // }
                // console.log(result);
                // if (num_array.length > 1) {
                //   newstr = result.join("");
                //   newstr += "." + num_array[1];
                //   return [
                //     "{a|" + a.name + "}",
                //     "{b|" + newstr + "万元" + "}",
                //     "{c|" + a.percent.toFixed(0) + "%" + "}"
                //   ].join("\n");
                // } else {
                //   return [
                //     "{a|" + a.name + "}",
                //     "{b|" + result.join("") + "万元" + "}",
                //     "{c|" + a.percent.toFixed(0) + "%" + "}"
                //   ].join("\n");
                // }
              },
              rich: {
                //控制说明的文字的样式
                a: {
                  lineHeight: 14,
                  fontSize: 12,
                  fontWeight: "bold"
                },
                b: {
                  lineHeight: 20,
                  fontSize: 12,
                  fontWeight: "bold"
                },
                c: {
                  lineHeight: 12,
                  fontSize: 12,
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              //控制连线的颜色
              show: true,
              length: 10,
              length2: 5
              // lineStyle: {
              //   color: "#D6D6D6"
              // }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      // echart 点击事件
      // let self = this;
      // myChart.on("click", function(params) {
      //   console.log(title);
      //   console.log(
      //     params.name,
      //     "name---",
      //     type,
      //     "type===",
      //     params.data,
      //     "data",
      //     params.title
      //   );
      //   let name =
      //     params.name == "水务及水环境治理"
      //       ? "0"
      //       : "" || params.name == "产业园及制造业"
      //       ? "1"
      //       : "" || params.name == "城市综合体"
      //       ? "2"
      //       : "";
      //   self.$router.push({
      //     name: "engineering-plate",
      //     query: {
      //       board: name,
      //       type: type,
      //       data: params.data.num,
      //       title: title
      //     }
      //   });
      // });
    },
    // 百分比计算
    GetPercent(num, total) {
      num = parseFloat(num);
      total = parseFloat(total);
      if (isNaN(num) || isNaN(total)) {
        return "-";
      }
      return total <= 0
        ? "0%"
        : Math.round((num / total) * 10000) / 100.0 + "%";
    },
    //   点击显示企业人员
    enterprisehandler(name, id) {
      console.log(name, id);
      const parameter = {
        condition: {
          companyName: `eq:${name}`,
          hurMainId: `eq:${id}`
        },
        number: 0,
        relation: "and",
        size: 100,
        sortDirection: "ASC",
        sortProperties: ["jobDesc", "name"]
      };
      this.Enterprisetitle = name;
      this.$api.personnel.staffing(parameter)
        .then(response => {
          console.log(response);
          if (response.state.code == 10000 && response.body.list.length) {
            this.EnterpriseStaffArr = response.body.list.map(item => {
              return {
                companyName: item.companyName,
                sex: item.sex,
                effdt: item.effdt,
                jobDesc: item.jobDesc,
                name: item.name,
                positionDesc: item.positionDesc,
                age: item.age
              };
            });
            this.EnterpriseStaff = true;
          } else {
            //   alert("没有数据或者状态错误！");
            console.log("没有数据或者状态错误！");
            this.EnterpriseStaffArr = [];
            this.EnterpriseStaff = true;
          }
        })
        .catch(accident => {
          console.log(accident);
        });
    },
    disposehandler(index) {
      if (index % 2) {
        return "flagclass_2";
      } else {
        return "flagclass_1";
      }
    }
  },
  components: { Loading }
};
</script>
  
<style scoped lang="scss">
.personnel {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  top: 0px;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  .application {
    margin-top: 60px;
    position: relative;
    .img {
      display: block;
      width: 90%;
      margin: 0 auto;
    }
    .info {
      position: absolute;
      top: 35px;
      left: 70px;
      .title {
        font-size: 40px;
        font-family: PingFang-SC-Heavy;
        color: #fff;
      }
      .number {
        .number {
          font-size: 70px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
          margin-right: 20px;
        }
        .unit {
          font-size: 50px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
        }
      }
    }
  }
  .positive {
    width: 90%;
    margin: 30px auto;
    display: flex;
    justify-content: space-between;
    .leftobj,
    .rightobj {
      width: 48%;
      height: 200px;
      background: linear-gradient(
        -48deg,
        rgba(255, 102, 72, 1),
        rgba(227, 4, 4, 1)
      );
      border-radius: 10px;
      position: relative;
      .info {
        position: absolute;
        top: 35px;
        left: 30px;
        .title {
          font-size: 40px;
          font-family: PingFang-SC-Heavy;
          color: #fff;
          display: flex;
          align-items: center;
          .titletext {
            font-size: 25px;
          }
        }
        .number {
          .number {
            font-size: 70px;
            font-family: PingFang-SC-Heavy;
            color: #fff;
            margin-right: 20px;
          }
          .unit {
            font-size: 50px;
            font-family: PingFang-SC-Heavy;
            color: #fff;
          }
        }
      }
    }
  }
  #duration,
  #distinction,
  #gender {
    background: #f4f1f4;
    margin-top: 30px;
    padding: 30px 0;
    position: relative;
    .chart_title {
      font-size: 38px;
      font-family: PingFang SC;
      font-weight: 800;
      color: rgba(0, 0, 0, 1);
      position: relative;
      &.chart_title::before {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        left: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
      &.chart_title::after {
        content: "";
        display: inline-block;
        width: 14px;
        height: 14px;
        background: rgba(89, 140, 249, 1);
        border-radius: 50%;
        position: absolute;
        right: 28%;
        top: 50%;
        transform: translateY(-50%);
      }
    }
    .businesstitle {
      position: absolute;
      top: 220px;
      left: 50px;
      display: flex;
      flex-direction: column;
      .item {
        position: relative;
        display: flex;
        align-items: center;
        font-family: PingFang SC;
        font-weight: 800;
      }
    }
  }
  #gender {
    .chart_title {
      &.chart_title::before {
        left: 25%;
      }
      &.chart_title::after {
        right: 25%;
      }
    }
  }
  #distinction {
    .chart_title {
      &.chart_title::before {
        left: 30%;
      }
      &.chart_title::after {
        right: 30%;
      }
    }
  }
  .statistics {
    display: flex;
    margin-top: 30px;
    .itemtext {
      text-align: center;
      flex: 1;
      padding: 20px 20px;
      font-size: 30px;
      font-weight: bold;
      color: black;
    }
    .active {
      background-color: red;
      color: #fff;
      border-radius: 10px;
    }
  }
}

.color_1 {
  .index {
    color: #6f9dfb !important;
  }
  .bg {
    background: #6f9dfb !important;
  }
  // .cont_item {
  //   background: #dea3fa !important;
  // }
  // .item_cont {
  //   background: #a578ff !important;
  // }
  .plan_title {
    &::before {
      background: #6f9dfb !important;
    }
    &::after {
      background: #6f9dfb !important;
    }
  }
}

.color_2 {
  .index {
    color: #ff6b35 !important;
  }
  .bg {
    background: #ff6b35 !important;
  }

  // .cont_item {
  //   background: #f9bca3 !important;
  // }
  // .item_cont {
  //   background: #f2810b !important;
  // }
  .plan_title {
    &::before {
      background: #ff6b35 !important;
    }
    &::after {
      background: #ff6b35 !important;
    }
  }
}
.color_3 {
  .index {
    color: #59cedb !important;
  }
  .bg {
    background: #59cedb !important;
  }

  // .cont_item {
  // background: #59cedb !important;
  // }
  // .item_cont {
  // background: #59cedb !important;
  // }
  .plan_title {
    &::before {
      background: #59cedb !important;
    }
    &::after {
      background: #59cedb !important;
    }
  }
}
.plate {
  background: #fff;
  padding: 40px 20px 50px 10px;
  .cont_item {
    // background: #82c9f8;
    font-size: 34px;
    color: #000;
    font-weight: 600;
    overflow: hidden;
  }
  .item {
    position: relative;
    line-height: 64px;
    height: 64px;
    font-size: 34px;
    margin-top: 20px;
    .index {
      font-size: 26px;
      color: #0da5eb;
      position: relative;
      top: 2px;
      white-space: nowrap;
    }
  }
  .item_cont {
    white-space: nowrap;
  }
  .index_list {
    padding-top: 10px;
    min-width: 5%;
    text-align: right;
  }
  .list {
    border-left: 1px solid #737373;
    border-bottom: 1px solid #737373;
    padding: 10px 20px 20px 10px;
    margin-left: 10px;
    min-width: 92%;
    .left {
      position: relative;
      width: 88%;
      .text {
        position: absolute;
        left: 0;
        width: 100%;
      }
      .bg {
        position: absolute;
        left: 0;
        height: 100%;
        background: #1aadff;
      }
    }
    .percent {
      font-size: 26px;
      width: 35%;
      text-align: right;
    }
  }

  .plan_title {
    font-size: 36px;
    position: relative;
    line-height: 50px;
    color: #000;
    text-align: center;
    font-weight: 600;

    &::before {
      content: "";
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-right: 15px;
      position: relative;
      top: -4px;
    }

    &::after {
      content: "";
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-left: 15px;
      position: relative;
      top: -4px;
    }
  }
  .plan_title_sub {
    font-size: 30px;
    &::before {
      content: "";
      width: 16px;
      height: 5px;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-right: 15px;
      position: relative;
      top: -4px;
    }

    &::after {
      content: "";
      width: 16px;
      height: 5px;
      background: #598cf9;
      display: inline-block;
      vertical-align: middle;
      margin-left: 15px;
      position: relative;
      top: -4px;
    }
  }
}

.enterprisedetail {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 200;
  background-color: rgba(0, 0, 0, 0.6);
  &.enterprise-enter-active,
  &.enterprise-leave-active {
    transition: all 0.4s;
    .enterprisecontent {
      transition: all 0.4s;
    }
  }
  &.enterprise-enter,
  &.enterprise-leave-to {
    opacity: 0;
    .enterprisecontent {
      transform: translate3d(0, 100%, 0);
    }
  }
  .enterprisecontent {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: #fff;
    border-radius: 30px 30px 0 0;
    .title {
      text-align: center;
      font-weight: bold;
      padding: 20px 0;
      display: -webkit-box;
      overflow: hidden;
      white-space: normal!important;
      text-overflow: ellipsis;
      word-wrap: break-word;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
    }
    .enterpriseinfo {
      height: 50vh;
      overflow-y: scroll;
      -webkit-overflow-scrolling: touch;
      .enterpriseitem,
      .enterprisetitle {
        border-bottom: 1px solid #ccc;
        display: flex;
        .jobDesc,
        .positionDesc,
        .effdt,
        .age,
        .name {
          flex: 1;
          white-space: nowrap;
          text-align: center;
          font-size: 30px;
        }
      }

      .enterpriseitem {
        padding: 10px 0;
        border-bottom: none;
        .jobDesc,
        .positionDesc,
        .effdt,
        .age,
        .name {
          height: 50px;
          line-height: 50px;
          font-size: 28px;
        }
      }
      .flagclass_1 {
        background: #dbeef3;
        color: #4a5182;
      }
    }
    .enterpriseaccident {
      text-align: center;
      font-weight: bold;
      height: 50vh;
      line-height: 50vh;
    }
  }
}
</style>
