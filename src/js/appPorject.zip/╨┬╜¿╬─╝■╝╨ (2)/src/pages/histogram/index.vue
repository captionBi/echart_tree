<template>
  <div class="histogramDiv">
    <div class="timeDiv" @click="showTime">
      <div class="timeesp">
        <span>日期:</span>
        <input type="text" v-model="valueTime" placeholder="选择时间" />
        <img src="../../assets/img/date.png" alt="" />
      </div>
    </div>
    <div id="myChart" style="height: 350px; width: 100%"></div>
    <div class="tables">
      <table class="fixedTable" border="1">
        <tr>
          <td>品种</td>
          <td class="fixedColumn"></td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
          <td>期限</td>
          <td>收益率</td>
        </tr>
        <tr v-for="(item, index) in tableHtList" :key="index">
          <td>{{ item.symbolName }}</td>
          <td class="fixedColumn"></td>
          <td>{{ item.qx1 }}</td>
          <td>{{ item.value1 }}</td>
          <td>{{ item.qx2 }}</td>
          <td>{{ item.value2 }}</td>
          <td>{{ item.qx3 }}</td>
          <td>{{ item.value3 }}</td>
          <td>{{ item.qx4 }}</td>
          <td>{{ item.value4 }}</td>
          <td>{{ item.qx5 }}</td>
          <td>{{ item.value5 }}</td>
          <td>{{ item.qx6 }}</td>
          <td>{{ item.value6 }}</td>
          <td>{{ item.qx7 }}</td>
          <td>{{ item.value7 }}</td>
          <td>{{ item.qx8 }}</td>
          <td>{{ item.value8 }}</td>
        </tr>
      </table>
    </div>
    <van-calendar v-model="shows" @confirm="changeTime" :min-date="minDate" />
  </div>
</template>

<script>
// import { DatetimePicker } from "vant";
import Vue from "vue";
import { Calendar } from "vant";

Vue.use(Calendar);
function getNowFormatDate() {
  //获取当前时间
  var date = new Date();
  var preDate = new Date(date.getTime() - 24 * 60 * 60 * 1000);
  var seperator1 = "-";
  var seperator2 = ":";
  var month =
    preDate.getMonth() + 1 < 10
      ? "0" + (preDate.getMonth() + 1)
      : preDate.getMonth() + 1;
  var strDate =
    preDate.getDate() < 10 ? "0" + preDate.getDate() : preDate.getDate();
  var currentdate =
    preDate.getFullYear() + seperator1 + month + seperator1 + strDate;
  return currentdate;
}

export default {
  components: {},
  data() {
    return {
      dataList: [],
      shows: false,
      minDate: new Date(2010, 1, 1),
      // valueTime: new Date(),
      valueTime: getNowFormatDate(),
      //userTime: getNowFormatDate(), //转换后的时间
      nameList: [],
      yearsList: [],
      intervalNum: 1,
      tableHtList: [],
    };
  },
  created() {
    this.tableChange();
    this.apifun();
  },
  methods: {
    tableChange() {
      let newDataList = [];
      this.$api.histogram.hasgetExcel(this.valueTime).then((res, index) => {
        res.body.data.map((item) => {
          console.log("item", item.symbolName);
          if (item.symbolName === "国债") {
            newDataList[0] = item;
          } else if (item.symbolName === "地方政府债(AAA)") {
            newDataList[1] = item;
          } else if (item.symbolName === "中期票据(AAA)") {
            newDataList[2] = item;
          } else if (item.symbolName === "有担保企业债(AAA)") {
            newDataList[3] = item;
          } else if (item.symbolName === "超短期融资券(AAA)") {
            newDataList[4] = item;
          }
        });
        this.tableHtList = newDataList;
      });
    },
    lineEcher(nameList, yearsList, data, intervalNum) {
      let myChart = this.$echarts.init(document.getElementById("myChart"));

      let option = {
        legend: {
          icon: "line",
          data: nameList ? nameList : [],
          formatter: (name) => {
            return name;
          },
          textStyle: {
            //文字颜色
            fontSize: 12,
          },
        },
        tooltip: {
          trigger: "axis",
          formatter: (params, ticket, callback) => {
            console.log("params", params);
            var showHtm = "";
            var year = "";
            for (var i = 0; i < params.length; i++) {
              //名称
              let text = params[i].seriesName;
              //值
              let value = params[i].value;
              let color = params[i].color;
              year = params[i].axisValue;
              showHtm += `
                    <div style="display: flex; align-items: center;">
                      <div style="width:10px; height:10px;border-radius: 50%; margin-right:8px;background:${color}"></div>
                      <div>${text}: </div>
                      <div>${value}%</div>
                    </div>`;
            }
            var yearDow = `<div>期限(年): ${year}</div>`;
            showHtm = yearDow + showHtm;
            return showHtm;
          },
        },
        grid: {
          left: "3%",
          right: "12%",
          bottom: "3%",
          top: "25%",
          containLabel: true,
        },
        xAxis: {
          name: "年",
          type: "category",
          axisLine: {
            //折线图x轴的样式
            lineStyle: {
              color: "#ccc",
            },
          },
          axisLabel: {
            //折线图x轴的值
            formatter: function (val) {
              return parseInt(val);
            },
            interval: Number(intervalNum), //折线图显示多少个刻度内容，number类型
          },
          nameTextStyle: {
            //折线图修改单位标段
            color: "gray",
            fontSize: 12,
            padding: 0,
            fontWeight: "bold",
          },
          splitArea: {
            areaStyle: {
              margin: 40,
            },
          },
          data: yearsList ? yearsList : [],
        },
        yAxis: {
          name: "%",
          type: "value",
          axisLine: {
            lineStyle: {
              color: "#ccc",
            },
          },
          nameTextStyle: {
            color: "gray",
            fontSize: 12,
            padding: 0,
            fontWeight: "bold",
          },
          splitLine: { show: false }, //去掉网格线
        },
        series: [
          {
            name: data[0] && data[0].symbolName ? data[0].symbolName : "",
            type: "line",
            showSymbol: false,
            hoverAnimation: false,
            smooth: true,
            data: data[0] && data[0].dateList ? data[0].dateList : [],
            color: "#005293",
          },
          {
            name: data[1] && data[1].symbolName ? data[1].symbolName : "",
            type: "line",
            showSymbol: false, //折线图是否显示圈圈
            hoverAnimation: false,
            smooth: true, //折线图是否变成曲线图
            data: data[1] && data[1].dateList ? data[1].dateList : [],
            color: "#e72742",
          },
          {
            name: data[2] && data[2].symbolName ? data[2].symbolName : "",
            type: "line",
            showSymbol: false,
            hoverAnimation: false,
            smooth: true,
            data: data[2] && data[2].dateList ? data[2].dateList : [],
            color: "#00B376",
          },
          {
            name: data[3] && data[3].symbolName ? data[3].symbolName : "",
            type: "line",
            showSymbol: false,
            hoverAnimation: false,
            smooth: true,
            data: data[3] && data[3].dateList ? data[3].dateList : [],
            color: "#F59A23",
          },
          {
            name: data[4] && data[4].symbolName ? data[4].symbolName : "",
            type: "line",
            showSymbol: false,
            hoverAnimation: false,
            smooth: true,
            data: data[4] && data[4].dateList ? data[4].dateList : [],
            color: "#7B4D12",
          },
        ],
      };
      myChart.setOption(option);
    },
    apifun() {
      this.$api.histogram
        .getInFoListPian(this.valueTime)
        .then((data, index) => {
          console.log("ceshi", data.body);
          this.nameList =
            data.body && data.body.symbolNameList
              ? data.body.symbolNameList
              : [];
          this.dataList = data.body && data.body.data ? data.body.data : [];
          this.yearsList = data.body && data.body.years ? data.body.years : [];
          if (data.body && data.body.years) {
            let maxNum = data.body.years.length; //获取数组的长度
            this.intervalNum = parseInt(maxNum / 6);
          }
          // let newData = data.body.years.map((res) => {
          //   return (res = parseInt(res));
          // });
          // this.yearsList = newData;
          this.$nextTick(() => {
            console.log("eeeeeee", this.intervalNum);
            this.lineEcher(
              this.nameList,
              this.yearsList,
              this.dataList,
              this.intervalNum
            );
          });
        });
    },
    changeTime(e) {
      this.valueTime = this.timeFormat(e);
      this.apifun();
      this.tableChange();
      this.shows = false;
    },
    timeFormat(date) {
      var seperator1 = "-";
      var seperator2 = ":";
      var month =
        date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1;
      var strDate = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
      var currentdate =
        date.getFullYear() + seperator1 + month + seperator1 + strDate;
      return currentdate;
    },
    showTime() {
      this.shows = true;
    },
  },
};
</script>

<style lang="scss" scoped>
.timeDiv {
  height: 80px;
  line-height: 80px;
  text-indent: 30px;
  display: flex;
  margin-bottom: 60px;
  .timeesp {
    width: 100%;
    display: flex;
    text-align: center;
    justify-content: center;
    align-items: center;
    input {
      width: 70%;
      height: 60px;
      text-indent: 10px;
      line-height: 60px;
      margin: 0 10px;
    }
    img {
      width: 45px;
      height: 45px;
      position: relative;
      left: -70px;
    }
  }
}
.tableList {
  overflow-x: scroll;
  white-space: nowrap;
  width: 94%;
  margin: 0 auto;
  & > div {
    width: 100%;
    position: relative;
    & > div {
      padding: 10px;
      display: inline-block;
      width: 120px;
      text-align: center;
      font-size: 32px;
      border-right: 1px solid #ccc;
      border-bottom: 1px solid #ccc;
    }
    & > div:nth-child(1) {
      border-left: 1px solid #ccc;
      position: absolute;
      left: 0;
      top: 0;
    }
  }
  & > div:nth-child(1) {
    font-weight: 600;
    & > div {
      border-top: 1px solid #ccc;
    }
  }
}
.tables {
  width: 96%;
  margin: 50px auto 0;
  overflow-x: scroll;
  background-color: #7c95b5;
}

.fixedTable {
  width: 200%;
  text-align: center;
  color: #fff;
  font-size: 26px;

  border-collapse: collapse;
}

.fixedTable tr {
  line-height: 30px;
  height: 60px;
  border: 1px solid #fff;
}

.fixedTable tr:first-child {
  height: 60px;
  background-color: cadetblue;
}

.fixedTable td:first-child {
  position: absolute;
  width: 200px;
  background-color: cadetblue;
  border: 1px solid #fff;
  margin: -1px 0px 0px -1px;
  height: 60px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.fixedColumn {
  width: 200px;
  height: 60px;
}
</style>
