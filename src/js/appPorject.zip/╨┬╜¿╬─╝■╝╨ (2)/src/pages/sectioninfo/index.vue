<template>
  <div class="index">
    <ul class="tab">
      <li
        class="tabitem"
        :class="{'active':currentindex == item.flag}"
        v-for="(item, index) in tablist"
        :key="index"
        @click="handoverhandler(item.flag)"
      >{{item.text}}</li>
    </ul>
    <div class="placeholder"></div>
    <component :is="cut" v-if="isRouterAlive"></component>
  </div>
</template>

<script type="text/ecmascript-6">
import Schedule from "./tab/schedule";
import Section from "./tab/section";
export default {
  name: "index",
  data() {
    return {
      tablist: [
        { text: "进度展示", flag: 1 },
        { text: "标段信息", flag: 2 }
      ],
      cut: Schedule,
      currentindex: 1,
      isRouterAlive: true
    };
  },
  provide(){
    return{
      reload: this.reload
    }
  },
  methods: {
    handoverhandler(flag) {
      this.currentindex = flag;
      flag == 1 ? (this.cut = Schedule) : (this.cut = Section);
    },
    reload(){
      this.isRouterAlive = false
      this.$nextTick(function () {
        this.isRouterAlive = true
      })
    }
  },
  components: { Schedule, Section }
};
</script>

<style scoped lang="scss">
.index {
  .tab {
    display: flex;
    height: 105px;
    .tabitem {
      font-size: 36px;
      font-family: Adobe Heiti Std;
      font-weight: bold;
      color: rgba(1, 1, 1, 1);
      opacity: 0.6;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .active {
      opacity: initial;
      position: relative;
      &.active::before {
        content: "";
        display: inline-block;
        width: 210px;
        height: 10px;
        background: rgba(0, 118, 240, 1);
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
  }
  .placeholder{
    height: 8px;
    background-color: #eaeaea;
  }
}
</style>
