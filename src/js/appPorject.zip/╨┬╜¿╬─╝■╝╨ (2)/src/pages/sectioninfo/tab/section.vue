<template>
  <div class="sectiontem">
    <div class="stagetext">{{stagetitle}}（{{stageprice}}亿元）</div>
    <div class="construction">施工单位：{{construction}}</div>
    <div class="infolist">
      <ul class="typelist">
        <li class="typeitem">
          <div class="serial" style="display:none;">01</div>
          <div class="title">工程信息</div>
          <ul class="text">
            <li class="textitem" v-show="constructionarray.length">
              <div class="textitemtitle">类别</div>
              <div class="textitemtitle">数量</div>
              <div class="textitemtitle">单位</div>
              <div class="textitemtitle">备注</div>
            </li>
            <li class="content" v-for="(item, index) in constructionarray" :key="index">
              <div class="contenttext">{{item.categoryName}}</div>
              <div class="contenttext">{{item.egProjectAmount}}</div>
              <div class="contenttext">{{item.egUnitName}}</div>
              <div class="contenttext">{{item.remark}}</div>
            </li>
            <li class="bulletin" v-show="!constructionarray.length">暂无数据</li>
          </ul>
        </li>
        <li class="typeitem">
          <div class="serial" style="display:none;">01</div>
          <div class="title">切面图信息</div>
          <van-swipe ref="vanswipe" class="my-swipe" :autoplay="0" indicator-color="white" @change="swipeChange" :loop="false" :initial-swipe="initialswipe">
            <van-swipe-item>
              <img v-show="swipearray[0].prevImage" class="img" :src="swipearray[0].prevImage" alt />
              <p v-show="!swipearray[0].prevImage">没有数据</p>
            </van-swipe-item>
            <van-swipe-item>
              <img class="img" :src="swipearray[1].cutaway" alt />
            </van-swipe-item>
            <van-swipe-item>
              <img v-show="swipearray[2].nextImage" class="img" :src="swipearray[2].nextImage" alt />
              <p v-show="!swipearray[2].nextImage">没有数据</p>
            </van-swipe-item>
          </van-swipe>
        </li>
        <li class="userinfo">
          <div class="user">
            <img src="@/assets/img/sectioninfo/portrait.png" alt />
            <div class="username">项目经理:张三</div>
          </div>
          <div class="phone">
            <img src="@/assets/img/sectioninfo/phone.png" alt />
            <div class="userphone">联系方式:13888888888</div>
          </div>
        </li>
      </ul>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script type="text/ecmascript-6">
import Loading from "../../../components/loading";
import { Toast } from "vant";
export default {
  name: "sectiontem",
  inject: ["reload"], //注入reload方法
  data() {
    return {
      constructionarray: [],
      loadingShow: true, //加载图层
      stagetitle: window.sessionStorage.getItem("bidName"), //标段
      stageprice: window.sessionStorage.getItem("markedPrice"), //标段金额
      construction: window.sessionStorage.getItem("constructionEnterprise"), //施工单位
      cutawayinfo: "",
      swipearray:[],
      initialswipe:1
    };
  },
  mounted() {
    // console.log(this.$route.params);
  },
  created() {
    if (window.sessionStorage.getItem("schedule")) {
      this.loadingShow = true;
      this._engineeringinfo(window.sessionStorage.getItem("schedule"));
      this._workingwellinfo(window.sessionStorage.getItem("schedule"));
    } else {
      this.loadingShow = true;
      this._engineeringinfo(this.$route.params.id);
      this._workingwellinfo(this.$route.params.id);
    }
    this._coordinatedetail(
      window.sessionStorage.getItem("projectId"),
      window.sessionStorage.getItem("node")
    );
  },
  methods: {
    _engineeringinfo(id) {
      this.$api.sectioninfo.engineeringinfo(id)
        .then(response => {
          console.log(response);
          if (response.state.code == 10000 && response.body.length) {
            this.constructionarray = response.body;
            this.loadingShow = false;
          } else {
            this.loadingShow = false;
            Toast("没有数据!");
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
        });
    },
    _coordinatedetail(projectId, node) {
      this.$api.sectioninfo.coordinatedetail(projectId, node)
        .then(response => {
          console.log(response);
          this.cutawayinfo = response.body[0].cutaway;
        })
        .catch(accident => {
          console.log(accident);
        });
    },
    _workingwellinfo(id){
      this.$api.sectioninfo.workingwellinfo(id)
      .then((response)=>{
        console.log(response);
        if (response.state.code == 10000) {
          this.swipearray.push(
            {prevImage:response.body.baseInfo.prevImage},
            {cutaway:response.body.baseInfo.bidMain.cutaway},
            {nextImage:response.body.baseInfo.nextImage}
          );
          console.log(this.swipearray);
        }
      })
      .catch((accident)=>{
        console.log(accident);
      })
    },
    // 监听滚动事件
    swipeChange: function(index) {
      this.constructionarray = [];
      this.loadingShow = true;
      console.log("当前 Swipe 索引：" + index);
      console.log(this.swipearray[index]);
      if (index == '0') {
        if (this.swipearray[index].prevImage) {
          this.$api.sectioninfo.coordinatedetail(window.sessionStorage.getItem("projectId"), Number(window.sessionStorage.getItem("node")) - 1)
            .then(response => {
              console.log(response);
              if (response.state.code == 10000 && response.body[0]) {
                this.stagetitle = response.body[0].bidName;
                this.stageprice = response.body[0].markedPrice ? response.body[0].markedPrice : 0;
                this.construction = response.body[0].constructionEnterprise;
                window.sessionStorage.setItem("bidName",response.body[0].bidName);
                window.sessionStorage.setItem("constructionEnterprise",response.body[0].constructionEnterprise);
                window.sessionStorage.setItem("markedPrice",response.body[0].markedPrice ? response.body[0].markedPrice : 0);
                window.sessionStorage.setItem("schedule",response.body[0].id);
                window.sessionStorage.setItem("projectId",response.body[0].projectId);
                window.sessionStorage.setItem("node",response.body[0].node);
                window.sessionStorage.setItem("swipeflag","0");
                this.$api.sectioninfo.engineeringinfo(response.body[0].id)
                  .then(response => {
                    console.log(response);
                    if (response.state.code == 10000 && response.body.length) {
                      this.constructionarray = response.body;
                      this.loadingShow = false;
                    } else {
                      this.loadingShow = false;
                      Toast("没有数据!");
                    }
                  })
                  .catch(accident => {
                    console.log(accident + ":意外错误");
                  });
                this.reload();
              }else{
                Toast("请求-1数据异常!");
              }
            })
            .catch(accident => {
              Toast("请求-1状态异常!+"+accident+"");
            });
        }else{
          clearTimeout(this.nexttime);
          this.nexttime = setTimeout(() => {
            this.$refs.vanswipe.next();
          }, 50);
          this.reload();
          this.loadingShow = false;
          Toast("禁止请求!");
          return false;
        }
      }else if (index == '1') {
        if (this.swipearray[index].cutaway) {
          let projectId = window.sessionStorage.getItem("projectId");
          let node = Number(window.sessionStorage.getItem("node"));
          if (window.sessionStorage.getItem("swipeflag") == '0') {
            node = Number(window.sessionStorage.getItem("node")) + 1;
          } else if (window.sessionStorage.getItem("swipeflag") == '2') {
            node = Number(window.sessionStorage.getItem("node")) - 1;
          }
          this.$api.sectioninfo.coordinatedetail(projectId, node)
            .then(response => {
              console.log(response);
              if (response.state.code == 10000 && response.body[0]) {
                this.stagetitle = response.body[0].bidName;
                this.stageprice = response.body[0].markedPrice ? response.body[0].markedPrice : 0;
                this.construction = response.body[0].constructionEnterprise;
                window.sessionStorage.setItem("bidName",response.body[0].bidName);
                window.sessionStorage.setItem("constructionEnterprise",response.body[0].constructionEnterprise);
                window.sessionStorage.setItem("markedPrice",response.body[0].markedPrice ? response.body[0].markedPrice : 0);
                window.sessionStorage.setItem("schedule",response.body[0].id);
                window.sessionStorage.setItem("projectId",response.body[0].projectId);
                window.sessionStorage.setItem("node",response.body[0].node);
                window.sessionStorage.removeItem("swipeflag");
                this.$api.sectioninfo.engineeringinfo(response.body[0].id)
                  .then(response => {
                    console.log(response);
                    if (response.state.code == 10000 && response.body.length) {
                      this.constructionarray = response.body;
                      this.loadingShow = false;
                    } else {
                      this.loadingShow = false;
                      Toast("没有数据!");
                    }
                  })
                  .catch(accident => {
                    console.log(accident + ":意外错误");
                  });
                this.reload();
              }else{
                Toast("请求-2数据异常!");
              }
            })
            .catch(accident => {
              Toast("请求-2状态异常!+"+accident+"");
            });
        }else{
          Toast("禁止请求!");
          return false;
        }
      }else if (index == '2') {
        if (this.swipearray[index].nextImage) {
          this.$api.sectioninfo.coordinatedetail(window.sessionStorage.getItem("projectId"), Number(window.sessionStorage.getItem("node")) + 1)
            .then(response => {
              console.log(response);
              if (response.state.code == 10000 && response.body[0]) {
                this.stagetitle = response.body[0].bidName;
                this.stageprice = response.body[0].markedPrice ? response.body[0].markedPrice : 0;
                this.construction = response.body[0].constructionEnterprise;
                window.sessionStorage.setItem("bidName",response.body[0].bidName);
                window.sessionStorage.setItem("constructionEnterprise",response.body[0].constructionEnterprise);
                window.sessionStorage.setItem("markedPrice",response.body[0].markedPrice ? response.body[0].markedPrice : 0);
                window.sessionStorage.setItem("schedule",response.body[0].id);
                window.sessionStorage.setItem("projectId",response.body[0].projectId);
                window.sessionStorage.setItem("node",response.body[0].node);
                window.sessionStorage.setItem("swipeflag","2");
                this.$api.sectioninfo.engineeringinfo(response.body[0].id)
                  .then(response => {
                    console.log(response);
                    if (response.state.code == 10000 && response.body.length) {
                      this.constructionarray = response.body;
                      this.loadingShow = false;
                    } else {
                      this.loadingShow = false;
                      Toast("没有数据!");
                    }
                  })
                  .catch(accident => {
                    console.log(accident + ":意外错误");
                  });
                this.reload();
              }else{
                Toast("请求-3数据异常!");
              }
            })
            .catch(accident => {
              Toast("请求-3状态异常!+"+accident+"");
            });
        }else{
          clearTimeout(this.prevtime);
          this.prevtime = setTimeout(() => {
            this.$refs.vanswipe.prev();
          }, 50);
          this.reload();
          this.loadingShow = false;
          Toast("禁止请求!");
          return false;
        }
      }
    }
  },
  computed: {},
  components: { Loading,[Toast.name]: Toast }
};
</script>

<style scoped lang="scss">
.sectiontem {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  top: 113px;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  .stagetext {
    font-size: 40px;
    font-family: PingFang SC;
    font-weight: bold;
    color: rgba(0, 118, 240, 1);
    text-align: center;
  }
  .construction {
    margin-bottom: 80px;
    font-size: 34px;
    font-family: PingFang SC;
    font-weight: bold;
    color: rgba(0, 0, 0, 1);
    text-align: center;
    position: relative;
    // &.construction::before {
    //   content: "";
    //   display: inline-block;
    //   width: 14px;
    //   height: 14px;
    //   background: rgba(89, 140, 249, 1);
    //   border-radius: 50%;
    //   position: absolute;
    //   left: 180px;
    //   top: 50%;
    //   transform: translateY(-50%);
    // }
    // &.construction::after {
    //   content: "";
    //   display: inline-block;
    //   width: 14px;
    //   height: 14px;
    //   background: rgba(89, 140, 249, 1);
    //   border-radius: 50%;
    //   position: absolute;
    //   right: 180px;
    //   top: 50%;
    //   transform: translateY(-50%);
    // }
  }
  .infolist {
    .typelist {
      .typeitem {
        .serial {
          font-size: 50px;
          font-family: FZDaHei-B02S;
          font-weight: 400;
          color: rgba(148, 148, 148, 1);
          text-align: center;
        }
        .title {
          font-size: 40px;
          font-family: PingFang SC;
          font-weight: bold;
          color: rgba(0, 0, 0, 1);
          text-align: center;
          position: relative;
          &.title::after {
            content: "";
            display: inline-block;
            width: 103px;
            height: 2px;
            border: 2px solid rgba(0, 118, 240, 1);
            background-color: rgba(0, 118, 240, 1);
            position: absolute;
            bottom: -6px;
            left: 50%;
            transform: translateX(-50%);
          }
        }
        .img {
          width: 100%;
          display: block;
          // margin: 30px 0;
        }
        .text {
          width: 90%;
          margin: 30px auto;
          border: 1px solid #ececec;
          box-sizing: border-box;
          .textitem {
            display: flex;
            width: 100%;
            height: 80px;
            background: rgba(234, 242, 252, 1);

            .textitemtitle {
              flex: 1;
              text-align: center;
              line-height: 80px;
              font-size: 34px;
              font-family: Adobe Heiti Std;
              font-weight: bold;
              color: rgba(1, 1, 1, 1);
              &.textitemtitle:nth-child(-n + 3) {
                border-right: 1px solid #ececec;
              }
            }
          }
          .content {
            display: flex;
            width: 100%;
            height: 80px;
            .contenttext {
              flex: 1;
              text-align: center;
              line-height: 80px;
              font-size: 34px;
              font-family: Adobe Heiti Std;
              font-weight: bold;
              color: rgba(1, 1, 1, 1);
              white-space: nowrap;
              &.contenttext:nth-child(-n + 3) {
                border-right: 1px solid #ececec;
              }
            }
          }
          .bulletin{
            text-align: center;
            font-weight: bold;
            padding: 20px;
          }
        }
      }
      .userinfo {
        display: none;
        padding: 30px;
        .user,
        .phone {
          display: flex;
          align-items: center;
          .username,
          .userphone {
            font-size: 40px;
            font-family: PingFang SC;
            font-weight: bold;
            color: rgba(0, 118, 240, 1);
          }
          img {
            width: 34px;
            height: 36px;
            margin-right: 30px;
          }
        }
        .user {
          margin-bottom: 20px;
        }
      }
    }
  }
}

.my-swipe {
  margin-top: 30px;
}

.my-swipe .van-swipe-item {
  color: #fff;
  font-size: 20px;
  height: 300px;
  line-height: 300px;
  text-align: center;
  // background-color: #39a9ed;
  img{
    height: 100%;
  }
  p{
    font-weight: bold;
    color: #333333;
  }
}
</style>
