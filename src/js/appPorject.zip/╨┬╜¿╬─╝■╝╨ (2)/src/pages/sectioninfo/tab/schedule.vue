<template>
  <div class="schedule">
    <div class="title">{{pagetitle}}</div>
    <div class="button">
      <div class="leftbtn" @click="prevbutton">上一标段</div>
      <div class="rightbtn" @click="nextbutton">下一标段</div>
    </div>

    <div class="databox">
      <ul class="table">
        <li class="progress" v-show="frequency.length">{{status}}</li>
        <li class="tableitem clearfix" v-for="(item, index) in frequency" :key="index">
          <div class="start">
            <div class="welltext">{{item.interval.workingWellStartName}}</div>
            <!-- <div class="progress" style="display:none;">进度正常</div> -->
          </div>

          <!-- 主体box -->
          <div class="percentage">
            <div class="textplan">
              <ul class="show">
                <li class="item" v-for="(item_2, index) in item.wells" :key="index">
                  <div class="toptext">{{GetPercent(item_2.finishAmount,item_2.totalAmount)}}</div>
                  <div class="bottom">
                    <div
                      class="children"
                      :style="{'height':GetPercent(item_2.finishAmount,item_2.totalAmount)}"
                    ></div>
                    <div class="childrentext">
                      {{item_2.workingProjectName}}
                      <br />
                      {{item_2.finishAmount}} {{item_2.unitName}}
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <!-- 线 -->
            <div
              :class="item_3.feederName == '左线'?'leftline':item_3.feederName == '右线'?'rightline':'centerline'"
              v-for="(item_3, index) in item.branch"
              :key="index"
            >
              <div
                :class="item_3.feederName == '左线'?'lefttitle':item_3.feederName == '右线'?'righttitle':'centertitle'"
              >
                <div class="text">{{item_3.feederName}}</div>
                <div class="number">{{GetPercent(item_3.finishAmount,item.interval.totalAmount)}}</div>
                <!-- <div class="number">{{item.interval.totalAmount}}</div> -->
              </div>
              <div class="sheet">
                <ul class="sheetlist">
                  <!-- <li
                    class="sheetitem active"
                    v-for="(item_4, index) in item_3.finishAmount"
                    :key="index"
                  >{{item_4}}</li>-->
                  <li
                    :class="classfunction(roundmethods(item_3.finishAmount),index+1)"
                    class="sheetitem"
                    v-for="(item_4, index) in roundmethods(item.interval.totalAmount)"
                    :key="index"
                  >{{item_4}}</li>
                </ul>
              </div>
            </div>
            <!-- 中线 -->
            <!-- <div class="centerline">
              <div class="centertitle">
                <div class="text">中线</div>
                <div class="number">50%</div>
              </div>
              <div class="sheet">
                <ul class="sheetlist">
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">2</li>
                  <li class="sheetitem">3</li>
                </ul>
              </div>
            </div>-->
            <!-- 右线 -->
            <!-- <div class="rightline">
              <div class="righttitle">
                <div class="text">右线</div>
                <div class="number">50%</div>
              </div>
              <div class="sheet">
                <ul class="sheetlist">
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem active">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">1</li>
                  <li class="sheetitem">2</li>
                  <li class="sheetitem">3</li>
                </ul>
              </div>
            </div>-->

            <!-- 最左侧区间 -->
            <div class="distance">{{item.interval.totalAmount}}</div>
            <!-- 区间文本 -->
            <div class="section" :class="{'flag' : item.interval.intervalName == '交通洞区间'}">{{item.interval.intervalName}}</div>
          </div>

          <div class="end">
            <div class="welltext">{{item.interval.workingWellEndName}}</div>
          </div>
        </li>

        <!-- <li class="tableitem clearfix">
          <div class="start">
            <div class="welltext">{{lastobj.workingWellEndName}}</div>
            <div class="progress" style="display:none;">进度正常</div>
          </div>

          <div class="percentage">
            <div class="textplan">
              <ul class="show">
                <li class="item" v-for="(item, index) in lastobj.lastwells" :key="index">
                  <div class="toptext">{{GetPercent(item.finishAmount,item.totalAmount)}}</div>
                  <div class="bottom">
                    <div
                      class="children"
                      :style="{'height':GetPercent(item.finishAmount,item.totalAmount)}"
                    ></div>
                    <div class="childrentext">
                      {{item.workingProjectName}}
                      <br />
                      {{item.finishAmount}} {{item.unitName}}
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </li>-->
      </ul>
    </div>

    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script type="text/ecmascript-6">
import { Toast } from "vant";
import Loading from "../../../components/loading";
export default {
  name: "schedule",
  data() {
    return {
      frequency: [],
      lastobj: {},
      loadingShow: true, //加载图层
      pagetitle: '', //当前标题
      currentnode:0,//当前node
      currentflag:0,//当前进度文本
      coordinatearray: [],//标段数组
    };
  },
  computed: {
    status() {
      return this.currentflag == "0" ? "进度正常" : "进度延迟";
    }
  },
  created() {
    window.sessionStorage.removeItem("swipeflag");
    if (window.sessionStorage.getItem("schedule")) {
      this._workingwellinfo(window.sessionStorage.getItem("schedule"));

    }else{
      this._workingwellinfo(this.$route.params.id);
    }
      this._coordinatelist();

      if (!window.sessionStorage.getItem("schedule")) {
        console.log('123');
          window.sessionStorage.setItem("bidName",this.$route.params.name);
          window.sessionStorage.setItem("constructionEnterprise",this.$route.params.construction);
          window.sessionStorage.setItem("markedPrice",this.$route.params.price);
          window.sessionStorage.setItem("schedule",this.$route.params.id);
          window.sessionStorage.setItem("projectId",this.$route.params.projectId);
          window.sessionStorage.setItem("node",this.$route.params.node);
          this.pagetitle = this.$route.params.name;
          this.currentnode = this.$route.params.node;
      }
  },
  mounted() {
    console.log(this.$route.params);
  },
  methods: {
    _workingwellinfo(id) {
      this.$api.sectioninfo.workingwellinfo(id)
        .then(response => {
          console.log(response);
          if (response.state.code == 10000 && response.body.intervals.length && response.body.wells.length) {
            this.pagetitle = response.body.baseInfo.bidMain.bidName;
            this.currentnode = response.body.baseInfo.bidMain.node;
            this.currentflag = response.body.baseInfo.bidMain.processStatus;
            // console.log(this.pagetitle,this.currentnode);
            // window.sessionStorage.setItem("bidName",response.body.baseInfo.bidMain.bidName);
            // window.sessionStorage.setItem("constructionEnterprise",response.body.baseInfo.bidMain.constructionEnterprise);
            // window.sessionStorage.setItem("markedPrice",response.body.baseInfo.bidMain.markedPrice);
            // window.sessionStorage.setItem("schedule",response.body.baseInfo.bidMain.id);
            // window.sessionStorage.setItem("projectId",response.body.baseInfo.bidMain.projectId);
            // window.sessionStorage.setItem("projectId",response.body.baseInfo.bidMain.projectId);
            // window.sessionStorage.setItem("node",response.body.baseInfo.bidMain.node);
            window.sessionStorage.removeItem("dataflag");
            var disposearray = [];
            // var indexflag = 0;
            var responseintervals = response.body.intervals;
            var responsewells = response.body.wells;
            for (let i = 0; i < responseintervals.length; i++) {
              var parentObj = {};
              var parentarray = [];
              // console.log(responseintervals[i].interval.workingWellEndId);
              for (let j = 0; j < responsewells.length; j++) {
                if (responseintervals[i].interval.workingWellEndId == responsewells[j].workingWellId) {
                  parentarray.push(responsewells[j]);
                }
              }
              parentObj.interval = responseintervals[i].interval;
              parentObj.branch = responseintervals[i].branch;
              parentObj.wells = parentarray;
              disposearray.push(parentObj);
            }
            console.log(disposearray);
            this.frequency = disposearray.sort((a, b) => {
              return a.interval.workingWellStartName.localeCompare(
                b.interval.workingWellStartName
              );
            });
            console.log(this.frequency);
            this.loadingShow = false;
            // console.log(this.lastobj);
          } else {
            this.pagetitle = response.body.baseInfo.bidMain.bidName;
            this.currentnode = response.body.baseInfo.bidMain.node;
            this.currentflag = response.body.baseInfo.bidMain.processStatus;
            this.loadingShow = false;
            this.frequency = [];
            // Toast("没有数据 三秒之后跳转!");
            // setTimeout(() => {
            //   window.history.back(-1);
            // }, 3000);
          }
        })
        .catch(accident => {
          console.log(accident + ":意外错误");
          Toast("没有数据!");

          this.frequency = [];
          this.loadingShow = false;
          window.sessionStorage.setItem("dataflag","0");
          // window.sessionStorage.removeItem("schedule");
          // this._workingwellinfo(this.$route.params.id);
          // setTimeout(() => {
          //   window.history.back(-1);
          // }, 3000);
        });
    },
    _coordinatelist(){
      this.$api.sectioninfo.coordinatelist()
      .then((response)=>{
        console.log(response);
        if (response.state.code == 10000 && response.body.list.length) {
          this.coordinatearray = response.body.list;
        }else{
          console.log("状态错误,或者没有数据");
        }
      })
      .catch((accident)=>{
        console.log(accident);
      })
    },
    _coordinatedetail(projectId,node){
      this.$api.sectioninfo.coordinatedetail(projectId,node)
      .then((response)=>{
        console.log(response);
      })
      .catch((accident)=>{
        console.log(accident);
      })
    },
    GetPercent(num, total) {
      /// <summary>
      /// 求百分比
      /// </summary>
      /// <param name="num">当前数</param>
      /// <param name="total">总数</param>
      num = parseFloat(num);
      total = parseFloat(total);
      if (isNaN(num) || isNaN(total)) {
        return "-";
      }
      return total <= 0
        ? "0%"
        : Math.round((num / total) * 10000) / 100.0 + "%";
    },
    roundmethods(value) {
      return Math.round(value / 100);
    },
    classfunction(value, index) {
      // console.log(value,index);
      if (value >= index) {
        return "active";
      } else {
        return "";
      }
    },
    // 点击上一个标段
    prevbutton(){
      clearTimeout(this.prevtime);
      var aloneflag = true;
      this.loadingShow = true;
      // console.log(this.coordinatearray);
      // console.log(Number(this.currentnode) - 1);
      for (let j = 0; j < this.coordinatearray.length; j++) {
        // console.log(this.coordinatearray[j].bidMain.node,Number(this.currentnode) - 1);
        if (this.coordinatearray[j].bidMain.node == Number(this.currentnode) - 1) {
          this.prevtime = setTimeout(() => {
            this.currentnode = this.coordinatearray[j].bidMain.node;
          }, 20);
          this._workingwellinfo(this.coordinatearray[j].bidMain.id);
          this.pagetitle = this.coordinatearray[j].bidMain.bidName;
          window.sessionStorage.setItem("bidName",this.coordinatearray[j].bidMain.bidName);
          window.sessionStorage.setItem("constructionEnterprise",this.coordinatearray[j].bidMain.constructionEnterprise);
          window.sessionStorage.setItem("markedPrice",this.coordinatearray[j].bidMain.markedPrice);
          window.sessionStorage.setItem("schedule",this.coordinatearray[j].bidMain.id);
          window.sessionStorage.setItem("projectId",this.coordinatearray[j].bidMain.projectId);
          window.sessionStorage.setItem("node",this.coordinatearray[j].bidMain.node);
          aloneflag = false;
          console.log(this.coordinatearray[j].bidMain.node);
        }
      }
      if (aloneflag) {
        Toast("没有对应的ID字段!");
        this.loadingShow = false;
      }
    },
    // 点击下一个标段
    nextbutton(){
      clearTimeout(this.nexttime);
      var aloneflag = true;
      this.loadingShow = true;
      // console.log(this.coordinatearray);
      // console.log(Number(this.currentnode) + 1);
      for (let i = 0; i < this.coordinatearray.length; i++) {
        // console.log(this.coordinatearray[i].bidMain.node,Number(this.currentnode) + 1);
        if (this.coordinatearray[i].bidMain.node == Number(this.currentnode) + 1) {
          this.nexttime = setTimeout(() => {
            this.currentnode = this.coordinatearray[i].bidMain.node;
          }, 20);
          this._workingwellinfo(this.coordinatearray[i].bidMain.id);
          this.pagetitle = this.coordinatearray[i].bidMain.bidName;
          window.sessionStorage.setItem("bidName",this.coordinatearray[i].bidMain.bidName);
          window.sessionStorage.setItem("constructionEnterprise",this.coordinatearray[i].bidMain.constructionEnterprise);
          window.sessionStorage.setItem("markedPrice",this.coordinatearray[i].bidMain.markedPrice);
          window.sessionStorage.setItem("schedule",this.coordinatearray[i].bidMain.id);
          window.sessionStorage.setItem("projectId",this.coordinatearray[i].bidMain.projectId);
          window.sessionStorage.setItem("node",this.coordinatearray[i].bidMain.node);
          aloneflag = false;
          console.log(this.coordinatearray[i].bidMain.node);
        }
      }
      if (aloneflag) {
        Toast("没有对应的ID字段!");
        this.loadingShow = false;
      }
    }
  },
  components: { Loading, [Toast.name]: Toast }
};
</script>

<style scoped lang="scss">
.schedule {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  top: 113px;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  .title {
    text-align: center;
    font-size: 40px;
    font-family: PingFang SC;
    font-weight: bold;
    color: rgba(255, 0, 0, 1);
    position: relative;
    &.title::before {
      content: "";
      display: inline-block;
      width: 20px;
      height: 20px;
      background: rgba(255, 0, 0, 1);
      border-radius: 50%;
      position: absolute;
      left: 260px;
      top: 50%;
      transform: translateY(-50%);
    }
    &.title::after {
      content: "";
      display: inline-block;
      width: 20px;
      height: 20px;
      background: rgba(255, 0, 0, 1);
      border-radius: 50%;
      position: absolute;
      right: 260px;
      top: 50%;
      transform: translateY(-50%);
    }
  }
  .button {
    margin-top: 40px;
    display: flex;
    justify-content: space-between;
    padding: 0 30px;
    .leftbtn,
    .rightbtn {
      cursor: pointer;
      width: 235px;
      height: 60px;
      line-height: 60px;
      background: rgba(250, 250, 250, 1);
      border: 2px solid rgba(0, 118, 240, 1);
      border-radius: 30px;
      font-family: PingFang SC;
      font-weight: bold;
      color: rgba(0, 118, 240, 1);
      text-align: center;
    }
  }
  .databox {
    .table {
      position: relative;
      .progress {
        position: absolute;
        top: 0;
        right: 30px;
        padding: 14px;
        background-color: #06c245;
        border-radius: 20px;
        font-size: 32px;
        font-family: PingFang SC;
        font-weight: 800;
        color: rgba(255, 255, 255, 1);
        // position: relative;
        &.progress::before {
          content: "";
          display: inline-block;
          width: 0;
          height: 0;
          border-width: 20px;
          border-style: solid;
          border-color: transparent #06c245 transparent transparent;
          position: absolute;
          left: -38px;
          top: 50%;
          transform: translateY(-50%);
        }
      }

      .tableitem {
        padding: 0 30px;
        margin-top: 40px;
        .end,
        .start {
          display: flex;
          justify-content: space-between;
          .welltext {
            text-align: center;
            width: 191px;
            height: 63px;
            line-height: 63px;
            background: rgba(0, 118, 240, 1);
            border-radius: 32px;
            font-size: 36px;
            font-family: PingFang SC;
            font-weight: bold;
            color: rgba(254, 254, 254, 1);
          }
          .progress {
            padding: 14px;
            background-color: #06c245;
            border-radius: 20px;
            font-size: 32px;
            font-family: PingFang SC;
            font-weight: 800;
            color: rgba(255, 255, 255, 1);
            position: relative;
            &.progress::before {
              content: "";
              display: inline-block;
              width: 0;
              height: 0;
              border-width: 20px;
              border-style: solid;
              border-color: transparent #06c245 transparent transparent;
              position: absolute;
              left: -38px;
              top: 50%;
              transform: translateY(-50%);
            }
          }
        }
        .percentage {
          width: 90%;
          margin: 0 auto;
          margin: 20px 30px;
          border-left: 10px solid #88c2ff;
          position: relative;
          // overflow: hidden;
          &.percentage::before {
            content: "";
            display: inline-block;
            width: 0;
            height: 0;
            border-width: 30px;
            border-style: solid;
            border-color: #88c2ff transparent transparent transparent;
            position: absolute;
            bottom: -35px;
            left: -35px;
          }
          .textplan {
            .show {
              display: flex;
              justify-content: flex-end;
              .item {
                margin-right: 50px;
                .toptext {
                  text-align: center;
                  width: 150px;
                  height: 100px;
                  line-height: 100px;
                  background-color: #e5f1fd;
                  font-size: 40px;
                  font-family: DS-Digital;
                  font-weight: bold;
                  color: #155bdb;
                }
                .bottom {
                  margin-top: 20px;
                  width: 150px;
                  height: 240px;
                  background: #cce4fc;
                  font-size: 28px;
                  font-family: PingFang SC;
                  font-weight: bold;
                  color: rgba(0, 0, 0, 1);
                  text-align: center;
                  position: relative;
                  .children {
                    width: 100%;
                    // height: 34%;
                    background-color: #7ab8f7;
                    position: absolute;
                    top: 0;
                    left: 0;
                  }
                  .childrentext {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate3d(-50%, -50%, 0);
                    width: 59%;
                  }
                }
              }
              .item:last-child {
                margin-right: 0;
              }
            }
          }
          .centerline,
          .rightline,
          .leftline {
            margin-top: 68px;
            .centertitle,
            .righttitle,
            .lefttitle {
              display: flex;
              align-items: center;
              .text {
                margin-left: 25px;
                margin-right: 70px;
                font-size: 36px;
                font-family: Adobe Heiti Std;
                font-weight: bold;
                color: rgba(1, 1, 1, 1);
              }
              .number {
                text-align: center;
                width: 200px;
                height: 100px;
                line-height: 100px;
                color: #155bdb;
                background-color: #e5f1fd;
                font-size: 50px;
                font-family: DS-Digital;
                font-weight: bold;
                position: relative;
                &.number::before {
                  content: "";
                  display: inline-block;
                  width: 0;
                  height: 0;
                  border-width: 30px;
                  border-style: solid;
                  border-color: transparent #0076f0 transparent transparent;
                  position: absolute;
                  left: -80px;
                  top: 50%;
                  transform: translateY(-50%);
                }
              }
            }
            .sheet {
              display: flex;
              justify-content: flex-end;
              margin-top: 30px;
              .sheetlist {
                width: 80%;
                display: flex;
                flex-wrap: wrap;
                .sheetitem {
                  text-align: center;
                  width: 60px;
                  height: 80px;
                  line-height: 80px;
                  font-size: 36px;
                  font-family: Adobe Heiti Std;
                  font-weight: bold;
                  color: rgba(0, 0, 0, 1);
                  border: 1px solid rgba(0, 118, 240, 1);
                  box-sizing: border-box;
                }
                .active {
                  background-color: #3391f3;
                  color: #fff;
                }
              }
            }
          }
          .rightline {
            .righttitle {
              .number {
                &.number::before {
                  content: "";
                  display: inline-block;
                  width: 0;
                  height: 0;
                  border-width: 30px;
                  border-style: solid;
                  border-color: transparent #0076f0 transparent transparent;
                  position: absolute;
                  left: -50px;
                  top: 25%;
                  transform: rotate(180deg);
                }
              }
            }
          }
          .centerline {
            .centertitle {
              .number {
                &.number::before {
                  display: none;
                }
              }
            }
          }

          .distance {
            font-size: 30px;
            font-family: PingFang SC;
            font-weight: bold;
            color: rgba(0, 118, 240, 1);
            position: absolute;
            left: -60px;
            top: 30%;
            transform: rotate(-90deg);
          }
          .section {
            font-size: 30px;
            font-family: PingFang SC;
            font-weight: bold;
            color: rgba(0, 0, 0, 1);
            position: absolute;
            left: -128px;
            top: 50%;
            transform: rotate(-90deg);
          }
          .flag{
            left: -100px;
          }
        }
      }
      // .tableitem:last-child {
      //   position: relative;
      //   .percentage {
      //     margin-top: 0;
      //     border-left: none;
      //     position: absolute;
      //     top: 0;
      //     right: 60px;
      //     &.percentage::before {
      //       display: none;
      //     }
      //   }
      // }
    }
  }
}

.clearfix:after {
  /*伪元素是行内元素 正常浏览器清除浮动方法*/
  content: "";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}
.clearfix {
  *zoom: 1; /*ie6清除浮动的方式 *号只有IE6-IE7执行，其他浏览器不执行*/
}
</style>
