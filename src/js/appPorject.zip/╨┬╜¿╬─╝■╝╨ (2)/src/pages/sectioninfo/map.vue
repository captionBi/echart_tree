<template>
  <div class="maptemplate">
    <div class="geographical">
      <img class="geographicalimage" src="@/assets/img/sectioninfo/map.jpg" alt />
      <!-- <div class="obscuration_1" @click="obscuration_1"></div>
      <div class="obscuration_2"></div>
      <div class="obscuration_3"></div>
      <div class="obscuration_4"></div>
      <div class="obscuration_5"></div>
      <div class="obscuration_6"></div>
      <div class="obscuration_7"></div>
      <div class="obscuration_8"></div>
      <div class="obscuration_9"></div>
      <div class="obscuration_10"></div>
      <div class="obscuration_11"></div>
      <div class="obscuration_12"></div>
      <div class="obscuration_13"></div>
      <div class="obscuration_14"></div>
      <div class="obscuration_15"></div>
      <div class="obscuration_16"></div> -->
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "maptemplate",
  data() {
    return {};
  },
  methods: {
    // obscuration_1(){
    //   alert('1')
    // }
  },
  components: {}
};
</script>

<style scoped lang="scss">
.maptemplate {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  position: fixed;
  // top: 105px;
  top: 0px;
  bottom: 0px;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 1);
  .geographical {
    height: 100%;
    width: 100%;
    overflow-y: scroll;
    // transform: rotate(-90deg);
    // position: relative;
    .geographicalimage {
      width: 100%;
      display: block;
    }
    // .obscuration_1{
    //   width: 33vw;
    //   height: 25vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: 71vh;
    //   left: 45vw;
    // }
    // .obscuration_2{
    //   width: 39vw;
    //   height: 35vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: 31vh;
    //   left: 51vw;
    //   transform: rotate3d(1,1,1,-10deg);
    // }
    // .obscuration_3{
    //   width: 40vw;
    //   height: 38vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -12vh;
    //   left: 75vw;
    //   transform: rotate3d(1,1,1,-1deg);
    // }
    // .obscuration_4{
    //   width: 34vw;
    //   height: 55vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -72vh;
    //   left: 92vw;
    //   transform: rotate3d(1,1,1,-1deg);
    // }
    // .obscuration_5{
    //   width: 34vw;
    //   height: 40vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -120vh;
    //   left: 88vw;
    //   transform: rotate3d(1,1,1,-1deg);
    // }
    // .obscuration_6{
    //   width: 34vw;
    //   height: 56vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -184vh;
    //   left: 83vw;
    //   transform: rotate3d(1,1,1,1deg);
    // }
    // .obscuration_7{
    //   width: 34vw;
    //   height: 52vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -242vh;
    //   left: 83vw;
    //   transform: rotate3d(1,1,1,1deg);
    // }
    // .obscuration_8{
    //   width: 34vw;
    //   height: 5vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -248vh;
    //   left: 79vw;
    //   transform: rotate3d(1,1,1,1deg);
    // }
    // .obscuration_9{
    //   width: 34vw;
    //   height: 56vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -311vh;
    //   left: 84vw;
    //   transform: rotate3d(1,1,1,-14deg);
    // }
    // .obscuration_10{
    //   width: 34vw;
    //   height: 90vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -408vh;
    //   left: 98vw;
    //   transform: rotate3d(1,1,1,0deg);
    // }
    // .obscuration_11{
    //   width: 31vw;
    //   height: 60vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -472vh;
    //   left: 99vw;
    //   transform: rotate3d(1,1,1,0deg);
    // }
    // .obscuration_12{
    //   width: 31vw;
    //   height: 135vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -625vh;
    //   left: 92vw;
    //   transform: rotate3d(1,1,1,7deg);
    // }
    // .obscuration_13{
    //   width: 31vw;
    //   height: 19vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -647vh;
    //   left: 64vw;
    //   transform: rotate3d(1,1,1,20deg);
    // }
    // .obscuration_14{
    //   width: 35vw;
    //   height: 7vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -658vh;
    //   left: 50vw;
    //   transform: rotate3d(1,1,1,20deg);
    // }
    // .obscuration_15{
    //   width: 35vw;
    //   height: 57vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -726vh;
    //   left: 26vw;
    //   transform: rotate3d(1,1,1,30deg);
    // }
    // .obscuration_16{
    //   width: 25vw;
    //   height: 14vh;
    //   background-color: #ccc;
    //   position: absolute;
    //   bottom: -740vh;
    //   left: 11vw;
    //   transform: rotate3d(1,1,1,0deg);
    // }
  }
}
</style>
