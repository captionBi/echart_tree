<template>
  <div class="vacation_record">
    <!-- <div class="record_count">
      <p class="vacation_total">{{totalCount}}</p>
      <p class="record">已休假天数</p>
    </div> -->
    <div class="vacation_count">
      <p class="vacation_tit">已休{{type}}天数</p>
      <p class="vacation_num"> <span class="big_txt">{{totalCount?totalCount:0}}</span> 天</p>
    </div>
    <div class="record_item" v-for="(item,index) in recordList" :key="index">
      <div class="record_item_title flex justify-between">
        <div class="record_name">
          <div class="name">{{item.name}}<span class="code">{{item.code}}</span></div>
        </div>
        <p class="type">{{item.type}}</p>
      </div>
      <p class="record_cont_item blue_cont">{{item.startDate+item.startDate?'至':''}}{{item.endDate}}</p>
      <div class="record_cont_item flex justify-between">
        <div>
          <span>总天数:</span>
          <span class="margin-left-xs">{{item.totalDay}}天</span>
        </div>
        <div>
          <span>休假天数:</span>
          <span class="margin-left-xs">{{item.vacationDay}}天</span>
        </div>
        <div>
          <span>公共假期:</span>
          <span class="margin-left-xs">{{item.pubDay}}天</span>
        </div>
      </div>
      <div class="record_cont_item flex justify-start">
        <p class="record_reason">请假事由:</p>
        <p class="">{{item.reason}}</p>
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
import loading from "../../components/loading";
export default {
  components: {
    loading
  },
  data() {
    return {
      totalCount: "",
      recordList: [],
      loadingShow: false,
      defindTime: "2020-06-30 20:20:20",
      code: "",
      userId: "",
      type: ""
    };
  },
  created() {
    // alert(this.userId)
    // alert("详情页")
    this.userId = this.$route.query.userId;
    this.type = this.$route.query.type;
    console.log(this.userId, this.type);
    this.getVacationDetail();
  },
  mounted() {
    // this.getCode()
  },
  methods: {
    getCode() {
      const code = this.getUrlParam("code"); // 截取路径中的code，如果没有就去微信授权，如果已经获取到了就直接传code给后台获取openId
      const local = window.location.href + "2";
      console.log(local, "local==============");
      const APPID = "ww1736e9ae98ad76c9";
      if (code) {
        this.getOpenId(code);
      } else {
        window.location.href =
          "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" +
          APPID +
          "&redirect_uri=" +
          encodeURIComponent(local) +
          "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
      }
    },
    getUrlParam(name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
      var r = window.location.search.substr(1).match(reg);
      console.log(r);
      if (r != null) return unescape(r[2]);
      return null;
    },
    getOpenId(code) {
      let param = {
        code: code,
        state: "oadatagetcode"
      };
      this.$api.vacation.getAuths(param).then(res => {
        if (res.state.code === 10000) {
          let userId = res.body.UserId;
          this.getVacationDetail(userId);
        }
      });
    },
    getVacationDetail() {
      this.loadingShow = true;
      let params = {
        userId: this.userId,
        oaType: this.type
      };
      this.$api.vacation.getVacationDetail(params).then(res => {
        this.loadingShow = false;
        this.totalCount = res.body.totalCount;
        this.recordList = res.body.list;
        console.log(this.recordList, "========");
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.vacation_count {
  margin: 20px;
  color: #fff;
  font-size: 40px;
  font-weight: 400;
  padding: 46px 40px;
  background: url("../../assets/img/vacation/banner2.png");
  background-size: cover;
  border-radius: 10px;
  height: 250px;
}

.vacation_num {
  text-align: center;
  margin-top: 20px;
}

.big_txt {
  font-size: 60px;
  font-weight: bold;
}

.vacation_record {
  .record_item {
    margin: 35px 20px;
    font-size: 32px;
    font-weight: bold;
    background: #fff;
    color: #657180;
    font-size: 28px;
    border-radius: 10px;
    padding: 23px 29px 15px 20px;
    border: 1px solid #0076f0;

    .blue_cont {
      color: #0076f0;
    }

    .record_reason {
      min-width: 140px;
    }

    .type {
      color: #965bb9;
    }

    .name {
      color: #131313;
      font-size: 34px;
    }

    .code {
      color: #657180;
      display: inline-block;
      margin-left: 20px;
    }

    .record_item_title {
      margin-top: 23px;
    }

    .record_cont_item {
      margin: 42px 0px;
    }
  }

  .record_count {
    background: url("../../assets/img/vacation/banner2.png");
    background-size: cover;
    line-height: 1;
    text-align: center;
    margin: 63px 20px 45px;
    // background: #fff;
    border-radius: 10px;

    .vacation_total {
      font-size: 80px;
      color: #0744c5;
      margin-bottom: 41px;
      padding-top: 75px;
    }

    .record {
      padding-bottom: 42px;
      color: #657180;
      font-size: 34px;
    }
  }

  .record_name {
    color: #464b5b;
  }

  .record_time {
    color: #9da7b3;
    font-size: 28px;
  }
}
</style>