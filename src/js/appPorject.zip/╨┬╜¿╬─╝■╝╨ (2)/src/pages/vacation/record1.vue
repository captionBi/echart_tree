<template>
  <div class="vacation_record">
    <div class="record_count">
      <p class="record">已休{{type}}天数</p>
      <p class="vacation_total">{{totalCount}} <span>天</span> </p>
    </div>
    <div class="record_item" v-for="(item,index) in recordList" :key="index">
      <div class="record_item_title flex justify-between">
        <div class="record_name">
          <div class="name">{{item.name}}<span class="code">{{item.code}}</span></div>
        </div>
        <p class="type">{{item.type}}</p>
      </div>
      <p class="record_cont_item blue_cont">{{item.startDate?item.startDate:defindTime}} 至
        {{item.endDate?item.endDate:defindTime}}</p>
      <div class="record_cont_item flex justify-between">
        <div>
          <span>总天数:</span>
          <span class="margin-left-xs">{{item.totalDay}}天</span>
        </div>
        <div>
          <span>休假天数:</span>
          <span class="margin-left-xs">{{item.vacationDay}}天</span>
        </div>
        <div>
          <span>公共假期:</span>
          <span class="margin-left-xs">{{item.pubDay}}天</span>
        </div>
      </div>
      <div class="record_cont_item flex justify-start">
        <p class="record_reason">请假事由:</p>
        <p class="margin-left-sm">{{item.reason}}</p>
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>
<script>
  import loading from '../../components/loading'
  export default {
    components: {
      loading
    },
    data() {
      return {
        totalCount: "",
        recordList: [],
        loadingShow: false,
        defindTime: '2020-06-30 20:20:20',
        code: '',
        type: ""
      }
    },
    created() {
      this.type = this.$route.query.type
    },
    // created () {
    //   // let data = {      "state": { "code": 10000, "message": "访问成功", "timestamp": 1593571182260 },
    //   //   "body": { "UserId": "txy_qiujie" }    }
    //   // this.$api.vacation.getAuth()
    //   // this.getCode()

    //   const appid = 'ww1736e9ae98ad76c9';
    //   const pageUrl = 'https://itest.gdhchina.com/index.html#/vacation';
    //   if (this.$storage.get('code')) {
    //     alert(1)
    //     // 如果本地已经存有code 说明是回退到了获取code的起始页面
    //     // this.code = localStorage.getItem("code");
    //     this.code = this.$storage.get('code')
    //     alert(this.code, '1')
    //     // alert('我是A页面从缓存取的code: ' + this.code)
    //   } else if (this.getUrlParam("code")) {

    //     alert(2)
    //     // 如果是链接上有code，说明是获取code的当前页面
    //     this.code = this.getUrlParam("code");
    //     // localStorage.setItem("code", this.code);
    //     alert(window.location.href)
    //     this.$storage.set('code', this.code, 1)
    //     alert(this.code, '2')
    //     // alert('我是获取code的页面从url取的code: ' + this.code)
    //   } else {
    //     alert(3)
    //     // 没有code 要去微信获取
    //     let timeStamp = new Date().getTime();
    //     let url =
    //       "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" +
    //       appid +
    //       "&response_type=code&scope=snsapi_base&redirect_uri=" +
    //       encodeURIComponent(pageUrl) +
    //       "&state=STATE#wechat_redirect";
    //     alert('我要去取code了: ' + url)
    //     // alert(url)
    //     window.location.replace(url);
    //   }
    //   alert(this.code + '======code')
    //   if (this.code) {
    //     this.getOpenId(this.code)
    //   }

    // },
    mounted() {
      // alert('页面2')
      const code = this.getUrlParam("code")
      const code1 = this.$methods.getUrlKey("code")
      this.getOpenId(code || code1)
    },
    methods: {
      getUrlParam(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        console.log(r);
        if (r != null) return unescape(r[2]);
        return null;
      },
      getOpenId(code) {
        let param = {
          code: code,
          state: 'oadatagetcode'
        };
        this.$api.vacation.getAuths(param).then(res => {
          if (res.state.code === 10000) {
            let userId = res.body.UserId
            this.getVacationDetail(userId)
          }
        })
      },
      getVacationDetail(userId) {
        this.loadingShow = true
        let params = {
          // userId: "ZhouYin",
          userId: userId,
          oaType: this.type
        }
        // alert(JSON.stringify(params))
        this.$api.vacation.getVacationDetail(params).then(res => {
          // alert(JSON.stringify(res))
          this.loadingShow = false
          this.totalCount = res.body.totalCount
          this.recordList = res.body.list
          console.log(this.recordList, '----------------')
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .vacation_record {
    .record_item {
      margin: 35px 20px;
      font-size: 32px;
      color: #657180;
      font-weight: bold;
      background: #fff;
      font-size: 28px;
      border-radius: 10px;
      padding: 23px 29px 15px 20px;
      border: 1px solid #0076f0;

      .blue_cont {
        color: #0076f0;
      }

      .record_reason {
        min-width: 160px;
      }

      .type {
        color: #965bb9;
      }

      .name {
        color: #131313;
        font-size: 34px;
      }

      .code {
        color: #657180;
        display: inline-block;
        margin-left: 20px;
      }

      .record_item_title {
        margin-top: 23px;
      }

      .record_cont_item {
        margin: 42px 0px;
      }
    }

    .record_count {
      height: 250px;
      padding: 42px 45px;
      background: url("../../assets/img/vacation/banner2.png");
      background-size: cover;
      line-height: 1;
      margin: 23px 20px 45px;
      border-radius: 10px;

      span {
        font-size: 40px;
      }

      .vacation_total {
        font-size: 80px;
        color: #fff;
        margin-bottom: 41px;
        text-align: center;
        // padding-top: 75px;
      }

      .record {
        padding-bottom: 42px;
        color: #fff;
        font-size: 34px;
      }
    }

    .record_name {
      color: #464b5b;
    }

    .record_time {
      color: #9da7b3;
      font-size: 28px;
    }
  }
</style>