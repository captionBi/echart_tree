<template>
  <div class="vacation">
    <div class="vacation_count">
      <p class="vacation_tit">已休假天数</p>
      <p class="vacation_num">
        <span class="big_txt">{{count}}</span> 天
      </p>
    </div>
    <div
      class="item_new"
      v-for="(item,index) in vList"
      :key="index"
      @click="goVacationDetail(item)"
    >
      <div class="vacation_item flex justify-start align-start">
        <div class="vacation_icon">
          <img :src="item.icon" alt />
        </div>
        <div class="type">{{item.key}}</div>
        <div class="record">
          <p class="total" v-if="item.value==0">0</p>
          <p class="total" v-else>{{item.value}}</p>
        </div>
        <van-icon v-if="item.value!=0" name="arrow" />
      </div>
    </div>
    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script>
import loading from "@/components/loading";
import { Toast, Icon } from "vant";
import axios from "axios";
import methods from "../../utils/methods";
export default {
  components: {
    loading,
    [Icon.name]: Icon,
    [Toast.name]: Toast
  },
  data() {
    return {
      vacationCount: {},
      loadingShow: true,
      count: 0,
      code: "",
      userId: "",
      uid: "",
      vList: []
    };
  },
  created() {
    // alert("页面2")
    // this.getVacationList()
    // this.uid = localStorage.getItem("userId");
    // if (this.uid) {
    //   this.userId = this.uid;
    //   this.getVacationList(this.uid);
    // } else {
    //   const code = this.getUrlParam("code");
    //   const code1 = this.$methods.getUrlKey("code");
    //   this.getOpenId(code || code1);
    // }
    // 调用日志方法
    this.inntRecord();
  },
  mounted() {
    // const code = this.getUrlParam("code")
    // const code1 = this.$methods.getUrlKey("code")
    // this.getOpenId(code || code1)
  },
  methods: {
    getUrlParam(name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
      var r = window.location.search.substr(1).match(reg);
      console.log(r);
      if (r != null) return unescape(r[2]);
      return null;
    },
    getOpenId(code) {
      let param = {
        code: code,
        state: "oadatagetcode"
      };
      this.$api.vacation.getAuths(param).then(res => {
        // window.alert(JSON.stringify(res));
        if (res.state.code === 10000) {
          this.userId = res.body.UserId;
          localStorage.setItem("userId", res.body.UserId);
          this.loadingShow = true;
          this.getVacationList(this.userId);
        }
      });
    },
    // 日志方法
    inntRecord() {
      this.logRecord();
      let self = this;
      let code = "";
      code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
      if (code == "") {
        var iCount = 0;
        var testCode = window.setInterval(function() {
          let codeTest = "";
          codeTest = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
          if (codeTest != "") {
            self.logRecord();
            window.clearInterval(testCode);
            // window.alert(codeTest);
          }
          iCount++;
          if (iCount == 10) {
            window.clearInterval(testCode);
          }
        }, 500);
      }
    },
    logRecord() {
      let code = "";
      code = methods.getUrlKey("code") ? methods.getUrlKey("code") : "";
      const APPID = "ww1736e9ae98ad76c9";
      let self = this;
      axios
        .post(
          "/gdh-com-hk-digital-accessloghistorysvc/api/service/logUserAccessInfo",
          {
            corpId: APPID,
            code: code,
            appCode: "vocationSearch",
            pageCode: "vacation",
            pageName: "休假查询",
            pageUrl: window.location.href
          }
        )
        .then(res => {
          //   window.alert(JSON.stringify(res));
          if (
            res.data != null &&
            res.data.body.body != null &&
            res.data.body.body.code != null &&
            res.data.body.body.code == "-100"
          ) {
            const local = window.location.href;
            window.location.href =
              "https://wechat.gdhchina.com/connect/oauth2/authorize?appid=" +
              APPID +
              "&redirect_uri=" +
              encodeURIComponent(local) +
              "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
          }
          if (res.data.body.code == "10000") {
            // window.alert(JSON.stringify(res));
            let userId = res.data.body.userId;
            this.userId = res.data.body.userId;
            // window.alert(userId + "2222222222");
            self.getVacationList(userId);
            // self.getVacationList("xl");
          }
        });
    },
    // 获取休假list
    getVacationList(userId) {
      let params = {
        userId: userId
      };
      this.$api.vacation
        .getVacationList(params)
        .then(res => {
          // window.alert(JSON.stringify(res) + "休假list");
          this.loadingShow = false;
          if (res.state.code == 10000) {
            if (res.body) {
              // window.alert(res.body, "body--------");
              this.vList = [
                {
                  key: "有薪年假",
                  value: res.body.yxxj,
                  icon: require("../../assets/img/vacation/year.png")
                },
                {
                  key: "事假",
                  value: res.body.sj,
                  icon: require("../../assets/img/vacation/thing.png")
                },
                {
                  key: "病假",
                  value: res.body.bj,
                  icon: require("../../assets/img/vacation/illness.png")
                },
                {
                  key: "加班补休",
                  value: res.body.jbbx,
                  icon: require("../../assets/img/vacation/work.png")
                },
                {
                  key: "产假",
                  value: res.body.cj,
                  icon: require("../../assets/img/vacation/baby.png")
                },
                {
                  key: "陪产假",
                  value: res.body.phj,
                  icon: require("../../assets/img/vacation/comp.png")
                },
                {
                  key: "丧假",
                  value: res.body.sj,
                  icon: require("../../assets/img/vacation/dill.png")
                },
                {
                  key: "婚假",
                  value: res.body.hj,
                  icon: require("../../assets/img/vacation/marry.png")
                },
                // {
                //   key: "公假",
                //   value: res.body.gjts,
                //   icon: require("../../assets/img/vacation/gj.png")
                // },
                {
                  key: "其他",
                  value: res.body.other,
                  icon: require("../../assets/img/vacation/other.png")
                }
              ];
              this.vacationCount = res.body;
              for (var i in res.body) {
                this.count += parseInt(res.body[i]);
              }
            }
          }
        })
        .catch(accident => {
          window.alert(JSON.stringify(accident) + "错误!");
        });
    },
    goVacationDetail(item) {
      // window.alert(JSON.stringify(item));
      // window.alert(item.key);
      // window.alert(item.value);
      if (item.value == 0) {
        Toast("暂无休假记录");
        return;
      } else {
        this.$router.push({
          name: "record",
          query: {
            type: item.key,
            userId: this.userId
          }
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
@import "./css/index.scss";

.vacation_icon {
  width: 40px;
  height: 54px;
}

.vacation_icon1 {
  width: 40px;
  height: 40px;
}

.vacation_count {
  margin: 20px;
  color: #fff;
  font-size: 40px;
  font-weight: 400;
  padding: 46px 40px;
  background: url("../../assets/img/vacation/banner .png");
  background-size: cover;
  border-radius: 10px;
  height: 250px;
}

.vacation_num {
  text-align: center;
  margin-top: 20px;
}

.big_txt {
  font-size: 60px;
  font-weight: bold;
}

//新样式
.vacation {
  .item_new {
    width: 50%;
    float: left;
    .vacation_item {
      height: 90px;
      line-height: 90px;
      padding: 0 40px 0 0;
      display: block;
    }
    .vacation_icon {
      width: 25%;
      float: left;
      text-align: center;
      img {
        width: 40px;
        display: inline-block;
        vertical-align: middle;
      }
    }
    .van-icon-arrow {
      position: absolute;
      top: 12px;
      color: #dadada;
      right: -3px;
      font-size: 22px;
    }
    .type {
      font-weight: normal;
      font-size: 30px;
      position: relative;
      padding-left: 5%;
      margin-left: 0 !important;
      width: 50% !important;
      float: left;
      &::before {
        content: "";
        position: absolute;
        width: 1px;
        background: #dbdbdb;
        top: 20px;
        bottom: 20px;
        left: 0;
      }
    }
    .record {
      border-left: none !important;
      width: 25%;
      float: left;
      padding-left: 0 !important;
      text-align: right;
    }
  }
}
</style>
