<template>
  <div class="vacation">
    <div class="vacation_count">
      <p class="vacation_tit">已休假天数</p>
      <p class="vacation_num">
        <span class="big_txt">{{ count }}</span
        >天
      </p>
    </div>
    <div
      class="item_new"
      v-for="(item, index) in vList"
      :key="index"
      @click="goVacationDetail(item.key, item.value)"
    >
      <div class="vacation_item flex justify-start align-start">
        <div class="vacation_icon"><img :src="item.icon" alt="" /></div>
        <div class="type">{{ item.key }}</div>
        <div class="record">
          <p class="total" v-if="item.value == 0">0</p>
          <p class="total" v-else>{{ item.value }}</p>
        </div>
        <van-icon v-if="item.value != 0" name="arrow" />
      </div>
    </div>
    <loading v-if="loadingShow"> </loading>
  </div>
</template>

<script>
import loading from "@/components/loading";
import { Toast, Icon } from "vant";
export default {
  components: {
    loading,
    [Icon.name]: Icon,
    [Toast.name]: Toast,
  },
  data() {
    return {
      vacationCount: {},
      loadingShow: true,
      count: 0.0,
      code: "",
      // userId: "",
      uid: "",
      vList: [],
    };
  },
  created() {
    // localStorage.setItem("userId", 'xl')
    // this.uid = localStorage.getItem('userId')
    // if (this.uid) {
    //     this.getVacationList(this.uid)
    // } else {
    //     this.getCode()
    // }
    // localStorage.removeItem('userId')

    //   this.uid = localStorage.getItem("userId");
    //      console.log(this.uid)
    if (this.uid) {
      this.userId = this.uid;
      this.getVacationList(this.uid);
    } else {
      this.getCode();
    }
    // this.getVacationList();
  },
  mounted() {
    // this.getCode()
  },
  methods: {
    getCode() {
      const code = this.getUrlParam("code"); // 截取路径中的code，如果没有就去微信授权，如果已经获取到了就直接传code给后台获取openId
      const local = window.location.href + "2";
      const APPID = "ww1736e9ae98ad76c9";
      if (code) {
        // console.log(code)
        //   this.getOpenId(code);
        //   console.log(document.cookie)
      } else {
        window.location.href =
          "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" +
          APPID +
          "&redirect_uri=" +
          encodeURIComponent(local) +
          "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
      }
    },

    getUrlParam(name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
      var r = window.location.search.substr(1).match(reg);
      console.log(r);
      if (r != null) return unescape(r[2]);
      return null;
    },

    //   getOpenId(code) {
    //     let param = {
    //       code: code,
    //       state: "oadatagetcode"
    //     };
    //     this.$api.vacation.getAuths(param).then(res => {
    //         console.log(res);
    //       if (res.body.UserId) {
    //         localStorage.setItem("userId", res.body.UserId);
    //       }
    //       if (res.state.code === 10000) {
    //         this.userId = res.body.UserId;
    //         this.getVacationList(this.userId);
    //       }
    //     });
    //   },
    // 获取休假list
    getVacationList() {
      // let params = {
      //   userId: userId
      // };
      this.$api.vacation.getVacationList().then((res) => {
        console.log(res);
        this.loadingShow = false;
        if (res.state.code == 10000) {
          if (res.body) {
            // console.log(res.body, "body--------");
            this.vList = [
              {
                key: "有薪年假",
                value: res.body.yxxj,
                icon: require("../../assets/img/vacation/year.png"),
              },
              {
                key: "事假",
                value: res.body.sj,
                icon: require("../../assets/img/vacation/thing.png"),
              },
              {
                key: "病假",
                value: res.body.bj,
                icon: require("../../assets/img/vacation/illness.png"),
              },
              {
                key: "加班补休",
                value: res.body.jbbx,
                icon: require("../../assets/img/vacation/work.png"),
              },
              {
                key: "产假",
                value: res.body.cj,
                icon: require("../../assets/img/vacation/baby.png"),
              },
              {
                key: "陪产假",
                value: res.body.phj,
                icon: require("../../assets/img/vacation/comp.png"),
              },
              {
                key: "丧假",
                value: res.body.sj,
                icon: require("../../assets/img/vacation/dill.png"),
              },
              {
                key: "婚假",
                value: res.body.hj,
                icon: require("../../assets/img/vacation/marry.png"),
              },
              {
                key: "公假",
                value: res.body.gjts,
                icon: require("../../assets/img/vacation/gj.png"),
              },
              {
                key: "其他",
                value: res.body.other,
                icon: require("../../assets/img/vacation/other.png"),
              },
            ];
            this.vacationCount = res.body;
            for (var i in res.body) {
              this.count += parseInt(res.body[i]);
            }
          }
        }
      });
    },
    goVacationDetail(type, value) {
      if (value == 0) {
        Toast("暂无休假记录");
        return;
      } else {
        if (type == "公假") {
          type = "公假天数";
        }
        this.$router.push({
          name: "record",
          query: {
            type: type,
            userId: this.userId,
          },
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped>
@import "./css/index.scss";

.vacation_count {
  margin: 20px;
  color: #fff;
  font-size: 40px;
  font-weight: 400;
  padding: 46px 40px;
  background: url("../../assets/img/vacation/banner .png");
  background-size: cover;
  border-radius: 10px;
  height: 250px;
}

.vacation_num {
  text-align: center;
  margin-top: 20px;
}

.big_txt {
  font-size: 60px;
  font-weight: bold;
}

//新样式
.vacation {
  .item_new {
    width: 50%;
    float: left;
    .vacation_item {
      height: 90px;
      line-height: 90px;
      padding: 0 40px 0 0;
      display: block;
    }
    .vacation_icon {
      width: 25%;
      float: left;
      text-align: center;
      img {
        width: 40px;
        display: inline-block;
        vertical-align: middle;
      }
    }
    .van-icon-arrow {
      position: absolute;
      top: 12px;
      color: #dadada;
      right: -3px;
      font-size: 22px;
    }
    .type {
      font-weight: normal;
      font-size: 30px;
      position: relative;
      padding-left: 5%;
      margin-left: 0 !important;
      width: 50% !important;
      float: left;
      &::before {
        content: "";
        position: absolute;
        width: 1px;
        background: #dbdbdb;
        top: 20px;
        bottom: 20px;
        left: 0;
      }
    }
    .record {
      border-left: none !important;
      width: 25%;
      float: left;
      padding-left: 0 !important;
      text-align: right;
    }
  }
}
</style>