<template>
  <div class="location">

  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'location',
  data() {
    return {

    }
  },
  components: {}
}
</script>

<style scoped lang="scss">
</style>
