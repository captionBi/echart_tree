<template>
  <div class="ranking">
    <div class="feimabang">
      <div class="feimabox">
        <div class="feimachuang">
          <img src="../../assets/img/ranking/groupbox.png" alt />
        </div>
        <div class="feimaImg">
          <img src="../../assets/img/ranking/group.png" alt />
        </div>
        <div class="feimafontone">
          {{ rankName }}
        </div>
        <div class="feimafonttwo">第{{ currcount }}期 总{{ tolCount }}期</div>
      </div>
      <div class="feimacontent">
        <div
          class="oneData"
          v-for="(item, index) in topList"
          :class="index !== 0 ? 'overclass' : ''"
          :key="index"
        >
          <div class="proName">{{ item.projectName }}</div>
          <div class="yearPlan">
            <div class="leftwidth">年投资计划</div>
            <div>
              ￥
              <span style="color: red">{{ item.yearInvestmentPlanCount }}</span>
              万元
            </div>
            <div>上榜{{ item.rankingCount }}次</div>
          </div>
          <div class="propross">
            <div class="leftwidth">投资进度</div>
            <div class="goall">
              <div
                :style="{ width: `${parseInt(item.investmentProgress)}%` }"
              ></div>
            </div>
            <div>
              <span style="color: red">{{
                parseInt(item.investmentProgress)
              }}</span>
              %
            </div>
          </div>
          <div class="proleader">
            <div class="leftwidth">项目负责人</div>
            <div>{{ item.projectLeader }}</div>
          </div>
          <div class="prounit">
            <div class="leftwidth">建设单位</div>
            <div>{{ item.constructionUnit }}</div>
          </div>
          <div class="mainPro">
            <div class="leftwidth">主要成绩</div>
            <div>{{ item.remark }}</div>
          </div>
          <div class="leftpic" v-if="index === 0">
            <img src="../../assets/img/ranking/aa.png" alt />
          </div>
          <div class="leftfont" v-else>
            <div>NO{{ index + 1 }}</div>
          </div>
        </div>
      </div>
      <div class="boxImg">
        <img src="../../assets/img/ranking/housebottom.png" alt />
      </div>
    </div>
    <div class="woniubang">
      <div class="woniutop">
        <div class="woniubaijing">
          <img src="../../assets/img/ranking/woniubing.jpg" alt />
        </div>
      </div>
      <div class="woniufont">蜗牛榜第{{ currcount }}期 总{{ tolCount }}期</div>
      <div class="woniucontent">
        <div class="oneData" v-for="(item, index) in lastList" :key="index">
          <div class="proName">
            <div class="espDivImg">
              <img src="../../assets/img/ranking/woniu.png" />
              <span>{{ index + 1 }}</span>
            </div>
            <div style="margin-left: 10px">{{ item.projectName }}</div>
          </div>
          <div class="yearPlan">
            <div class="leftwidth">年投资计划</div>
            <div>
              ￥
              <span style="color: #061d3f; font-weight: 600">{{
                item.yearInvestmentPlanCount
              }}</span>
              万元
            </div>
            <div>
              上榜
              <span style="color: yellow">{{ item.rankingCount }}</span> 次
            </div>
          </div>
          <div class="propross">
            <div class="leftwidth">投资进度</div>
            <div class="goall">
              <div
                :style="{ width: `${parseInt(item.investmentProgress)}%` }"
              ></div>
            </div>
            <div>
              <span style="color: #061d3f; font-weight: 600">{{
                parseInt(item.investmentProgress)
              }}</span>
              %
            </div>
          </div>
          <div class="proleader">
            <div class="leftwidth">项目负责人</div>
            <div>{{ item.projectLeader }}</div>
          </div>
          <div class="proleader">
            <div class="leftwidth">建设单位</div>
            <div>{{ item.constructionUnit }}</div>
          </div>
          <div class="mainPro">
            <div class="leftwidth">主要问题</div>
            <div>{{ item.remark }}</div>
          </div>
        </div>
      </div>
    </div>
    <div
      @click="goLeft"
      id="leftClass"
      v-if="Number(this.currcount) > 1"
      style="
        position: fixed;
        top: 50%;
        left: 10px;
        width: 40px;
        height: 40px;
        background: black;
        opacity: 0.2;
      "
    >
      <div
        style="
          position: relative;
          top: 27%;
          left: 31%;
          width: 20px;
          height: 20px;
          border-top: 3px solid #fff;
          border-right: 3px solid #fff;
          transform: rotate(-135deg);
        "
      ></div>
    </div>

    <div
      @click="goRight"
      class="rightClass"
      style="
        position: fixed;
        top: 50%;
        right: 10px;
        width: 40px;
        height: 40px;
        background: black;
        opacity: 0.2;
      "
      v-if="Number(currcount) < Number(tolCount)"
    >
      <div
        style="
          position: relative;
          top: 27%;
          left: 10%;
          width: 20px;
          height: 20px;
          border-top: 3px solid #fff;
          border-right: 3px solid #fff;
          transform: rotate(45deg);
        "
      ></div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import feimapic from "@/assets/img/ranking/bg1.png";
import woniupic from "@/assets/img/ranking/dibg.png";
import methods from "../../utils/methods";
import axios from "axios";
export default {
  name: "ranking",
  data() {
    return {
      showBox: false,
      pegasus: "",
      snail: "",
      topList: [],
      lastList: [],
      currcount: 0, //当前期数
      tolCount: 1, //总期数
      rankName: "",
      dataObj: {},
      showdataBox: false,
      types: "feima",
      typeindex: 1,
    };
  },
  mounted() {
    window.addEventListener("scroll", this.scrollToTop);
  },
  methods: {
    celboxclick() {
      this.showBox = false;
    },
    celbox() {
      this.showdataBox = false;
      // @click="showdataclick('feima', item, index)"
    },
    showdataclick(type, e, index) {
      this.types = type;
      this.dataObj = e;
      this.typeindex = index;
      this.showdataBox = true;
    },
    scrollTop() {
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      // 实现滚动效果
      const timeTop = setInterval(() => {
        document.body.scrollTop = document.documentElement.scrollTop = top -= 50;
        if (top <= 0) {
          clearInterval(timeTop);
        }
      }, 10);
    },
    goLeft() {
      console.log("aaaa", Number(this.currcount) - 1);
      if (Number(this.currcount) - 1 < 1) {
        // alert('已经第一期了！')
        this.showBox = true;
        return;
      } else {
        this.scrollTop();
        this.apifun(Number(this.currcount) - 1);
      }
    },
    goRight() {
      if (Number(this.currcount) + 1 > Number(this.tolCount)) {
        this.showBox = true;
        // alert('已经最后一期了！')
        return;
      } else {
        this.scrollTop();
        this.apifun(Number(this.currcount) + 1);
      }
    },
    apifun(e) {
      this.$api.rankingsvc.getDataLastedRank(e).then((data, num) => {
        console.log("ceshi", data);
        let pegasusData = data.body.pegasus;
        let lastListData = data.body.snail;
        pegasusData.forEach((res) => {
          res.collapseStatus = false;
          res.img = feimapic;
        });
        lastListData.forEach((res) => {
          res.collapseStatus = false;
          res.img = woniupic;
        });
        this.currcount = data.body.rankMain.count;
        this.tolCount = data.body.totalRank;
        this.rankName = data.body.rankMain.rankName;
        this.topList = pegasusData;
        this.lastList = lastListData;
      });
    },
  },
  mounted() {},
  created() {
    this.apifun(0);
  },
};
</script>

<style scoped lang="scss">
.ranking {
  position: relative;
}
.zhezhaoceng {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9;
  display: flex;
  justify-content: center;
  align-items: center;
  .contnt {
    position: relative;
    z-index: 11;
    width: 92% !important;
    border-radius: 18px;
    .oneData {
      background: url("../../assets/img/ranking/bg1.png") top right no-repeat;
      background-size: 100% 100%;
      width: 100%;
      margin: 0 auto 26px;
      border-radius: 8px;
      padding: 30px 30px;
      position: relative;
      & > div {
        font-size: 26px;
        margin-top: 10px;
        .leftwidth {
          width: 140px;
          font-size: 32px;
          margin-right: 10px;
        }
      }
      .espDivImg {
        position: relative;
        top: 4px;
        img {
          width: 60px;
          height: 60px;
        }
        span {
          position: absolute;
          top: -8px;
          left: -16px;
          bottom: 0;
          right: 0;
          margin: auto;
          width: 5px;
          height: 5px;
          line-height: 5px;
          text-align: center;
          color: #061d3f !important;
        }
      }
      & > div:nth-child(2) {
        display: flex;
      }
      & > div:nth-child(3) {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      & > div:nth-child(6),
      & > div:nth-child(5),
      & > div:nth-child(4) {
        display: flex;
        & > div:nth-child(2) {
          flex: 1;
        }
      }
      .proName {
        font-size: 36px;
        font-weight: 600;
        display: flex;
        align-items: center;
        .espDivImg {
          position: relative;
          top: 4px;
          img {
            width: 60px;
            height: 60px;
          }
          span {
            position: absolute;
            top: -8px;
            left: -16px;
            bottom: 0;
            right: 0;
            margin: auto;
            width: 5px;
            height: 5px;
            line-height: 5px;
            text-align: center;
            color: #061d3f !important;
          }
        }
      }
      .yearPlan {
        font-size: 28px;
        & > div:nth-child(2) {
          margin-right: 30px;
          font-size: 28px;
          flex: 1;
        }
        & > div:nth-child(3) {
          background: crimson;
          padding: 0 10px;
          color: white;
          border-radius: 6px;
        }
      }
      .propross {
        & > div:nth-child(2) {
          flex: 1;
        }
        .goall {
          position: relative;
          border-radius: 10px;
          background: #d4d4d4;
          height: 16px;
          margin: 15px 15px 15px 0;
          & > div {
            width: 78%;
            height: 16px;
            position: absolute;
            left: 0;
            top: 0;
            background: #fbd007;
            border-radius: 10px;
          }
        }
      }
      .leftpic {
        position: absolute;
        left: -40px;
        top: -70px;
        img {
          width: 100px;
          height: 100px;
        }
      }
      .leftfont {
        position: absolute;
        left: -10px;
        top: 0px;
        background: red;
        color: white;
        padding: 2px 20px;
        font-size: 20px;
        transform: rotate(-40deg);
      }
    }
    .clos {
      position: absolute;
      bottom: -60px;
      left: 0;
      width: 100%;
      color: white;
      text-align: center;
      span {
        display: inline-block;
        border: 1px solid #ccc;
        width: 60px;
        height: 60px;
        line-height: 60px;
        border-radius: 50%;
      }
    }
  }
}
.feimabang {
  position: relative;
  background: red;
  background: url("../../assets/img/ranking/bg.png") 100% 100% top left;
  padding-bottom: 140px;
  .feimabox {
    width: 100%;
    position: relative;
    .feimachuang {
      img {
        width: 100%;
        height: 120%;
        display: inline-block;
      }
    }
    .feimaImg {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      margin: auto;
    }
    .feimafontone {
      width: 100%;
      position: absolute;
      bottom: 80px;
      color: white;
      text-align: center;
      font-size: 32px;
    }
    .feimafonttwo {
      width: 100%;
      position: absolute;
      bottom: 30px;
      color: white;
      text-align: center;
      font-size: 32px;
    }
  }
  .feimacontent {
    .oneData {
      background: url("../../assets/img/ranking/bg1.png") top right no-repeat;
      background-size: 100% 100%;
      width: 86%;
      margin: 0 auto 26px;
      border-radius: 8px;
      padding: 30px 30px;
      position: relative;
      & > div {
        font-size: 26px;
        margin-top: 10px;
        .leftwidth {
          width: 140px;
          margin-right: 10px;
        }
      }
      & > div:nth-child(2) {
        display: flex;
      }
      & > div:nth-child(3) {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      & > div:nth-child(6),
      & > div:nth-child(5),
      & > div:nth-child(4) {
        display: flex;
        & > div:nth-child(2) {
          flex: 1;
        }
      }
      .proName {
        font-size: 36px;
        font-weight: 600;
      }
      .yearPlan {
        & > div:nth-child(2) {
          margin-right: 30px;
        }
        & > div:nth-child(3) {
          background: crimson;
          padding: 0 20px;
          color: white;
          border-radius: 6px;
        }
      }
      .propross {
        & > div:nth-child(2) {
          flex: 1;
        }
        .goall {
          position: relative;
          border-radius: 10px;
          background: #d4d4d4;
          height: 16px;
          margin: 15px 15px 15px 0;
          & > div {
            width: 78%;
            height: 16px;
            position: absolute;
            left: 0;
            top: 0;
            background: #fbd007;
            border-radius: 10px;
          }
        }
      }
      .mainPro {
        & > div:nth-child(2) {
          // white-space: nowrap;
          // text-overflow: ellipsis;
          // overflow: hidden;
        }
      }
      .leftpic {
        position: absolute;
        left: -40px;
        top: -70px;
        img {
          width: 100px;
          height: 100px;
        }
      }
      .leftfont {
        position: absolute;
        left: -10px;
        top: 0px;
        background: red;
        color: white;
        padding: 2px 20px;
        font-size: 20px;
        transform: rotate(-40deg);
      }
    }
  }
  .boxImg {
    position: absolute;
    left: 0;
    bottom: -8px;
    width: 100%;
    img {
      width: 100%;
      display: inline-block;
    }
  }
}
.woniubang {
  background: url("../../assets/img/ranking/woniuback.png") bottom left
    no-repeat;
  background-size: 100% 100%;
  padding-bottom: 40px;
  .woniutop {
    position: relative;
    .woniubaijing {
      width: 100%;
      img {
        width: 100%;
      }
    }
  }
  .woniufont {
    text-align: center;
    font-size: 32px;
    color: #061d3f;
    margin-bottom: 20px;
  }
  .woniucontent {
    .oneData {
      background: url("../../assets/img/ranking/dibg.png") top right no-repeat;
      background-size: 100% 100%;
      width: 86%;
      margin: 0 auto 26px;
      border-radius: 8px;
      padding: 30px 30px;
      position: relative;
      overflow: hidden;
      & > div {
        font-size: 26px;
        margin-top: 10px;
        .leftwidth {
          width: 140px;
          margin-right: 10px;
        }
      }
      & > div:nth-child(2) {
        display: flex;
      }
      & > div:nth-child(3) {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      & > div:nth-child(4),
      & > div:nth-child(5),
      & > div:nth-child(6) {
        display: flex;
        color: #061d3f;
        & > div:nth-child(2) {
          flex: 1;
        }
      }
      .proName {
        font-size: 36px;
        font-weight: 600;
        display: flex;
        align-items: center;
        .espDivImg {
          position: relative;
          top: 4px;
          img {
            width: 60px;
            height: 60px;
          }
          span {
            position: absolute;
            top: -8px;
            left: -16px;
            bottom: 0;
            right: 0;
            margin: auto;
            width: 5px;
            height: 5px;
            line-height: 5px;
            text-align: center;
            color: #061d3f !important;
          }
        }
      }
      .yearPlan {
        & > div:nth-child(2) {
          margin-right: 30px;
        }
        & > div:nth-child(3) {
          background: #061d3f;
          padding: 0 20px;
          color: white;
          border-radius: 6px;
          font-weight: 600;
        }
      }
      .propross {
        & > div:nth-child(2) {
          flex: 1;
        }
        .goall {
          position: relative;
          border-radius: 10px;
          background: #d4d4d4;
          height: 16px;
          margin: 15px 15px 15px 0;
          & > div {
            width: 78%;
            height: 16px;
            position: absolute;
            left: 0;
            top: 0;
            background: #267dcc;
            border-radius: 10px;
          }
        }
      }
      .mainPro {
        & > div:nth-child(2) {
          // white-space: nowrap;
          // text-overflow: ellipsis;
          // overflow: hidden;
        }
      }
      .leftpic {
        position: absolute;
        left: -40px;
        top: -70px;
        img {
          width: 100px;
          height: 100px;
        }
      }
    }
  }
}
.overclass {
  overflow: hidden;
}
.guanjun {
  background: url("../../assets/img/ranking/bg1.png") top right no-repeat !important;
}
.diandi {
  background: url("../../assets/img/ranking/dibg.png") top right no-repeat !important;
}
.hiddenbox {
  position: absolute;
  left: 0px;
  top: 0px;
  background: rgba(0, 0, 0, 0.4);
  width: 100%; /*宽度设置为100%，这样才能使隐藏背景层覆盖原页面*/
  height: 100%;
  z-index: 1;
  .boxtis {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    width: 70%;
    height: 300px;
    background: white;
    border-radius: 4px;
    border: 1px solid #ccc;
    display: flex;
    flex-direction: column;
    & > div:nth-child(1) {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    & > div:nth-child(2) {
      height: 80px;
      display: flex;
      & > span {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #ccc;
      }
      & > span:nth-child(1) {
        border-right: none;
      }
      & > span:nth-child(2) {
        color: #409eff;
      }
    }
  }
}
</style>
