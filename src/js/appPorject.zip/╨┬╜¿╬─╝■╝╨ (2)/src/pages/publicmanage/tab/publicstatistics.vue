<template>
  <div class="publicstatistics">
    舆情统计
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'publicstatistics',
  data() {
    return {

    }
  },
  components: {}
}
</script>

<style scoped lang="scss">
</style>
