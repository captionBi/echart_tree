<template>
  <div class="publicexamine">
    舆情查看
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'publicexamine',
  data() {
    return {

    }
  },
  components: {}
}
</script>

<style scoped lang="scss">
</style>
