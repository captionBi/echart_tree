<template>
  <div class="publicsearch">
    <img class="logo" src="@/assets/img/publicmanage/yuehailogo.png" alt />
    <!-- 搜索框 -->
    <div class="serach">
      <div class="input">
        <input type="text" placeholder="输入内容" v-model="inputvalue" />
      </div>
      <div class="button" @click="searchhandler">搜索</div>
    </div>

    <!-- item列表 -->
    <div class="arraybox">
      <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
        <van-list
          v-model="isUpLoading"
          :finished="upFinished"
          @load="onLoad"
          :offset="offset"
          finished-text="我也是有底线的~~~"
        >
          <div class="content">
            <!-- 自定义内容 -->

            <ul class="list">
              <li
                class="item"
                v-for="(item, index) in searchlist"
                :key="index"
                @click="itemdetail(item)"
              >
                <img class="itemimg" src="@/assets/img/publicmanage/itemimg.png" alt />
                <div class="iteminfo">
                  <div class="title">{{item.headline}}</div>
                  <div class="giveinfo">
                    <div class="give">{{item.source}}</div>
                    <div class="time">{{item.pubTime}}</div>
                  </div>
                  <div class="user">用户:{{item.author}}</div>
                </div>
              </li>
            </ul>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>

    <loading v-if="loadingShow"></loading>
  </div>
</template>

<script type="text/ecmascript-6">
import Loading from "../../../components/loading";
export default {
  name: "publicsearch",
  data() {
    return {
      loadingShow: true, //加载图层
      isLoading: false, //下拉刷新
      isUpLoading: false, //上拉加载
      upFinished: false, //上拉加载完毕
      offset: 100, //滚动条与底部距离小于 offset 时触发load事件
      searchlist: [], //数据数组
      pagenumber: 0, //页数
      pagesize: 10, //一页大小
      total: 0, //总数量
      inputvalue: "",
      timer: null
    };
  },
  created() {},
  mounted() {
    setTimeout(() => {
      this.loadingShow = false;
    }, 500);
  },
  methods: {
    //下拉调用此函数
    onRefresh() {
      setTimeout(() => {
        const object = {
          keyword: this.inputvalue,
          pagenumber: 1,
          pagesize: 10
        };
        this._getpublicsearchlist(object);
        this.pagenumber = 1;
        this.pagesize = 10;
        this.$toast("刷新成功"); //弹出
        this.isLoading = false;
      }, 500);
    },

    //上拉调用此函数
    onLoad() {
      const object = {
        keyword: this.inputvalue,
        pagenumber: ++this.pagenumber,
        pagesize: this.pagesize
      };
      this._getpublicsearchlist(object, true);
      this.$toast("加载成功"); //弹出

      //加载完成时底部提示加载完成，禁止上拉加载。延迟器是为了避免和加载中同时执行
      setTimeout(() => {
        if (this.searchlist.length == this.total) {
          console.log("没有数据");
          this.upFinished = true;
        } else {
          console.log("还有数据");
          this.upFinished = false;
        }
      }, 1000);
    },
    _getpublicsearchlist(obj, flag) {
      console.log(obj);
      console.log(flag);
      const parameter = {
        condition: { headline: `like:%${obj.keyword}%` },
        number: obj.pagenumber,
        size: obj.pagesize,
        relation: "and",
        sortDirection: "DESC",
        sortProperties: ["pubTime"]
      };
      this.$api.publicmanage
        .getpublicsearchlist(parameter)
        .then(response => {
          console.log(response);
          if (response.state.code == 10000 && response.body.list.length) {
            this.total = response.body.totalCount;
            if (flag) {
              this.searchlist = [...this.searchlist, ...response.body.list];
            } else {
              this.searchlist = response.body.list;
            }
            if (response.body.list.length == 10) {
              // 数据更新完毕
              this.isUpLoading = false;
              this.upFinished = false;
            } else {
              // 数据更新完毕
              this.isUpLoading = false;
              this.upFinished = true;
            }
          } else {
            this.upFinished = true;
            this.searchlist = [];
          }
        })
        .catch(accident => {
          console.log(accident);
        });
    },
    // 用户点击搜索
    searchhandler() {
      const object = {
        keyword: this.inputvalue,
        pagenumber: 1,
        pagesize: 10
      };
      this._getpublicsearchlist(object);
      this.pagenumber = 1;
      this.pagesize = 10;
    },
    itemdetail(item) {
      window.location.href = item.url;
    }
  },
  components: { Loading }
};
</script>

<style scoped lang="scss">
.publicsearch {
  background-color: #fff;
  .logo {
    width: 100%;
    height: 185px;
  }
  .serach {
    display: flex;
    padding: 0 40px;
    .input {
      flex: 1;
      height: 80px;
      margin-right: 30px;
      border-radius: 40px;
      input {
        width: 100%;
        height: 100%;
        background: #eef4fa;
        outline: none;
        border: none;
        border-radius: 40px;
        text-indent: 30px;
      }
    }
    .button {
      width: 150px;
      height: 80px;
      line-height: 80px;
      text-align: center;
      background-color: #007fff;
      color: #fff;
      font-size: 35px;
      border-radius: 40px;
    }
  }
  .arraybox {
    max-width: 1200px;
    width: 100%;
    position: absolute;
    top: 272px;
    bottom: 100px;
    overflow: hidden;
    overflow-y: scroll;
    background-color: #fff;
    -webkit-overflow-scrolling: touch;
  }
  .list {
    padding: 0 30px;
    .item {
      display: flex;
      position: relative;
      padding: 40px 0;
      &.item::after {
        content: "";
        display: inline-block;
        width: 100%;
        height: 1px;
        background-color: #dfdfdf;
        position: absolute;
        bottom: 0;
        left: 0;
      }
      .itemimg {
        width: 120px;
        height: 120px;
        border-radius: 10px;
        margin-right: 20px;
      }
      .iteminfo {
        flex: 1;
        .title {
          color: #0f81ff;
          font-weight: bold;
          text-decoration: underline;
          display: -webkit-box;
          overflow: hidden;
          white-space: normal !important;
          text-overflow: ellipsis;
          word-wrap: break-word;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        .giveinfo {
          display: flex;
          align-items: center;
          margin: 5px 0;
          .give {
            margin-right: 20px;
            font-weight: bold;
          }
        }
        .user {
          color: #707070;
        }
      }
    }
  }
}
</style>
