<template>
  <div class="index">
    <ul style="display:none" class="tab">
      <li
        class="tabitem"
        :class="{'active':currentindex == item.flag}"
        v-for="(item, index) in tablist"
        :key="index"
        @click="handoverhandler(item.flag)"
      >{{item.text}}</li>
    </ul>
    <div style="display:none" class="placeholder"></div>
    <component :is="cut"></component>
  </div>
</template>

<script type="text/ecmascript-6">
import Publicexamine from "./tab/publicexamine";
import Publicsearch from "./tab/publicsearch";
import Publicstatistics from "./tab/publicstatistics";
export default {
  name: "index",
  data() {
    return {
      tablist: [
        { text: "舆情查看", flag: 1 },
        { text: "舆情搜索", flag: 2 },
        { text: "舆情统计", flag: 3 }
      ],
      cut: Publicsearch,
      currentindex: 2
    };
  },
    methods: {
    handoverhandler(flag) {
      this.currentindex = flag;
      flag == 1 ? (this.cut = Publicexamine) : flag == 2 ? (this.cut = Publicsearch) : (this.cut = Publicstatistics);
    }
  },
  components: { Publicexamine, Publicsearch, Publicstatistics }
};
</script>

<style scoped lang="scss">
.index {
  .tab {
    display: flex;
    height: 105px;
    .tabitem {
      font-size: 36px;
      font-family: Adobe Heiti Std;
      font-weight: bold;
      color: rgba(1, 1, 1, 1);
      opacity: 0.6;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .active {
      opacity: initial;
      position: relative;
      &.active::before {
        content: "";
        display: inline-block;
        width: 210px;
        height: 10px;
        background: rgba(0, 118, 240, 1);
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
      }
    }
  }
  .placeholder {
    height: 8px;
    background-color: #eaeaea;
  }
}
</style>
