import Vue from 'vue'
import {
    Toast
} from 'vant';
Vue.use(Toast);
import axios from 'axios'
// import storage from 'good-storage'
import config from '../utils/config'

// 配置请求头
axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8'
// 静态资源
Vue.prototype.$static = ''
// 配置接口地址
axios.defaults.baseURL = config.baseUrl
// 超时时间
axios.defaults.timeout = 1000*30;
// 配置cookie
// axios.defaults.withCredentials=true;
// http请求拦截器
axios.interceptors.request.use(config => {
    // storage.set('token', "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTU4NzI4ODYzNywiaWF0IjoxNTg2NDI0NjM3fQ.qPQcuHmoQ_G6F-_NkA4wyXczUsxyKB5FLMjlVbW1A_43pcKw-il8pu7Q2tH3uqNuxOAJy_3fBu9OpWOHiIK_iA")
    // if (storage.get('token')) {
    //     // config.headers.Authorization = 'Bearer ' + storage.get('token');
    //     config.headers.Authorization = "Row "
    // }
    return config

}, error => {
    setTimeout(() => {
        Toast.clear();
        Toast('加载超时');
    }, 3000)
    return Promise.reject(error)
})
// http响应拦截器
axios.interceptors.response.use(data => { // 响应成功关闭loading
    Toast.clear();
    return data
}, error => {
    setTimeout(() => {
        Toast.clear();
        Toast('请求失败，稍后再试！');
    }, 1000*5)
    return Promise.reject(error)
})

// 发送请求
export function post(url, params) {
    return new Promise((resolve, reject) => {
        axios.post(url, params)
            .then(
                res => {
                    resolve(res.data)
                },
                err => {
                    reject(err.data)
                }
            )
            .catch(err => {
                reject(err.data)
            })
    })
}

export function get(url, params) {
    return new Promise((resolve, reject) => {
        axios
            .get(url, {
                params: params
            })
            .then(res => {
                resolve(res.data)
            })
            .catch(err => {
                reject(err.data)
            })
    })
}
export function patch(url, params) {
    return new Promise((resolve, reject) => {
        axios.patch(url, params).then(res => {
            resolve(res.data)
        }).catch(err => {
            reject(err.data)
        })
    })
}

export function put(url, params) {
    return new Promise((resolve, reject) => {
        axios.put(url, params).then(res => {
            resolve(res.data)
        }).catch(err => {
            reject(err.data)
        })
    })
}

//删除
export function DELETE(url, params) {
    return new Promise((resolve, reject) => {
        axios.delete(url, params).then(res => {
            resolve(res.data)
        }).catch(err => {
            reject(err.data)
        })
    })
}
