import {
    post,
    get
} from './config'
// 计划投资
const planInvestment = "gdh-com-hk-digital-investmentplansvc"
// const planInvestment = ""
// 实际投资
const realInvestment = "gdh-com-hk-digital-investmentprogresssvc"
// const realInvestment = ""
// 形象进度左侧
const imageplansvc = "gdh-com-hk-digital-imageplansvc"
// const imageplansvc = ""
export default {
    // 投资
    investment(params, a) {
        if (a == 0) {
            return post(`${planInvestment}/api/service/queryData`, params)
        } else if (a == 1) {
            return post(`${realInvestment}/api/service/queryData`, params)
        }
    },
    // 形象进度
    steps(projectId) {
        return get(`${imageplansvc}/api/service/getProjectImage/${projectId}`)
            // get(`${imageplansvcright}/api/service/filePreview/${projectId}`))
    },
}