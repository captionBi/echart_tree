import {
    post
} from './config'
import progress from './progress'
import engineering from './engineering'
import site from './site'
import vacation from './vacation'
import publicmanage from './publicmanage'
import partymanage from './partymanage'
import personnel from './personnel'
import yuehaishare from './yuehaishare'
import exchange from './exchange'
import sectioninfo from './sectioninfo'
import pegasus from './pegasus'
import rankingsvc from './rankingsvc'
import histogram from './histogram'
import problemstotle from './problemstotle'
import business from './business'
import legalcontract from './legalcontract'
const projectquerysvc = "gdh-com-hk-digital-projectquerysvc"
// const projectquerysvc = ""


export default {
    // 项目列表
    queryProjectList(params) {
        return post(`${projectquerysvc}/api/esearch/queryProjectList`, params)
    },

    progress,
    engineering,
    site,
    vacation,
    publicmanage,
    partymanage,
    personnel,
    yuehaishare,
    exchange,
    sectioninfo,
    pegasus,
    rankingsvc,
    histogram,
    problemstotle,
    business,
    legalcontract,
}