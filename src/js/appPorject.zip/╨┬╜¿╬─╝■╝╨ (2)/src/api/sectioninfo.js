import { get } from './config'

const baseString_1 = "gdh-com-hk-digital-bidengineeringinfosvc";
const baseString_2 = "gdh-com-hk-digital-bidworkingwellinfosvc";
const baseString_3 = "gdh-com-hk-digital-bidmainsvc";


export default {
  // 根据标段ID获取工程信息
  engineeringinfo(bidMainId) {
    return get(`${baseString_1}/api/service/listEngineering/${bidMainId}`);
  },
  // 工作井--工作区间列表
  workingwellinfo(bidMainId) {
    return get(`${baseString_2}/api/service/getBidMainSubWell/${bidMainId}`);
  },
  // 坐标列表
  coordinatelist() {
    return get(`${baseString_3}/api/service/list/1/1000`);
  },
  // 坐标详情
  coordinatedetail(projectId, node) {
    return get(`${baseString_3}/api/service/getListByProjectAndNode/${projectId}/${node}`);
  }
}
