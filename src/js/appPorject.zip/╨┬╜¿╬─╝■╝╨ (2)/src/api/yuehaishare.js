import { get } from './config'



export default {
  // 恒生指数
  hangseng() {
    return get('gdh-com-hk-digital-authcomputesvc/api/service/getStockData/hk01203');
  }
}
