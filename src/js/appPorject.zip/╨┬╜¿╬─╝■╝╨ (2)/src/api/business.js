import {
    get
} from './config'

const baseString_1 = "gdh-com-hk-digital-chinamobileapicomputesvc";

const baseString_2 = "gdh-com-hk-digital-tianhehistoryquerysvc"
export default {
    hasRealTimeData() {
        return get(`${baseString_1}/api/service/getRealTimeData`)
    },
    hasgetStreamPeople() {
        return get(`${baseString_1}/api/service/getStreamPeople`)
    },
    hasgetAttributeData() {
        return get(`${baseString_1}/api/service/getAttributeData`)
    },
    hasgetRealTimeInfo() {
        return get(`${baseString_1}/api/service/getRealTimeInfo`)
    },
    hasInputStream() {
        return get(`${baseString_1}/api/service/getInputStreamPeople`)
    },
    hasOutputStream() {
        return get(`${baseString_1}/api/service/getOutputStreamPeople`)
    },
    hasPassAnalysis() {
        return get(`${baseString_1}/api/service/getPassengerAnalysis`)
    },
    hasAllDayCount() {
        return get(`${baseString_1}/api/service/getAllDayCount`)
    },
    hasAddByHour() {
        return get(`${baseString_1}/api/service/getAddByHourPeople`)
    },
    hasAgeAndSex() {
        return get(`${baseString_1}/api/service/getAgeAndSexByDay`)
    },
    hasDataByMonth() {
        return get(`${baseString_2}/api/esearch/getHistoryDataByMonth`)
    },
    hasDataByWeek() {
        return get(`${baseString_2}/api/esearch/getHistoryDataByWeek`)
    },
    hasDDataByDay() {
        return get(`${baseString_2}/api/esearch/getHistoryDataByDay`)
    },
}