import {
    get
} from './config'

const baseString_1 = "gdh-com-hk-digital-rankingsvc";

export default {
    // 获飞马榜数据
    getDataLastedRank(count) {
        return get(`${baseString_1}/api/service/getLastedRank/${count}`)
    }
}