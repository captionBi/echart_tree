import { get, put } from './config'

const baseString_1 = "gdh-com-hk-digital-personnelprofilesvc"
// const baseString_2 = "gdh-com-hk-digital-personnelanalysiscomputesvc"


export default {
  // 初始化数据
  personnelrequest() {
    return get(`${baseString_1}/api/service/getMainInfo`)
  },
  staffing(parameter) {
    return put(`${baseString_1}/api/object/companyLeaderInfo/lookup/`, parameter)
  }
}
