import {
    get,
    post
} from './config'
const author = 'gdh-com-hk-digital-oadatacomputesvc'
// const author = ''
export default {
    // 获取休假详情
    getVacationDetail(params) {
        return post(`${author}/api/service/queryOaData`, params)
    },
    getAuth(params) {
        return get(`${author}/api/service/getAuthUrl`, params)
    },
    // getAuths(params) {
    //     return get(`${author}/api/service/wxCPAuth`, params)
    // },
    getVacationList(params) {
        return post(`${author}/api/service/queryOaTotalData`, params)
    }
}