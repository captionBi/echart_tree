import {
    get
} from './config'

const baseString_1 = "gdh-com-hk-digital-bondcomputesvc";

export default {
    getInFoListPian(date) {
        return get(`${baseString_1}/api/service/getInfoList/${date}`)
    },
    hasgetExcel(date) {
        return get(`${baseString_1}/api/service/getExcelList/${date}`)
    }
}