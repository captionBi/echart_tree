import {
    get
} from './config'

const baseString_1 = "gdh-com-hk-digital-auditcomputesvc";

export default {
    hasGetIndexInfo() {
        return get(`${baseString_1}/api/service/getIndexInfo`)
    },
    hasGetDetailInfo(unitId) {
        return get(`${baseString_1}//api/service/getDetailInfo/${unitId}`)
    }
}