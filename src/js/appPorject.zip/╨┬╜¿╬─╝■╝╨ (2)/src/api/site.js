import {
    get,
    post,
    DELETE,
    // post
} from './config'
// import { delete } from 'vue/types/umd'
// import config from '../utils/config'
const panoramasvc = "gdh-com-hk-digital-panoramasvc"
// const panoramasvc = ""

const videoconfigsvc = "gdh-com-hk-digital-videoconfigsvc"
//收藏
const videocollectsvc = "gdh-com-hk-digital-videocollectsvc"
// const videoconfigsvc = ""
export default {
    // 获取全景列表
    get720list(params) {
        return get(`${panoramasvc}/api/service/list`, params)
    },
    //全景搜索
    getSearchList(params) {
        return post(`${panoramasvc}/api/service/listPanoramaByProjectName`, params)
    },
    // 获取全景详细信息
    getPanorama(projectId) {
        return get(`${panoramasvc}/api/service/listPanorama/${projectId}`)
    },
    // 视频列表
    getVideoList() {
        return get(`${videoconfigsvc}/api/service/list`)
    },
    // 视频详情
    getVideoDetail(cam) {
        return get(`${videoconfigsvc}/api/service/getProjectVideoUrl/${cam}`)
    },
    // 获取项目及视频列表
    getProjectAndeVideoList(projectId) {
        let url = `${videoconfigsvc}/api/service/listProjectVideo`
        url = projectId ? url + '/' + projectId : url
        return get(url)
    },
    // 根据项目名称获取监控列表
    getVideoListByProjectName(projectName) {
        return get(`${videoconfigsvc}/api/service/listProjectVideoByProjectName/${projectName}`)
    },
    // 收藏--新增
    collectCollect(params) {
        return post(`${videocollectsvc}/api/service/collect`, params)
    },
    // 收藏--删除
    collectDelete(params) {
        return DELETE(`${videocollectsvc}/api/service/${params.id}`)
    },
    // 收藏--列表
    getFavoriteList(userId) {
        return get(`${videocollectsvc}/api/service/getListByUser?userId=${userId}`)
    },
}

