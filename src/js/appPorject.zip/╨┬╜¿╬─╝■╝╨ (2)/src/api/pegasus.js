import { post, put, get } from './config'

const baseurl = "http://10.1.20.81:8078";

const baseString_1 = "gdh-com-hk-digital-dictionarydatasvc";

export default {
    // 获取数据字典
    getNumfont(dicKey) {
        return get(`${baseString_1}/api/service/findChildByDicKey/${dicKey}`)
    }
}