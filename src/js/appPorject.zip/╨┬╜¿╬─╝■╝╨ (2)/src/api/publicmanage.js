import { put } from './config'

// 舆情搜索 / 以及默认数据
const baseString_1 = "gdh-com-hk-digital-publicsentimentsvc"

export default {
  // 舆情搜索
  getpublicsearchlist(params) {
    return put(`${baseString_1}/api/object/publicSentiment/lookup`, params)
  }
}
