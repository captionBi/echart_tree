import { post, put } from './config'

const baseurl = "http://10.1.20.81:8078";

const baseString_1 = "gdh-com-hk-digital-partcountsvc";


export default {
  // 搜索
  searchkeyword(parameter) {
    return post(`${baseurl}/uni/AccountService/getOrgTreeByOrgName`, parameter);
  },
  // 党员数据
  partyrequest(parameter) {
    return post(`${baseurl}/uni/AccountService/getStatisticsUserByOrgName`, parameter);
  },
  // 党组织活动次数统计
  activityrequest(parameter) {
    return post(`${baseurl}/uni/AccountService/getStatisticsOrgActivityByYear`, parameter);
  },
  // 党员数据结构统计
  construction(parameter) {
    return post(`${baseurl}/uni/AccountService/getStatisticsUserAgeByOrgName`, parameter);
  },
  // 申请入党
  applyrequest(parameter) {
    return put(`${baseString_1}/api/object/partyCount/lookup`, parameter);
  }
}
