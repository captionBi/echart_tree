import {
    // get,
    post
} from './config'
// import config from '../utils/config'
// 工程详情
const projectquerysvc = "gdh-com-hk-digital-projectquerysvc"
// const projectquerysvc = ""
// 概览信息
const projectsvc = "gdh-com-hk-digital-projectsvc"
// const projectsvc = ""


export default {
    // 获取工程概览信息
    getEngineering(params) {
        return post(`${projectsvc}/api/service/queryProjectList`, params)
    },
    // 获取剩余三个图表的接口
    getBoardData() {
        return post(`${projectsvc}/api/service/getBoardData`, {
            projectName: ""
        })
    },

    getBoardList(params) {
        return post(`${projectsvc}/api/service/getBoardList`, params)
    },
    // 获取工程详情
    getEngineeringDetail(params) {
        return post(`${projectquerysvc}/api/esearch/queryProjectDetail`, params)
    },
    // 语音转文字获取--签名------新加
    getAuthSign(params) {
        return post(`gdh-com-hk-digital-authcomputesvc/api/service/getAuthSign`, params)
    },
}