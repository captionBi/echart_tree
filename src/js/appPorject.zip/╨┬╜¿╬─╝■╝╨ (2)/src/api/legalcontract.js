import {
    get
} from './config'

const baseString_1 = "gdh-com-hk-digital-legalcomputesvc";

export default {
    hasContractPer(year) {
        return get(`${baseString_1}/api/service/getContractPerformance/${year}`)
    },
    hasContractSign(year) {
        return get(`${baseString_1}/api/service/getContractSigning/${year}`)
    },
}