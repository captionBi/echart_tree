import { get } from './config'

const baseString_1 = "gdh-com-hk-digital-foreignexchangesvc"


export default {
  // 初始化数据
  exchangeinitialize() {
    return get(`${baseString_1}/api/service/getExchangeRateForLine`)
  }
}
