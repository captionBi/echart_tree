<template>
  <div class="ondDivf">
    <div class="pieFons">{{ fonts }}</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "moreline",
  data() {
    return {};
  },
  props: {
    morelineList: {
      type: Array,
      default() {
        return [];
      },
    },
    fonts: {
      type: String,
      default: "",
    },
    ids: {
      type: String,
      default: "table",
    },
    areaList: {
      type: Array,
      default() {
        return [];
      },
    },
    xList: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  watch: {
    morelineList(news, old) {
      this.lineoneApi();
    },
  },
  created() {},
  methods: {
    lineoneApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        tooltip: {
          trigger: "axis",
        },
        legend: {
          show: true,
          right: "10%",
          top: "20%",
          type: "scroll",
          itemWidth: 24,
          itemHeight: 12,
          orient: "vertical",
          textStyle: {
            color: "white",
            fontSize: 12,
          },
          data: this.areaList,
        },
        grid: {
          left: "3%",
          right: "30%",
          bottom: "3%",
          top: "30%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          axisLabel: { show: true, textStyle: { color: "#fff" } },
          data: this.xList,
        },
        yAxis: {
          type: "value",
          axisLabel: { show: true, textStyle: { color: "#fff" } }, //字体颜色
          splitLine: { show: false }, //去掉网格线
        },
        series: this.morelineList,
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped lang="scss">
</style>
