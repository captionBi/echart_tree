<template>
  <div class="ondDivf">
    <div class="pieFons">性别</div>
    <div class="absdiv">
      <div class="leftpos">
        <div>
          <div class="posones">
            <div><img src="../assets/img/boypic.png" alt="" /></div>
            <div style="color: #0218b5">{{ sexObj.male }}</div>
          </div>
          <div
            v-for="(item, index) in nanNum"
            :key="index"
            style="background: #0218b5"
          ></div>
        </div>
      </div>

      <div class="centerpos">
        <div>
          <div class="posones">
            <div><img src="../assets/img/nvpic.png" alt="" /></div>
            <div style="color: #db132c">{{ sexObj.female }}</div>
          </div>
          <div
            v-for="(item, index) in nvNum"
            :key="index"
            style="background: #db132c"
          ></div>
        </div>
      </div>
      <div class="rightpos">
        <div><img src="../assets/img/sexpic.png" alt="" /></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "sexcom",
  data() {
    return {
      nanNum: "",
      nvNum: "",
    };
  },
  props: {
    sexObj: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  watch: {
    sexObj(news, old) {
      let newNan = news.male.substring(0, 4);
      let newNv = news.female.substring(0, 4);
      if (parseInt(newNan) > parseInt(newNv)) {
        if (parseInt(newNan.substring(2, 3)) >= 5) {
          this.nanNum = parseInt(newNan.substring(0, 1)) + 1;
          this.nvNum = 10 - this.nanNum;
        } else {
          this.nanNum = parseInt(newNan.substring(0, 1));
          this.nvNum = 10 - this.nanNum;
        }
      } else {
        if (parseInt(newNv.substring(2, 3)) >= 5) {
          this.nvNum = parseInt(newNv.substring(0, 1)) + 1;
          this.nanNum = 10 - this.nvNum;
        } else {
          this.nvNum = parseInt(newNv.substring(0, 1));
          this.nanNum = 10 - this.nvNum;
        }
      }
      console.log("eeeee", this.nvNum, this.nanNum);
    },
  },
  created() {},
  methods: {},
};
</script>

<style scoped lang="scss">
.ondDivf {
  width: 94%;
  margin: 0 auto;
  padding-top: 36px;
  background: url("../assets/img/onebg.png") no-repeat;
  background-size: 100% 100%;
  height: 476px;
  position: relative;
  .pieFons {
    text-align: center;
    font-size: 32px;
    color: white;
  }
  .absdiv {
    position: absolute;
    width: 80%;
    bottom: 50px;
    left: 10%;
    display: flex;
    .leftpos,
    .centerpos {
      flex: 1;
      text-align: center;
      position: relative;
      & > div:nth-child(1) {
        width: 100%;
        position: absolute;
        bottom: 0;
        img {
          width: 50px;
          height: 50px;
        }
        & > div {
          width: 80%;
          height: 16px;
          margin: 0 auto;
          margin-top: 6px;
        }
        .posones {
          position: relative;
          & > div:nth-child(1) {
            position: absolute;
            top: -120px;
            width: 100%;
            text-align: center;
          }
          & > div:nth-child(2) {
            position: absolute;
            top: -40px;
            width: 100%;
            text-align: center;
          }
        }
      }
    }
    .rightpos {
      flex: 1;
      & > div {
        width: 100%;
        text-align: center;
        img {
          width: 70%;
          height: 280px;
        }
      }
    }
  }
}
</style>
