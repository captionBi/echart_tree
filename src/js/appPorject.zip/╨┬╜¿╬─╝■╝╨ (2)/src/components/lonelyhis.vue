<template>
  <div class="ondDivf">
    <div class="pieFons">单条柱状图的封装</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "lonelyhis",
  data() {
    return {};
  },
  props: {
    onelydataList: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
  },
  watch: {
    onelydataList(news, old) {
      console.log("eeeee", news);
      this.pieApi();
    },
  },
  created() {
    // this.pieApi();
    console.log("aaaaaaaa", this.onelydataList);
  },
  methods: {
    pieApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        xAxis: {
          type: "category",
          data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        yAxis: {
          type: "value",
          splitLine: { show: false }, //去掉网格线
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        series: [
          {
            data: this.onelydataList,
            type: "bar",
          },
        ],
      };
      myChart.setOption(option);
    },
  },
  components: {},
};
</script>

<style scoped lang="scss">
</style>
