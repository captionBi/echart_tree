<template>
  <div class="ondDivf">
    <div class="pieFons">{{ fonts }}</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "histogram",
  data() {
    return {};
  },
  props: {
    hisList: {
      type: Array,
      default() {
        return [];
      },
    },
    areaList: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
    xList: {
      type: Array,
      default() {
        return [];
      },
    },
    fonts: {
      type: String,
      default: "",
    },
  },
  watch: {
    hisList(news, old) {
      this.histogramApi();
    },
  },
  created() {},
  methods: {
    histogramApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        tooltip: {
          trigger: "axis",
        },
        color: [
          "#ffa257",
          "#ffe98e",
          "#12b3ff",
          "#21fcff",
          "#5b72ff",
          "#0be53c",
        ],
        legend: {
          show: true,
          right: "10%",
          top: "20%",
          type: "scroll",
          itemWidth: 12,
          itemHeight: 12,
          orient: "vertical",
          textStyle: {
            color: "white",
            fontSize: 14,
          },
          data: this.areaList,
        },
        grid: {
          left: "3%",
          right: "30%",
          bottom: "3%",
          top: "30%",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: this.xList,
            axisLabel: { show: true, textStyle: { color: "#fff" } },
          },
        ],
        yAxis: [
          {
            type: "value",
            splitLine: { show: false }, //去掉网格线
            axisLabel: { show: true, textStyle: { color: "#fff" } },
          },
        ],
        series: this.hisList,
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped lang="scss">
</style>
