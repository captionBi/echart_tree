<template>
  <div class="ondDivf">
    <div class="pieFons">{{ fonts }}</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "population",
  data() {
    return {};
  },
  props: {
    populationList: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
    yAxis: {
      type: Array,
      default() {
        return [];
      },
    },
    fonts: {
      type: String,
      default: "",
    },
  },
  watch: {
    populationList(news, old) {
      this.lineoneApi();
    },
  },
  created() {},
  methods: {
    lineoneApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        color: ["#13b4ff"],
        xAxis: {
          type: "value",
          splitLine: { show: false }, //去掉网格线
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        yAxis: {
          type: "category",
          data: this.yAxis,
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        series: [
          {
            name: "全天人数",
            type: "bar",
            data: this.populationList,
          },
        ],
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped lang="scss">
</style>
