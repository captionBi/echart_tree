<template>
  <div class="ondDivf">
    <div class="pieFons">{{ fonts }}</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "oneline",
  data() {
    return {};
  },
  props: {
    onelineList: {
      type: Array,
      default() {
        return [];
      },
    },
    onelineName: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
    fonts: {
      type: String,
      default: "",
    },
    rotate: {
      type: Number,
      default: 0,
    },
  },
  watch: {
    onelineList(news, old) {
      console.log("rrrrrrrr", news);
      this.lineoneApi();
    },
  },
  created() {},
  methods: {
    lineoneApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        tooltip: {
          trigger: "axis",
        },
        xAxis: {
          type: "category",
          data: this.onelineName,
          axisLabel: {
            show: true,
            textStyle: { color: "#fff" },
            rotate: this.rotate,
          },
        },
        yAxis: {
          type: "value",
          splitLine: { show: false }, //去掉网格线
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        grid: {
          left: "10%",
          right: "10%",
          bottom: "3%",
          top: "10%",
          containLabel: true,
        },
        series: [
          {
            data: this.onelineList,
            type: "line",
            smooth: true,
          },
        ],
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped lang="scss">
</style>
