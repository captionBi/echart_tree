<template>
  <div class="nothing">
    <img src="../assets/img/common/nothing.png" alt="">
  </div>
</template>

<script>
export default {
  name: 'Nothing'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.nothing {
  text-align: center;
  margin-top: 100px;
}
img {
  width: 396px;
  height: 374px;
}
</style>
