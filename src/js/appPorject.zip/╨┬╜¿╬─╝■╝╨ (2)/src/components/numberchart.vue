<template>
  <div class="ondDivf">
    <div class="pieFons">人数走势</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "people",
  data() {
    return {};
  },
  props: {
    peopleList: {
      type: Array,
      default() {
        return [];
      },
    },
    timeData: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
  },
  watch: {
    peopleList(news, old) {
      this.lineoneApi();
    },
  },
  created() {},
  methods: {
    lineoneApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        grid: {
          left: "10%",
          right: "10%",
          bottom: "3%",
          top: "10%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.timeData,
          splitLine: { show: false }, //去掉网格线
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        yAxis: {
          type: "value",
          splitLine: { show: false }, //去掉网格线
          axisLabel: { show: true, textStyle: { color: "#fff" } },
        },
        series: this.peopleList,
      };
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped lang="scss">
</style>
