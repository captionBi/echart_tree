<template>
  <div class="ondDivf">
    <div class="pieFons">{{ fonts }}</div>
    <div :id="ids" style="height: 80%; width: 100%"></div>
  </div>
</template>

<script>
export default {
  name: "pie",
  data() {
    return {};
  },
  props: {
    showLabel: {
      type: Boolean,
      default: true,
    },
    dataList: {
      type: Array,
      default() {
        return [];
      },
    },
    ids: {
      type: String,
      default: "table",
    },
    fonts: {
      type: String,
      default: "",
    },
    picName: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  watch: {
    dataList(news, old) {
      this.pieApi();
    },
  },
  created() {},
  methods: {
    pieApi() {
      let myChart = this.$echarts.init(document.getElementById(this.ids));
      let option = {
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {d}%",
        },
        formatter: (res) => {
          return res.substring(0, 6);
        },
        color: [
          "#13b4ff",
          "#21fcff",
          "#ffa257",
          "#5b72ff",
          "#fff594",
          "#3bb400",
          "#c43632",
          "#2c4250",
        ],
        legend: {
          show: true,
          right: "10%",
          top: "20%",
          type: "scroll",
          itemWidth: 12,
          itemHeight: 12,
          orient: "vertical",
          textStyle: {
            color: "white",
            fontSize: 14,
          },
          data: this.picName,
        },
        series: [
          {
            name: this.fonts,
            type: "pie",
            radius: ["40%", "70%"],
            center: ["35%", "55%"],
            avoidLabelOverlap: true, //让文字提示不重叠
            label: {
              show: this.showLabel,
              position: "outside",
              fontSize: 15,
            },
            emphasis: {
              label: {
                show: false,
                fontSize: "15",
                fontWeight: "bold",
              },
            },
            labelLine: {
              show: this.showLabel,
              position: "outer",
              alignTo: "edge",
              margin: 10,
              length: 300 / 50,
              length2: 300 / 100,
            },
            data: this.dataList,
          },
        ],
      };
      myChart.setOption(option);
    },
  },
  components: {},
};
</script>

<style scoped lang="scss">
</style>
