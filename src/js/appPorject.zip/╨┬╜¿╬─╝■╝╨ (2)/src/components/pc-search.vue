<template>
    <div class="search">
        <van-search v-model="value" shape="round" show-action placeholder="请输入项目名称" @search="onSearch">
            <template #action>
                <div @click="onSearch" class="serch_button">搜索</div>
            </template>
        </van-search>
        <div class="search_items flex">
            <div class="search_item flex-between margin-right">
                <van-checkbox v-model="checked" shape="square" icon-size="16px">省重大项目</van-checkbox>
            </div>
            <div class="search_item flex-between" @click="stagePickrShow =true">
                <p>状态：</p>
                <p class="text-placeholder middle text-cut">请选择请选择请选择请选择请选择请选择s</p>
                <van-icon name="arrow-down" />
            </div>
            <p class="more" @click="more=true" v-if="!more">更多</p>
            <div class="search_more flex" v-if="more">
                <div class="search_item flex-between margin-right">
                    <p>阶段：</p>
                    <p class="text-placeholder middle text-cut">请选择请选择请选择请选择请选择请选择s</p>
                    <van-icon name="arrow-down" />
                </div>
                <div class="search_item flex-between">
                    <p>版块：</p>
                    <p class="text-placeholder middle text-cut">请选择请选择请选择请选择请选择请选择s</p>
                    <van-icon name="arrow-down" />
                </div>
                <div class="search_item flex-between  margin-right">
                    <p>时间</p>
                    <p class="text-placeholder middle text-cut">请选择请选择请选择请选择请选择请选择s</p>
                    <van-icon name="arrow-down" />
                </div>
                <div class="search_item flex-center text-main">
                    重置
                </div>
                <p class="more" @click="more=false">收起</p>
            </div>
            <div class="search_name" v-if="prograssname">{{prograssname}}</div>
        </div>
        <van-popup v-model="stagePickrShow" position="bottom">
            <van-picker show-toolbar :columns="columns" @confirm="stageConfirm" @cancel="stagePickrShow=false" />
        </van-popup>
    </div>
</template>
<script>
    import {
        Search,
        Icon,
        Checkbox,
        Picker,
        Popup
    } from 'vant';
    export default {
        components: {
            [Search.name]: Search,
            [Icon.name]: Icon,
            [Checkbox.name]: Checkbox,
            [Picker.name]: Picker,
            [Popup.name]: Popup,
        },
        data() {
            return {
                more: false,
                value: '',
                checked: false,
                stagePickrShow: false,
                columns: ['1', '2', '3', '4', '5'],
                prograssname: ''
            }
        },
        created() {},
        methods: {
            stageConfirm() {

            },
            onSearch() {}
        },
    }
</script>
<style lang='scss' scoped>
    .search {
        background: #fff;

        .van-search__content {
            background: #EEF4FA;
        }

        .serch_button {
            width: 100px;
            height: 50px;
            line-height: 50px;
            text-align: center;
            color: #fff;
            border-radius: 50px;
            background: #0081FF;
        }

        .search_items {
            flex-wrap: wrap;
            padding: 10px 20px;

            .search_more {
                width: 100%;
                flex-wrap: wrap;
            }

            .search_item {
                width: 41%;
                height: 50px;
                font-size: 16px;
                line-height: 50px;
                padding: 0 20px;
                background: #EEF4FA;
                border-radius: 50px;
                margin-bottom: 10px;

                .middle {
                    width: 60%;
                }
            }

            .more {
                line-height: 50px;
                margin-left: 30px;
                font-size: 24px;
                color: #0076F0;
            }

            .search_name {
                width: 100%;
                text-align: center;
                background: #EEF4FA;
                height: 50px;
                font-size: 16px;
                line-height: 50px;
                color: #0076F0;
                border-radius: 50px;
            }

        }
    }

    .panel {
        padding: 20px;
        margin: 20px;
        background: #fff;
        border-radius: 10px;
    }

    .chart {
        width: 100%;
    }
</style>