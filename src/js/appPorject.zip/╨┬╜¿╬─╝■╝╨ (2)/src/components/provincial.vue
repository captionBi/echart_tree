<template>
  <div class="ondDivf">
    <img class="imgpic" :src="urlpic" alt="" />
    <div class="pieFons">{{ name }}</div>
    <div class="contents">
      <div class="rangDiv">
        <div>{{ name === "省国际来源" ? "省份排名" : "城市排名" }}</div>
        <div>
          <div v-for="(item, index) in list" :key="index">
            <div>{{ item.sourceName }}</div>
            <div>{{ item.subscriberCount }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  props: {
    list: {
      type: Array,
      default() {
        return [];
      },
    },
    name: {
      type: String,
      default() {
        return "";
      },
    },
    urlpic: {
      type: String,
      default() {
        return "";
      },
    },
  },
  watch: {},
  created() {},
  methods: {},
};
</script>

<style scoped lang="scss">
.ondDivf {
  width: 94%;
  margin: 0 auto;
  padding-top: 36px;
  background: url("../assets/img/onebg.png") no-repeat;
  background-size: 100% 100%;
  height: 476px;
  position: relative;
  .pieFons {
    text-align: center;
    font-size: 32px;
    color: white;
  }
  .imgpic {
    position: absolute;
    top: 20%;
    left: 14px;
    width: 96%;
    height: 76%;
    border-radius: 8px;
    z-index: 1;
    display: inline-block;
    margin: 0 auto;
  }
  .contents {
    height: 76%;
    position: relative;
    .rangDiv {
      position: absolute;
      right: 20px;
      top: 12%;
      height: 90%;
      width: 260px;
      color: white;
      z-index: 2;
      & > div:nth-child(1) {
        text-align: center;
        margin-top: 10px;
        background: url("../assets/img/fontbg.png") no-repeat;
        background-size: cover;
      }
      & > div:nth-child(2) {
        overflow-y: scroll;
        height: 85%;
        margin-top: 20px;
        & > div {
          display: flex;
          margin-bottom: 10px;
          & > div:nth-child(1) {
            display: flex;
            flex: 1;
          }
          & > div:nth-child(2) {
            margin-right: 30px;
          }
        }
      }
    }
  }
}
</style>