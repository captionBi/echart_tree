<template>
  <div class="screen">
    <!-- <div class="screen_items flex justify-around">
        <div class="screen_item flex-between margin-right">
          <van-checkbox v-model="checked" shape="square" icon-size="16px" @change="projectType(checked)">省重点
          </van-checkbox>
    </div>-->
    <!-- <div class="screen_item flex-between" @click="stagePickrShow =true">
        <p>状态：</p>
        <p class="text-placeholder middle text-cut">{{projectStatus?projectStatus:'请选择'}}</p>
        <van-icon name="arrow-down" />
    </div>-->
    <!-- <p class="more" @click="more=true" v-if="!more">更多</p> -->
    <!-- <div class="screen_more flex" v-if="more">
        <div class="screen_item flex-between margin-right" @click="periodPickrShow =true">
          <p>阶段：</p>
          <p class="text-placeholder middle text-cut">{{projectPeriod?projectPeriod:'请选择'}}</p>
          <van-icon name="arrow-down" />
        </div>
        <div class="screen_item flex-between" @click="boardPickrShow =true">
          <p>版块：</p>
          <p class="text-placeholder middle text-cut">{{projectBoard?projectBoard:'请选择'}}</p>
          <van-icon name="arrow-down" />
        </div>
        <div class="screen_item flex-between  margin-right"  @click="yearPickrShow =true">
          <p>时间</p>
          <p class="text-placeholder middle text-cut">{{year?year:'请选择'}}</p>
          <van-icon name="arrow-down" />
        </div>
        <div class="screen_item flex-center text-main" @click="reset()">
          重置
        </div>
        <p class="more" @click="more=false">收起</p>
    </div>-->
    <div class="flex flex1 justify-between">
      <div class="screen_items">
        <div class="screen_item flex-between">
          <van-checkbox
            v-model="checked"
            shape="square"
            icon-size="16px"
            @change="projectType(checked)"
          >省重点</van-checkbox>
        </div>
      </div>
      <!-- <van-search v-model="searchValue" shape="round" show-action placeholder="搜索框" @search="onSearch">
        <template #action>
          <div @click="onSearch" v-if="search" class="search_button">搜索</div>
          <div @click="onCancel" v-else class="search_button">取消</div>
        </template>
      </van-search>-->
      <!-- <van-field
    v-model="searchValue"
    placeholder="请输入用户名"
    bind:change="onChange"
    @input="onChange"
      />-->
      <div class="searchDiv">
        <van-search
          v-model="searchValue"
          shape="round"
          placeholder="搜索框"
          @search="onSearch"
          @input="onChange"
        >
          <!-- <template #action>
            <div @click="onSearch" v-if="search" class="search_button">搜索</div>
            <div @click="onCancel" v-else class="search_button">取消</div>
          </template>-->
        </van-search>
        <span class="iconVoice" @click="voiceFun('open')"></span>
      </div>
    </div>

    <div class="screen_name" v-if="prograssname">
      {{prograssname}}
      <van-icon class="cross" name="cross" @click="cross" />
    </div>

    <!-- 显示搜索弹窗数据 -->
    <!-- <div class="search_list" v-show="searchListShow">
      <div class="search_list_item" v-for="(item,index) in searchList " :key="index" @click="chooseItem(item)">
        {{item.projectName}}</div>
    </div>-->

    <van-popup v-model="stagePickrShow" position="bottom">
      <van-picker
        show-toolbar
        :columns="stagePickrcolumns"
        @confirm="stageConfirm"
        @cancel="stagePickrShow=false"
      />
    </van-popup>
    <van-popup v-model="periodPickrShow" position="bottom">
      <van-picker
        show-toolbar
        :columns="periodPickrcolumns"
        @confirm="periodConfirm"
        @cancel="periodPickrShow=false"
      />
    </van-popup>
    <van-popup v-model="boardPickrShow" position="bottom">
      <van-picker
        show-toolbar
        :columns="boardPickrcolumns"
        @confirm="boardConfirm"
        @cancel="boardPickrShow=false"
      />
    </van-popup>
    <van-popup v-model="yearPickrShow" position="bottom">
      <van-picker
        show-toolbar
        :columns="yearPickrcolumns"
        @confirm="yearConfirm"
        @cancel="yearPickrShow=false"
      />
    </van-popup>

    <div class="fullModal" v-if="show" @click="voiceFun('close')"></div>
    <div :class="show?'voiceModal show':'voiceModal'">
      <span class="close" @click="voiceFun('close')">x</span>
      <div class="img">
        <img v-if="longShow" src="../assets/img/engineering/icon_voice_svg.svg" />
        <img v-if="!longShow" src="../assets/img/engineering/icon_voice_png.png" />
        <p>{{voiceTxt}}</p>
      </div>
      <div class="button" @touchstart="touchStart" @touchend="touchEnd">
        <van-button type="info" size="large">长按录音</van-button>
      </div>
    </div>
  </div>
</template>
<script>
import {
  Search,
  Icon,
  Checkbox,
  Picker,
  Popup,
  Toast,
  Field,
  ActionSheet,
  Button,
} from "vant";
export default {
  components: {
    [Search.name]: Search,
    [Icon.name]: Icon,
    [Checkbox.name]: Checkbox,
    [Picker.name]: Picker,
    [Popup.name]: Popup,
    [Toast.name]: Toast,
    [Field.name]: Field,
    "van-button": Button,
    "van-action-sheet": ActionSheet,
  },
  data() {
    return {
      // 录音
      show: false,
      loop: 0,
      longShow: false,
      voiceTxt: "",
      url2: "http://m.sea.com",
      url: "https://wechat.gdhchina.com",
      localId: "", //录音id
      timeStamp: Math.round(new Date() / 1000), // 时间戳
      corpId: "ww1736e9ae98ad76c9", //企业微信的corpid
      corpSecret: "hnZQKk_whGy686CfWpmuQx1cyxvsSI4Z0LypZISDbts", //应用secret
      nonceStr: "Wm3WZYTPz0wzccnW", //生成签名的随机串
      timer: null,
      //录音结束

      search: true,
      searchValue: "",
      searchListShow: false,
      searchList: [],
      more: false,
      value: "",
      checked: false,
      stagePickrShow: false,
      stagePickrcolumns: ["正常", "延期", "全部"],
      projectStatus: "",
      periodPickrShow: false,
      periodPickrcolumns: ["前期阶段", "建设阶段", "已建成"],
      projectPeriod: "",
      boardPickrShow: false,
      boardPickrcolumns: ["水务及水环境治理", "产业园及制造业", "城市综合体"],
      projectBoard: "",
      prograssname: "",
      yearPickrShow: false,
      yearPickrcolumns: ["2018", "2019", "2020"],
      year: "",
      params: {},
    };
  },
  created() {},
  mounted() {
    this.getAuthSign();
  },
  methods: {
    reset() {
      this.projectBoard = "";
      this.projectPeriod = "";
      this.projectStatus = "";
      this.checked = false;
      this.searchValue = "";
      this.params = {};
      this.$emit("searchParams", this.params);
    },
    boardConfirm(value, index) {
      this.projectBoard = value;
      this.params = {
        ...this.params,
        ...{
          projectBoard: index,
        },
      };
      this.$emit("searchParams", this.params);
      this.boardPickrShow = false;
    },
    periodConfirm(value, index) {
      this.projectPeriod = value;
      this.params = {
        ...this.params,
        ...{
          projectPeriod: index,
        },
      };
      this.$emit("searchParams", this.params);
      this.periodPickrShow = false;
    },
    stageConfirm(value, index) {
      this.projectStatus = value;
      if (index != 2) {
        this.params = {
          ...this.params,
          ...{
            projectStatus: index,
          },
        };
      } else {
        this.params = {
          ...this.params,
          ...{
            projectStatus: "",
          },
        };
      }
      this.$emit("searchParams", this.params);
      this.stagePickrShow = false;
    },
    yearConfirm(value) {
      this.year = value;
      this.params = {
        ...this.params,
        ...{
          year: value,
        },
      };
      this.$emit("searchParams", this.params);
      this.yearPickrShow = false;
    },
    projectType(name) {
      console.log(name);
      let isImportant = name ? 1 : "";
      this.params = {
        ...this.params,
        ...{
          projectType: isImportant,
        },
      };
      this.$emit("searchParams", this.params);
    },
    // 点击搜索出来的结果然后跳转
    chooseItem(item) {
      console.log(item);
      this.project = item;
      this.prograssname = item.projectName;
      this.params = {
        ...this.params,
        ...{
          projectName: item.projectName,
        },
      };
      this.$emit("searchParams", this.params);
      this.$emit("chooseItem", item);
      this.searchListShow = false;
      this.search = !this.search;
    },
    //input 输入求情数据
    onChange() {
      this.show = false;
      //   搜索框输入后请求接口数据
      this.$api
        .queryProjectList({
          projectName: this.searchValue,
        })
        .then((res) => {
          if (res.state.code === 10000) {
            if (res.body.length) {
              this.searchListShow = true;
              this.searchList = res.body;
              this.$emit("getSearchList", res.body);
            } else {
              this.searchListShow = false;
              Toast("暂无数据");
            }
          }
        });
      //   this.search = !this.search;
      if (this.searchValue === "") {
        this.$parent.getEngineeringCount();
        console.log("清空");
      }
    },
    onSearch() {
      this.$api
        .queryProjectList({
          projectName: this.searchValue,
        })
        .then((res) => {
          console.log(res);
          if (res.state.code === 10000) {
            if (res.body.length) {
              this.searchListShow = true;
              this.searchList = res.body;
              this.$emit("getSearchList", res.body);
            } else {
              this.searchListShow = false;
              Toast("暂无数据");
              screen_item;
            }
          }
        });
      this.search = !this.search;
    },
    onCancel() {
      this.search = !this.search;
      this.searchValue = "";
      this.searchList = [];
      this.searchListShow = false;
    },
    cross() {
      this.prograssname = "";
      this.searchValue = "";
      this.onSearch();
      this.$emit("cancle");
    },

    //点击录音
    voiceFun(obj) {
      this.show = obj == "open" ? true : false;
      this.searchListShow = false;
      this.searchValue = "";
      this.voiceTxt = "";
      this.longShow = false;
      if (this.searchValue === "") {
        this.onSearch();
        //     if(this.checked===true){
        //       this.projectType()
        //   }
      }
    },
    //获取签名signature
    getAuthSign() {
      this.$api.engineering
        .getAuthSign({
          corpId: this.corpId,
          corpSecret: this.corpSecret,
          noncestr: this.nonceStr,
          timestamp: this.timeStamp,
          url: window.location.href.split("#")[0], //当前网页的URL，不包含#及其后面部分
        })
        .then((res) => {
          if (res.state.code == 10000) {
            window.localStorage.setItem("signature", res.body.message);
            this.getBase();
          }
        });
    },
    getBase() {
      wx.config({
        beta: true, // 调用wx.invoke形式的接口值时，该值必须为true。
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: this.corpId, // 必填，企业微信的cropID
        timestamp: this.timeStamp, // 必填，生成签名的时间戳
        nonceStr: this.nonceStr, // 必填，生成签名的随机串
        signature: window.localStorage.getItem("signature"), // 必填，签名，见附录1
        // jsApiList: '',
        jsApiList: [
          "startRecord",
          "stopRecord",
          "playVoice",
          "onVoiceRecordEnd",
          "translateVoice",
        ], // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
      });
      wx.ready(() => {}),
        wx.error(function (res) {
          var ua = window.navigator.userAgent.toLowerCase();
          if (!(ua.indexOf("micromessenger") > -1)) {
            alert("出错了：" + JSON.stringify(res));
          }
          // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
        });
    },
    touchStart() {
      let _this = this;
      let isMinite = false;
      _this.loop = setTimeout(function () {
        _this.loop = 0;
        //执行长按要执行的内容，如弹出菜单
        _this.voiceTxt = "倾听中，松手结束";
        _this.longShow = true;
        wx.startRecord(); //开始录音
      }, 500);
      // this.timer = setTimeout(function(){
      //   alert('已过1分钟')
      //   _this.touchEnd();
      // }, 1000*5);
      // clearTimeout(_this.timer);
    },
    touchEnd() {
      let _this = this;
      clearTimeout(_this.loop);
      // if(_this.loop!=0){
      _this.longShow = false;
      //这里写要执行的内容（尤如onclick事件）
      wx.stopRecord({
        success: function (res) {
          _this.localId = res.localId;
          _this.voiceTxt = "识别中，请稍后";
          _this.timer = setTimeout(function () {
            _this.translateVoice();
          }, 1000 * 3);
        },
        fail: function (res) {
          Toast("识别失败，请重新录音");
        },
      });
      clearTimeout(_this.timer);
      // }
    },
    //语音转文字
    translateVoice() {
      let _this = this;
      // alert('转文字')
      // alert(_this.localId)
      wx.translateVoice({
        localId: _this.localId, // 需要识别的音频的本地Id，由录音相关接口获得，音频时长不能超过60秒
        isShowProgressTips: 1, // 默认为1，显示进度提示
        success: function (res) {
          _this.voiceTxt = "";
          // alert(res.translateResult)
          _this.searchValue = res.translateResult
            ? res.translateResult.substr(0, res.translateResult.length - 1)
            : "";
          _this.onChange();
        },
        fail: function (res) {
          Toast("语音转文字失败");
        },
      });
    },
  },
};
</script>
<style lang='scss' scoped>
.screen_name {
  position: relative;
}

.cross {
  position: absolute;
  right: 20px;
  top: 13px;
}

.screen_items {
  width: 30%;
}

.screen .van-search {
  padding: 2px !important;
}

.screen .screen_items .screen_item {
  margin-bottom: 0px !important;
}

//新样式
.searchDiv {
  width: 60%;
  position: relative;
  width: 55%;
  margin-right: 13vw;
}
.iconVoice {
  position: absolute;
  right: -2rem;
  top: 25%;
  width: 40px;
  height: 40px;
  background: url("../assets/img/engineering/icon_voice.png") no-repeat;
  background-size: 100%;
  z-index: 5;
}
.fullModal {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: transparent;
}
.voiceModal {
  height: 350px;
  position: fixed;
  left: 0;
  right: 0;
  bottom: -400px;
  background: #fff;
  border-top-left-radius: 30px;
  border-top-right-radius: 30px;
  z-index: 9999;
  transition: all 0.3s ease-in;

  .close {
    position: absolute;
    right: 20px;
    top: 15px;
    color: #fff;
  }
  .img {
    background: #2980b9;
    text-align: center;
    padding: 20px 0;
    p {
      color: #fff;
      padding-top: 20px;
    }
    img {
      width: 10%;
    }
  }
  .button {
    margin-top: 20px;
    padding: 0 10px;
    position: absolute;
    bottom: 20px;
    left: 0;
    right: 0;
    button {
      display: block;
      width: 100%;
      -webkit-touch-callout: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }
  }
}

.voiceModal.show {
  bottom: 0;
}
</style>