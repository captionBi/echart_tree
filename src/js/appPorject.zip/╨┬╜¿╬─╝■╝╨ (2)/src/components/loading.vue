<template>
<div class="loading">
    <van-overlay :show="show" class-name="className">
        <div class="wrapper" @click.stop>
            <van-loading size="40px"/>
        </div>
    </van-overlay>
</div>
</template>

<script>
import {Overlay, Loading } from "vant";
export default {
  components: {
    [Overlay.name]: Overlay,
    [Loading.name]: Loading
  },
  name: "loading",
  data() {
    return {
      show: true
    };
  },
  created() {}
};
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}
.className{
  background: rgba(0,0,0,.5)
}
</style>
