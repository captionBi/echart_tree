
// 记录日志
if(isWeiXin()){
    logRecord();
}
// 记录日志
function logRecord(){
    var code='', pageName = '', appCode = '', pageCode = '';
    code = getUrlKey("code")?getUrlKey("code"):'';
    var local = window.location.href;
    var APPID = "ww1736e9ae98ad76c9";
    var href = [{
        name: '珠三角工程云图',
        pageCode: 'location',
        appCode: 'prdEngineeCloud',
    },{
        name: '财经大数据',
        pageCode: 'economics',
        appCode: 'cjBigData',
    }];
    for(var i=0; i<href.length; i++){
        if(local.indexOf(href[i].pageCode)>0){
            pageCode = href[i].pageCode;
            appCode = href[i].appCode;
            pageName = href[i].pageName;
        }
    }
    if (code){
        $.ajax({
            url: 'gdh-com-hk-digital-accessloghistorysvc/api/service/logUserAccessInfo',
            data: {
                corpId: 'ww1736e9ae98ad76c9',
                code: code,
                appCode: appCode,
                pageCode: pageCode,
                pageName: pageName,
                pageUrl: window.location.href,
            },
            type: 'post',
            cache: false,
            async: true,
            success: function (res) {  }
        })
    }else{
        window.location.href =
        "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" +
        APPID +
        "&redirect_uri=" +
        encodeURIComponent(local) +
        "&response_type=code&scope=snsapi_base&state=oadatagetcode&connect_redirect=1#wechat_redirect";
    }
};
// 只在微信访问
function isWeiXin() {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.indexOf('micromessenger') > -1) {
        return true; // 是微信端
    } else {
        return false;
    }
}
// 获取url的参数
function getUrlKey(name) {
  return (
    decodeURIComponent((new RegExp("[?|&]" + name + "=" + "([^&;]+?)(&|#|;|$)").exec(window.location) || [, ""])[1].replace(/\+/g, "%20")) || null
  );
};