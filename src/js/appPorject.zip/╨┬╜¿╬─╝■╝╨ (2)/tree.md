.

├── dist //打包后文件 发布到服务器
│   ├── css
│   ├── favicon.ico
│   ├── img
│   ├── index.html
│   └── js
├── node_modules //依赖包
├── package-lock.json //package 的具体来源和版本号
├── package.json //定义项目中需要依赖的包
├── public //静态资源会复制到 dist 文件夹中
│   ├── favicon.ico //ico
│   └── index.html //入口页面
├── src
│   ├── App.vue //顶层路由
│   ├── api //与后端交互的方法及配置
│   │   ├── config.js //请求方法封装
│   │   └── index.js //请求接口
│   ├── assets //静态资源 图片、文字、css 等
│   │   ├── img
│   │   └── style
│   ├── components //公共组件
│   │   ├── loading.vue
│   │   └── nothing.vue
│   ├── main.js //入口文件
│   ├── pages //按功能划分的页面
│   │   ├── common
│   │   ├── complaint
│   │   └── repair
│   ├── router.js //路由及配置
│   └── utils //公共工具
│   ├── config.js //公共配置
│   ├── filters.js //过滤器
│   └── methods.js //公共方法
├── .gitignore //git 提交时忽略文件
├── vue.config.js
├── README.md //项目介绍
└── babel.config.js

3639 directories, 5902 files
