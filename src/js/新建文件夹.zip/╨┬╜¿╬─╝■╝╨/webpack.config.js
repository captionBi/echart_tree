const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { VueLoaderPlugin } = require('vue-loader');

const config = {
  //配置的entry单入口webpack4默认 ./src/index.js
  // webpack打包输出配置
  output: {
    path: path.join(__dirname, './dist'),
    publicPath: '/dist/',
    filename: 'main.js'
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader',
        options: {
          loaders: {
            css: [
              'vue-style-loader',
              'mini-css-extract-plugin',
              'css-loader'
            ]
          }
        }
      },
      {
        test: /\.less$/,
        loader: "style-loader!css-loader!less-loader",
      },
      {
        test: /\.css$/,
        //数组形式的话，编译是从后往前。
        use: [
          MiniCssExtractPlugin.loader,
          'css-loader'
        ]
      },
      {
        test: /\.(gif|jpg|png|woff|svg|eot|ttf)\??.*$/,
        //文件小于1k就以base64形式加载
        loader: 'url-loader?limit=1024'
      }
    ],
  },
  devServer: {
    host: 'localhost',//target host
    port: 8080,
    //proxy:{'/api':{}},代理器中设置/api,项目中请求路径为/api的替换为target
    proxy: {
      '/api': {
        target: 'http://10.1.20.194:10081',//代理地址，这里设置的地址会代替axios中设置的baseURL
        changeOrigin: true,// 如果接口跨域，需要进行这个参数配置
        //ws: true, // proxy websockets
        //pathRewrite方法重写url
        pathRewrite: {
          '^/api': '/api'
          //pathRewrite: {'^/api': '/'} 重写之后url为 http://192.168.1.16:8085/xxxx
          //pathRewrite: {'^/api': '/api'} 重写之后url为 http://192.168.1.16:8085/api/xxxx
        }
      },
      '/videoApi': {
        target: 'http://10.1.20.194:10004',
        changeOrigin: true,
        pathRewrite: {
          '^/videoApi': '/api'
        }
      },
      '/projects': {
        target: 'http://10.1.20.194:10014',
        changeOrigin: true,
        pathRewrite: {
          '^/projects': '/api'
        }
      },
      '/wxApi': {
        target: 'http://10.1.20.194:10066',
        changeOrigin: true,
        pathRewrite: {
          '^/wxApi': '/api'
        }
      }
    }
  },
  plugins: [
    new MiniCssExtractPlugin('main.css'),
    new VueLoaderPlugin()
  ]
};
module.exports = config;