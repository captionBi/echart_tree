import Vue from 'vue';
import router from './router';
import store from './store';
import App from './app.vue';
import './style.css';
import less from 'less'
import api from "./api"
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import 'video.js/dist/video-js.css'
Vue.use(ElementUI);
Vue.prototype.$api = api;
Vue.use(less)

const app = new Vue({
    el: '#app',
    router,
    store,
    render: h => {
        return h(App)
    }
})


