import Vue from 'vue';
import Vuex from 'vuex';
import product_data from './product';
import util from './util';
import {
  get,
  post
} from './http'
Vue.use(Vuex);
//配置Vuex状态管理
const store = new Vuex.Store({
  state: {
    //列表信息
    productList: [],
    imagesList: [],
    operCommBids: [],
    plans: [],
    detailList: [],
    timeValue: '',
    ganttType: 1,
    projectListData: [],
    screenNum: 0
  },
  getters: {
    // brands: state => {
    //   const brands = state.productList.map(item => item.brand);
    //   return util.getFilterArray(brands);
    // },
  },
  //mutations只能以同步方式
  mutations: {
    //获取数据
    setProductList(state, data) {
      state.productList = data;
    },
    setImagesList(state, data) {
      state.imagesList = data;
    },
    setOperCommBids(state, data) {
      state.operCommBids = data;
    },
    setPlans(state, data) {
      state.plans = data;
    },
    setDetailList(state, data) {
      state.detailList = data;
    },
    setTimeValue(state, data) {
      state.timeValue = data;
    },
    setGanttTimeSelect(state, data) {
      state.ganttType = data;
    },
    setProjectList(state, data) {
      state.projectListData = data;
    },
    setScreen(state, data) {
      state.screenNum = data;
    }
  },
  actions: {
    projectDetailData(state, data) {
      Date.prototype.Format = function (fmt) {
        // author: meizz
        var o = {
          "M+": this.getMonth() + 1, // 月份
          "d+": this.getDate(), // 日
          "h+": this.getHours(), // 小时
          "m+": this.getMinutes(), // 分
          "s+": this.getSeconds(), // 秒
          "q+": Math.floor((this.getMonth() + 3) / 3), // 季度
          S: this.getMilliseconds(), // 毫秒
        };
        if (/(y+)/.test(fmt))
          fmt = fmt.replace(
            RegExp.$1,
            (this.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        for (var k in o)
          if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
        return fmt;
      };
      setInterval(() => {
        let newTime = new Date().Format("yyyy-MM-dd hh:mm:ss");
        state.commit('setTimeValue', newTime)
      }, 1000);
      return new Promise(resolve => {
        get(`/api/service/getProjectDetaiInfo/${data}`).then(res => {
          console.log('datassssssss', res.body)
          state.commit('setOperCommBids', res.body.operCommBids)
          state.commit('setPlans', res.body.plans)
          state.commit('setDetailList', res.body)
          resolve();
        })
      });
    },
    projectData(state, data) {
      Date.prototype.Format = function (fmt) {
        // author: meizz
        var o = {
          "M+": this.getMonth() + 1, // 月份
          "d+": this.getDate(), // 日
          "h+": this.getHours(), // 小时
          "m+": this.getMinutes(), // 分
          "s+": this.getSeconds(), // 秒
          "q+": Math.floor((this.getMonth() + 3) / 3), // 季度
          S: this.getMilliseconds(), // 毫秒
        };
        if (/(y+)/.test(fmt))
          fmt = fmt.replace(
            RegExp.$1,
            (this.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        for (var k in o)
          if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
        return fmt;
      };
      setInterval(() => {
        let newTime = new Date().Format("yyyy-MM-dd hh:mm:ss");
        state.commit('setTimeValue', newTime)
      }, 1000);
      return new Promise(resolve => {
        post(`/api/service/getIndexInfo/${data.page}/${data.pageSize}`, { projectId: '' }).then(res => {
          localStorage.setItem('totalPage', res.body.totalPage)
          state.commit('setProductList', res.body.dataList)
          state.commit('setImagesList', res.body.imagesList)
          resolve();
        })
      });
    },
    setGanttTpye(state, data) {
      console.log('aaaaaabbbbb', data)
      state.commit('setGanttTimeSelect', data)
    },
    hasProjectArry(state, data) {
      return new Promise(resolve => {
        get(`/api/service/getProjectList`).then(res => {
          state.commit('setProjectList', res.body)
          resolve();
        })
      });
    },
    allScreenClick(state, data) {
      state.commit('setScreen', data)
    },
  }
});
export default store;