import {
  post,
  get
} from '../http'
function video(e, url) {
  var videoObject = {
    container: `#ckplayer${e}`, // 容器的ID或className
    variable: "player1", // 播放函数名称 与下面一致
    autoplay: true, // 是否自动播放
    live: true, // 是否是直播视频 true = 直播，false = 点播
    mobileCkControls: false, // 是否在移动端（包括ios）环境中显示控制
    video: url, // hls地址
  };
  return videoObject;
}
export function getVedio(cam, id) {
  let params = {
    cameraIndexCode: cam,
    streamType: 0,
    protocol: "hls",
    transmode: 1,
  };
  post("/videoApi/service/getCamerasUrl", params).then(function (res) {
    if (res.state.code == 10000) {
      if (res.body.data && res.body.data.url) {
        let url = res.body.data ? res.body.data.url : "";
        let targetAddr = "157.122.3.51:83";
        url = url
          .replace("192.168.112.204:83", targetAddr)
          .replace("192.168.112.205:83", targetAddr);
        // let addr = 'http://192.168.112.204:83' || 'http://192.168.112.205:83'
        // url = url.replace(addr, "http://157.122.3.51:83");
        console.log('ggggg', url)
        new ckplayer(video(id, url));
      }
    }
  });
}
//type=0的情况 getUrl('AA9DE9D6799F070FE05550540048709A', "#video7");
export function getUrl(cam, id) {
  get(`/videoApi/service/getProjectVideoUrl/${cam}`).then(function (res) {

    if (res.state.code === 10000) {
      if (res.body.code === 0) {
        var url = res.body.data.url; //res.body.data ? res.body.data.url : '';
        var cacheId = res.body.data.cacheId; //res.body.data ? res.body.data.cacheId : '';
        console.log(cacheId);
        // cacheId_arr.push(cacheId);
        // console.log(cacheId_arr);
        url = url.replace("api.welink.qq.com:880", "219.135.193.190:8088");
        console.log('yyyyyyyyyyyyy', url)
        new ckplayer(video(id, url));
      }
    }
  });
}


