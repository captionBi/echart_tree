import {
    get
} from '../http'

// const baseString_1 = "http://10.1.20.194:10014";

export default {
    VideoLists(id, page) {
        console.log('id', id ? id : ' ')
        return get(`/projects/service/getVideoListByProjectId/${id ? id : ' '}/${page}/8`)
    }
}