import {
    post,
    get
} from '../http'

// const baseString_1 = "http://10.1.20.194:10004";

export default {
    // type=0的情况 getUrl('AA9DE9D6799F070FE05550540048709A', "#video7");
    // type=2的情况下用getVedio getVedio('1ac96587709f4a76a4f013e95dd8caf7', "#video5");
    getCamerasUrl(parameter) {
        return post(`/videoApi/service/getCamerasUrl/`, parameter);
    },
    ProjectVide(cam) {
        return get(`/videoApi/service/getProjectVideoUrl/${cam}`);
    },
}