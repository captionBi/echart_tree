// 地址

// 开发
const baseUrl = 'http://localhost:8080/'


// 测试
// const baseUrl = 'http://10.1.20.193:6001/gdh-com-hk-digital-projectsvc/api'
// const baseUrl = 'http://10.1.20.194/'
// const baseUrl = 'https://itest.gdhchina.com/'



// uat
// const baseUrl = 'https://itest.gdhchina.com'




// 生产
// const baseUrl = ''


export default {
    baseUrl
}