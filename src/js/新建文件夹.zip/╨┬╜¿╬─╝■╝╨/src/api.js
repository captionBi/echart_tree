import sreem from './viewApi/sreem'
import encodeView from './viewApi/encodeView'

export default {
    sreem,
    encodeView,
}