<template>
  <div class="secondDiv">
    <div class="seconTop">
      <div class="topLeft">
        <div class="gobackclass">
          <img @click="gobackclick" src="../images/2icon@2x.png" alt />
        </div>
        <div>{{ jsdw != "undefined" ? jsdw : "" }}</div>
        <el-tooltip effect="dark" :content="xmmc" placement="top-start">
          <div>{{ xmmc }}</div>
        </el-tooltip>
        <!-- <div class="posiDiv">
          <div>
            <div>{{ seeTime.substring(0, 10) }}</div>
            <div class="cols">{{ seeTime.substring(10) }}</div>
          </div>
          <div>
          </div>
          <div>
            <div>多云</div>
            <div class="cols">27℃</div>
          </div>
        </div> -->
      </div>
      <div class="topRight">
        <div class="btnDiv">
          <div @click="homeClick">
            <img v-if="isHome" src="../images/5.1icon@2x.png" alt />
            <img v-else src="../images/5icon@2x.png" alt />
          </div>
          <div @click="tablesClick">
            <img v-if="isTable" src="../images/1.1icon@2x.png" alt />
            <img v-else src="../images/1icon@2x.png" alt />
          </div>
          <div @click="dataClick">
            <img v-if="isView" src="../images/9icon@2x.png" alt />
            <img v-else src="../images/9.1icon@2x.png" alt />
          </div>
        </div>
        <div class="timediv" v-if="isTable">
          <div>
            <div
              :class="isClick === '1' ? 'clickColor' : ''"
              @click="showTimeClick('1')"
            >
              月
            </div>
            <div
              :class="isClick === '2' ? 'clickColor' : ''"
              @click="showTimeClick('2')"
            >
              周
            </div>
            <div
              :class="isClick === '3' ? 'clickColor' : ''"
              @click="showTimeClick('3')"
            >
              日
            </div>
          </div>
        </div>
        <div class="allScreen" v-if="isTable">
          <div @click="allscreenclick">全屏</div>
        </div>
        <div class="backgroundwork">
          <div>总工期(月)</div>
          <div v-if="detailList.zgq && detailList.zgq.length >= 2">
            <span style="background: #198bf7">{{
              detailList.zgq.substring(0, 1)
            }}</span>
            <span style="background: #198bf7">{{
              detailList.zgq.substring(1, 2)
            }}</span>
          </div>
          <div v-else>
            <span style="background: #198bf7">{{ detailList.zgq }}</span>
          </div>
        </div>
        <div class="backgroundwork">
          <div>已开工(月)</div>
          <div v-if="detailList.ykg && detailList.ykg.length >= 2">
            <span style="background: #00ecb1">{{
              detailList.ykg.substring(0, 1)
            }}</span>
            <span style="background: #00ecb1">{{
              detailList.ykg.substring(1, 2)
            }}</span>
          </div>
          <div v-else>
            <span style="background: #00ecb1">{{ detailList.ykg }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="secondContent">
      <div class="contentLeft">
        <div class="imgpic">
          <img :src="detailList.pmturl" alt />
        </div>
        <div class="seeDataLine">
          <div class="linetis">
            <div>
              <div></div>
              <div>未完成</div>
            </div>
            <div>
              <div></div>
              <div>已完成</div>
            </div>
            <div>
              <div></div>
              <div>预警中</div>
            </div>
            <div>
              <div></div>
              <div>延误完成</div>
            </div>
            <div>
              <div></div>
              <div>延期未完成</div>
            </div>
          </div>
          <div class="espscrol" :class="plans.length >= 6 ? 'scrollclass' : ''">
            <div class="linepic">
              <div
                class="allLines"
                :style="{ width: plans.length >= 6 ? '300%' : '97%' }"
              >
                <div
                  class="oneClass"
                  v-for="(item, index) in plans"
                  :key="index"
                  :style="{ left: `${300 * index}px` }"
                >
                  <div
                    class="kongs"
                    v-if="index === 0"
                    :style="{
                      width: `${200 * (index + 1)}px`,
                      background: `${
                        item.planStatus === 1
                          ? 'none'
                          : item.planStatus === 2
                          ? '#00ecb1'
                          : item.planStatus === 3
                          ? '#ffd70d'
                          : item.planStatus === 4
                          ? '#ec0532'
                          : 'none'
                      }`,
                    }"
                  ></div>
                  <div
                    class="dians"
                    :style="{
                      background: `${
                        item.planStatus === 1
                          ? 'none'
                          : item.planStatus === 2
                          ? '#00ecb1'
                          : item.planStatus === 3
                          ? '#ffd70d'
                          : item.planStatus === 4
                          ? '#ec0532'
                          : 'none'
                      }`,
                      left: `${200}px`,
                      border: `1px solid ${
                        item.planStatus === 1
                          ? 'white'
                          : item.planStatus === 5
                          ? '#ec0532'
                          : ''
                      }`,
                    }"
                  ></div>
                  <div
                    class="xians"
                    :style="{
                      left: `200px`,
                      width: `300px`,
                      background: `${
                        item.planStatus === 1
                          ? 'none'
                          : item.planStatus === 2
                          ? '#00ecb1'
                          : item.planStatus === 3
                          ? '#ffd70d'
                          : item.planStatus === 4
                          ? '#ec0532'
                          : 'none'
                      }`,
                    }"
                  ></div>
                  <div class="times" style="">{{ item.planDate }}</div>
                  <el-tooltip
                    class="names"
                    effect="dark"
                    :content="item.planName"
                    placement="top-start"
                  >
                    <div @click="showPleClick(item)">{{ item.planName }}</div>
                  </el-tooltip>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="contentRight">
        <router-view></router-view>
      </div>
    </div>
    <div v-if="showGantt" class="closeDivs">
      <img @click="closebox" src="../images/5icon@2x.png" alt="" />
    </div>
    <div v-if="showPlo" class="problemBox">
      <div>
        <img @click="closeProblem" src="../images/close.png" alt="" />
      </div>
      <div>
        <div class="contetnsp">
          <div>计划内容:</div>
          <div>
            <pre>{{ problemData.planName }}</pre>
          </div>
        </div>
        <div class="contetnsp">
          <div>问题原因:</div>
          <div>
            <pre>{{ problemData.causeProblem }}</pre>
          </div>
        </div>
        <div class="contetnsp">
          <div>问题对策:</div>
          <div>
            <pre>{{ problemData.problemsCountermeasures }}</pre>
          </div>
        </div>
        <div class="contetnsp">
          <div>
            {{ problemData.planStatus === 4 ? "实际完成:" : "预期完成:" }}
          </div>
          <div>
            <pre>{{ problemData.endDate }}</pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { post } from "../http";
export default {
  name: "secondDiv",
  data() {
    return {
      showPlo: false,
      showGantt: false,
      isClick: "1",
      isHome: true,
      isTable: false,
      isView: false,
      jsdw: "",
      xmmc: "",
      timestamp: "",
      nonceStr: "",
      signature: "",
      problemData: {},
    };
  },
  computed: {
    detailList() {
      return this.$store.state.detailList;
    },
    // seeTime() {
    //   return this.$store.state.timeValue;
    // },
    plans() {
      console.log("sssssssss", this.$store.state.plans);
      return this.$store.state.plans;
    },
  },
  methods: {
    showPleClick(item) {
      this.problemData = item;
      this.showPlo = true;
    },
    closeProblem() {
      this.showPlo = false;
    },
    closebox() {
      this.showGantt = false;
      this.$store.dispatch("allScreenClick", 0);
    },
    allscreenclick() {
      this.showGantt = true;
      this.$store.dispatch("allScreenClick", 1);
    },
    showTimeClick(type) {
      this.isClick = type;
      localStorage.setItem("timeTpye", type);
      this.$store.dispatch("setGanttTpye", type);
    },
    gobackclick() {
      this.$router.push({ path: "/index" });
    },
    homeClick() {
      this.isHome = true;
      this.isTable = false;
      this.isView = false;
      this.$router.push({
        path: "/second/home",
        query: {
          id: this.$route.query.id,
        },
      });
    },
    tablesClick() {
      this.isTable = true;
      this.isHome = false;
      this.isView = false;
      this.$router.push({
        path: "/second/tables",
        query: {
          id: this.$route.query.id,
        },
      });
    },
    dataClick() {
      this.isView = true;
      this.isTable = false;
      this.isHome = false;
      this.$router.push({
        path: "/second/views",
        query: {
          id: this.$route.query.id,
        },
      });
    },
  },
  mounted() {
    this.jsdw = localStorage.getItem("jsdw");
    this.xmmc = localStorage.getItem("xmmc");
    if (window.location.href.indexOf("second/home") != -1) {
      this.isView = false;
      this.isTable = false;
      this.isHome = true;
    } else if (window.location.href.indexOf("second/tables") != -1) {
      this.isView = false;
      this.isTable = true;
      this.isHome = false;
    } else {
      this.isView = true;
      this.isTable = false;
      this.isHome = false;
    }
    this.$store.dispatch("projectDetailData", this.$route.query.id);
  },
};
</script>

<style scoped lang="less">
.secondDiv {
  display: flex;
  flex-flow: column;
  height: 100%;
  padding-top: 40px;
  .seconTop {
    display: flex;
    height: 180px;
    .topLeft {
      position: relative;
      flex: 1;
      display: flex;
      .gobackclass {
        width: 120px;
        height: 120px;
        margin-left: 20px;
        img {
          display: block;
          width: 100%;
          height: 100%;
        }
      }
      & > div:nth-child(2) {
        margin-left: 2%;
        font-size: 34px;
        line-height: 50px;
      }
      & > div:nth-child(3) {
        width: 45%;
        margin-left: 2%;
        font-size: 60px;
        font-weight: 600;
        height: 170px;
        text-overflow: -o-ellipsis-lastline;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        cursor: pointer;
      }
      .posiDiv {
        position: relative;
        right: 20px;
        top: 0;
        display: flex;
        width: 460px;
        align-items: center;
        justify-content: center;
        & > div:nth-child(1) {
          text-align: right;
        }
        & > div:nth-child(2) {
          margin: 0 10px;
          width: 30px;
          height: 30px;
          img {
            display: block;
            width: 100%;
            height: 100%;
          }
        }
        .cols {
          color: aqua;
        }
      }
    }
    .topRight {
      flex: 1;
      display: flex;
      margin: 0 40px;
      .btnDiv {
        display: flex;
        flex: 1;
        & > div {
          width: 100px;
          height: 80px;
          margin-right: 130px;
          img {
            width: 100%;
            height: 100%;
            display: block;
          }
        }
      }
      .timediv {
        margin-right: 40px;
        & > div {
          display: flex;
          width: 340px;
          height: 120px;
          line-height: 120px;
          & > div {
            padding: 4px;
            cursor: pointer;
            width: 33%;
            text-align: center;
          }
        }
      }
      .allScreen {
        flex: 1;
        div {
          line-height: 128px;
          cursor: pointer;
          width: 120px;
          font-size: 40px;
        }
      }
      & > div:nth-child(4) {
        margin-right: 40px;
        margin-left: 40px;
      }
      .backgroundwork {
        & > div:nth-child(2) {
          text-align: center;
          span {
            display: inline-block;
            text-align: center;
            width: 40px;
            height: 100px;
            line-height: 100px;
            color: white;
            border-radius: 12px;
          }
        }
      }
    }
  }
  .secondContent {
    flex: 1;
    display: flex;
    .contentLeft {
      flex: 1;
      display: flex;
      flex-flow: column;
      .imgpic {
        width: 100%;
        img {
          width: 100%;
          height: 440px;
          display: block;
        }
      }
      .seeDataLine {
        height: 410px;
        padding-top: 16px;
        width: 100%;
        .linetis {
          padding-top: 20px;
          display: flex;
          & > div {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-left: 60px;
            font-size: 26px;
            & > div:nth-child(1) {
              width: 30px;
              height: 30px;
              border-radius: 50%;
              margin-right: 10px;
            }
          }
          & > div:nth-child(1) {
            & > div:nth-child(1) {
              border: 1px solid white;
            }
          }
          & > div:nth-child(2) {
            & > div:nth-child(1) {
              background: #00ecb1;
            }
          }
          & > div:nth-child(3) {
            & > div:nth-child(1) {
              background: #ffd70d;
            }
          }
          & > div:nth-child(4) {
            & > div:nth-child(1) {
              background: #ec0532;
            }
          }
          & > div:nth-child(5) {
            & > div:nth-child(1) {
              border: 1px solid red;
            }
          }
        }
        .espscrol {
          height: 250px;
          .allLines {
            margin-top: 90px;
            margin-left: 40px;
            height: 4px;
            background: #aeaeb0;
            .oneClass {
              position: relative;
              // height: 4px;
              // background: #aeaeb0;
              .kongs {
                position: absolute;
                left: 0px;
                top: 0px;
                background: #00ecb1;
                width: 100px;
                height: 4px;
                z-index: 9;
              }
              .dians {
                position: absolute;
                left: 100px;
                top: -6px;
                background: #00ecb1;
                width: 20px;
                height: 20px;
                border-radius: 50%;
                z-index: 9;
              }
              .xians {
                position: absolute;
                top: 0;
                left: 100px;
                width: 250px;
                height: 4px;
                background: #ffd70d;
              }
              .times {
                position: absolute;
                top: -60px;
                left: 100px;
                font-size: 26px;
              }
              .names {
                position: absolute;
                bottom: -130px;
                width: 200px;
                height: 78px;
                font-size: 28px;
                left: 100px;
                text-overflow: -o-ellipsis-lastline;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                cursor: pointer;
              }
            }
          }
        }
      }
    }
    .contentRight {
      flex: 1;
      margin: 0 40px;
      width: 50%;
    }
  }
  .closeDivs {
    transition: all 2000ms;
    -o-transition: all 2000ms; /*兼容parsto内核*/
    -moz-transition: all 2000ms; /*兼容gecko内核*/
    -webkit-transition: all 2000ms; /*兼容webkit内核*/
    position: fixed;
    bottom: 40px;
    left: 48%;
    z-index: 99;
    img {
      width: 80px;
      height: 80px;
    }
  }
  .problemBox {
    width: 1500px;
    padding: 20px 20px 40px 20px;
    position: fixed;
    flex-direction: column;
    top: 20%;
    left: 5%;
    z-index: 99;
    background: #0a1e37;
    color: white;
    height: 650px;
    & > div:nth-child(1) {
      text-align: right;
      height: 90px;
      img {
        width: 40px;
        height: 40px;
        cursor: pointer;
      }
    }
    & > div:nth-child(2) {
      flex: 1;
      height: 530px;
      overflow-y: scroll;
      margin-right: 20px;
      .contetnsp {
        display: flex;
        margin-top: 20px;
        font-size: 40px;
        & > div:nth-child(1) {
          margin-right: 20px;
        }
        & > div:nth-child(2) {
          flex: 1;
          pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            // line-height: 44px;
          }
        }
      }
    }
  }
}
.clickColor {
  background: #20a0ff;
  color: white;
}
.scrollclass {
  overflow-x: scroll;
}
</style>