<template>
  <div class="indexDiv">
    <div class="indexLeftTop">
      <div class="wleftTop">
        <div class="topfons">挂图作战指挥平台</div>
        <!-- <div class="posiDiv">
          <div>
            <div>{{ seeTime.substring(0, 10) }}</div>
            <div class="cols">{{ seeTime.substring(10) }}</div>
          </div>
          <div>
          </div>
          <div>
            <div>多云</div>
            <div class="cols">27℃</div>
          </div>
        </div> -->
      </div>
      <div class="contentTis">
        <div>
          <div></div>
          <div>总投资</div>
        </div>
        <div>
          <div></div>
          <div>截止本年计划投资</div>
        </div>
        <div>
          <div></div>
          <div>目前实际完成投资</div>
        </div>
        <div class="posiDiv">
          <div class="imgDivsshow">
            <img src="../images/founddata.png" alt="" />
            <div class="contentdiv">
              <div class="sondiv">
                <div>
                  <div
                    :class="projectNum === 1 ? 'bottomColor' : ''"
                    @click="projectClick(1)"
                  >
                    水务及水环境治理
                  </div>
                  <div
                    :class="projectNum === 2 ? 'bottomColor' : ''"
                    @click="projectClick(2)"
                  >
                    产业园及制造业
                  </div>
                  <div
                    :class="projectNum === 3 ? 'bottomColor' : ''"
                    @click="projectClick(3)"
                  >
                    城市综合体
                  </div>
                </div>
                <div class="projectData" v-if="projectNum === 1">
                  <div
                    v-for="(item, index) in projectListData.waterList"
                    :key="index"
                    @click="godetailClick(item)"
                  >
                    {{ item.projectName }}
                  </div>
                </div>
                <div class="projectData" v-if="projectNum === 2">
                  <div
                    v-for="(item, index) in projectListData.industryList"
                    :key="index"
                    @click="godetailClick(item)"
                  >
                    {{ item.projectName }}
                  </div>
                </div>
                <div class="projectData" v-if="projectNum === 3">
                  <div
                    v-for="(item, index) in projectListData.cityList"
                    :key="index"
                    @click="godetailClick(item)"
                  >
                    {{ item.projectName }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="contentData">
        <div
          class="projects"
          v-for="(item, index) in productList"
          :key="index"
          @click="godetails(item)"
        >
          <div class="seeData">
            <div class="seetop">
              <!-- <div>{{ item.xmmc }}</div> -->
              <el-tooltip
                effect="dark"
                :content="item.xmmc"
                placement="top-start"
              >
                <div>{{ item.xmmc }}</div>
              </el-tooltip>
              <!-- <div>{{ item.jsdw }}</div> -->
              <div>
                <div>计划完成</div>
                <div style="color: #00e0aa">{{ item.jhwc }}</div>
              </div>
              <div>
                <div>实际完成</div>
                <div style="color: #46bef7">{{ item.sjwc }}</div>
              </div>
              <!-- <div>
                <div>存在问题</div>
                <div style="color: #e9c70f">
                  {{ item.czwt }}
                  <span style="color: white">个</span>
                </div>
              </div> -->
              <div class="imgdiv">
                <img src="../images/3icon@2x.png" alt />
              </div>
            </div>
            <div class="seecont">
              <div>总投资额</div>
              <div>
                {{ item.ztz }}
                <span>亿元</span>
              </div>
              <div class="allMoney">
                <div
                  :style="{
                    width: `${
                      (item.jhtz / item.ztz) * 100 > 100
                        ? 100
                        : (item.jhtz / item.ztz) * 100
                    }%`,
                    zIndex: `${
                      (item.jhtz / item.ztz) * 100 <
                      (item.sjtz / item.ztz) * 100
                        ? '2'
                        : '1'
                    }`,
                  }"
                ></div>
                <div
                  :style="{
                    width: `${
                      (item.sjtz / item.ztz) * 100 > 100
                        ? 100
                        : (item.sjtz / item.ztz) * 100
                    }%`,
                    zIndex: `${
                      (item.jhtz / item.ztz) * 100 >
                      (item.sjtz / item.ztz) * 100
                        ? '2'
                        : '1'
                    }`,
                  }"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="nextDiv">
        <div>
          <img
            v-if="page >= 2 ? true : false"
            @click="pagego"
            src="../images/up.png"
            alt=""
          />
        </div>
        <div>
          <img
            v-if="Number(page) >= Number(totalPage) ? false : true"
            @click="pageback"
            src="../images/xiangxiajiantou.png"
            alt=""
          />
        </div>
      </div>
    </div>
    <div class="indexRight">
      <div>
        <el-carousel :height="widths">
          <el-carousel-item v-for="(item, index) in imagesList" :key="index">
            <img :src="item" alt />
          </el-carousel-item>
        </el-carousel>
      </div>
    </div>
  </div>
</template>

<script>
import util from "../util";
export default {
  name: "index",
  data() {
    return {
      projectNum: 1,
      totalPage: "",
      page: 1,
      widths: "",
      imgList: [
        {
          img: "../images/video_bg.jpg",
        },
        {
          img: "../images/video_bg.jpg",
        },
        {
          img: "../images/video_bg.jpg",
        },
        {
          img: "../images/video_bg.jpg",
        },
      ],
    };
  },
  computed: {
    productList() {
      return this.$store.state.productList;
    },
    imagesList() {
      return this.$store.state.imagesList;
    },
    projectListData() {
      return this.$store.state.projectListData;
    },
  },
  methods: {
    godetailClick(item) {
      console.log("aaaaaa", item);
      localStorage.setItem("xmmc", item.projectName);
      localStorage.setItem("jsdw", item.buildingUnit);
      this.$router.push({
        path: "/second/home",
        query: {
          id: item.id,
        },
      });
    },
    projectClick(num) {
      this.projectNum = num;
    },
    pagego() {
      if (this.page > 1) {
        this.page = Number(this.page) - 1;
        localStorage.setItem("page", this.page);
        this.$store.dispatch("projectData", { page: this.page, pageSize: 3 });
      } else {
        return;
      }
    },
    pageback() {
      if (Number(this.page) < Number(this.totalPage)) {
        this.page = Number(this.page) + 1;
        localStorage.setItem("page", this.page);
        this.$store.dispatch("projectData", { page: this.page, pageSize: 3 });
      } else {
        return;
      }
    },
    ckplayera(e) {},
    throttle(method) {
      this.widths = `${document.body.clientHeight}px`;
    },
    godetails(item) {
      localStorage.setItem("xmmc", item.xmmc);
      localStorage.setItem("jsdw", item.jsdw);
      this.$router.push({
        path: "/second/home",
        query: {
          id: item.id,
        },
      });
    },
  },
  mounted() {
    this.page = localStorage.getItem("page") ? localStorage.getItem("page") : 1;
    this.$store
      .dispatch("projectData", { page: this.page, pageSize: 3 })
      .then((res) => {
        this.totalPage = localStorage.getItem("totalPage");
        console.log("aaaaa", this.totalPage);
      });
    this.$store.dispatch("hasProjectArry");
    window.onresize = () => {
      //监听窗口的变化
      this.throttle();
    };
    this.widths = `${document.body.clientHeight}px`;
  },
};
</script>

<style scoped lang="less">
.indexDiv {
  display: flex;
  height: 100%;
  .indexLeftTop {
    display: flex;
    flex-direction: column;
    flex: 1;
    padding: 0 40px;
    position: relative;
    .wleftTop {
      display: flex;
      position: relative;
      .topfons {
        font-size: 60px;
        flex: 1;
        text-align: center;
      }
      // .posiDiv {
      //   position: absolute;
      //   right: 20px;
      //   top: 0;
      //   display: flex;
      //   align-items: center;
      //   justify-content: center;
      //   font-size: 50px;
      //   & > div:nth-child(1) {
      //     text-align: right;
      //   }
      //   & > div:nth-child(2) {
      //     margin: 0 10px;
      //   }
      //   .cols {
      //     color: #43b7ee;
      //   }
      // }
    }
    .contentTis {
      display: flex;
      margin-top: 20px;
      & > div {
        display: flex;
        align-items: center;
        margin-right: 10px;
        & > div:nth-child(1) {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          margin-right: 5px;
        }
        & > div:nth-child(2) {
          font-size: 40px;
        }
      }
      & > div:nth-child(1) {
        display: flex;
        justify-content: center;
        align-items: center;
        & > div:nth-child(1) {
          border: 2px solid white;
        }
      }
      & > div:nth-child(2) {
        display: flex;
        justify-content: center;
        align-items: center;
        & > div:nth-child(1) {
          background: #91d5ff;
        }
      }
      & > div:nth-child(3) {
        display: flex;
        flex: 1;
        & > div:nth-child(1) {
          background: #198bf7;
        }
      }
      .posiDiv {
        cursor: pointer;
        .imgDivsshow {
          width: 240px;
          height: 140px;
          text-align: center;
          position: relative;
          img {
            width: 140px;
            height: 140px;
          }
          .contentdiv {
            position: absolute;
            right: 160px;
            top: 0px;
            display: none;
            z-index: 9;
            background: url("../images/bg.jpg") no-repeat;
            background-size: 100% 100%;
            color: white;
            .sondiv {
              width: 1400px;
              height: 900px;
              // background: white;
              border-radius: 18px;
              & > div:nth-child(1) {
                height: 120px;
                line-height: 100px;
                width: 100%;
                display: flex;
                & > div {
                  width: 30%;
                  padding: 10px 30px;
                  color: white;
                  border-bottom: 4px solid #ccc;
                  margin-right: 40px;
                }

                & > div:nth-child(1) {
                  margin-left: 40px;
                }
                & > div:nth-child(3) {
                  margin-right: none;
                }
              }
            }
            .projectData {
              height: 750px;
              margin: 10px 40px;
              overflow-y: scroll;
              color: white;
              text-align: left;
              & > div {
                height: 100px;
                line-height: 100px;
                font-size: 42px;
                &:hover {
                  background: #ccc;
                }
              }
            }
          }
        }
        .imgDivsshow:hover .contentdiv {
          display: block;
        }
      }
    }
    .contentData {
      margin-top: 20px;
      display: flex;
      flex-direction: column;
      flex: 1;
      & > div:nth-last-child(1) .seeData {
        border-bottom: none;
      }
      .projects {
        display: flex;
        height: 30%;
        .seeData {
          flex: 1;
          display: flex;
          flex-flow: column;
          justify-content: center;
          border-bottom: 1px solid #ccc;
          .seetop {
            position: relative;
            display: flex;
            .imgdiv {
              width: 60px;
              height: 60px;
              position: absolute;
              left: 0;
              top: 0;
              img {
                width: 100%;
                height: 100%;
              }
            }
            & > div:nth-child(1) {
              margin-left: 90px;
              font-size: 50px;
              width: 660px;
              flex: 1;
              height: 75px;
              text-overflow: -o-ellipsis-lastline;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 1;
              -webkit-box-orient: vertical;
              cursor: pointer;
            }
            // & > div:nth-child(2) {
            //   font-size: 24px;
            //   margin-left: 10px;
            //   line-height: 70px;
            //   flex: 1;
            //   font-size: 40px;
            // }
            & > div:nth-child(2),
            & > div:nth-child(3),
            & > div:nth-child(4) {
              font-size: 40px;
              margin-left: 20px;
              text-align: center;
            }
          }
          .seecont {
            display: flex;
            align-items: center;
            & > div:nth-child(1) {
              margin-left: 150px;
              margin-right: 20px;
              font-size: 48px;
            }
            & > div:nth-child(2) {
              color: yellow;
              font-weight: 600;
              position: relative;
              font-size: 48px;
              span {
                font-size: 24px;
                color: white;
                position: absolute;
                right: -56px;
                bottom: 0;
              }
            }
            .allMoney {
              margin-left: 60px;
              background: white;
              width: 600px;
              height: 20px;
              border-radius: 16px;
              position: relative;
              & > div:nth-child(1) {
                background: #91d5ff;
                height: 20px;
                position: absolute;
                left: 0;
                top: 0;
                z-index: 1;
                border-radius: 16px;
              }
              & > div:nth-child(2) {
                background: #198bf7;
                height: 20px;
                position: absolute;
                left: 0;
                top: 0;
                border-radius: 16px;
              }
            }
          }
        }
      }
    }
    .nextDiv {
      display: flex;
      position: absolute;
      bottom: 10px;
      left: 45%;
      width: 100%;
      & > div:nth-child(1) {
        margin-right: 70px;
        width: 80px;
        height: 80px;
      }
      img {
        width: 80px;
        height: 80px;
        cursor: pointer;
      }
    }
  }
  .indexRight {
    flex: 1;
    & > div {
      width: 100%;
      height: 100%;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 150px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}
.bottomColor {
  border-bottom: 4px solid red !important;
}
</style>