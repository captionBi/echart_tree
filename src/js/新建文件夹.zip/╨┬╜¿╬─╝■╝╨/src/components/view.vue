<template>
  <div class="viewDiv">
    <div class="viewConnent">
      <div v-if="isParseNum" class="evencontent">
        <div
          class="viewLists"
          v-for="(item, index) in evenNumberList"
          :key="index"
          :style="{ width: evenWidth, height: evenHeight }"
        >
          <div
            class="video active"
            style="width: 100%; height: 95%"
            :id="'ckplayer' + index"
          ></div>
          <el-tooltip
            class="fontspo"
            effect="dark"
            :content="item.videoName"
            placement="top-start"
          >
            <div>{{ item.videoName }}</div>
          </el-tooltip>
        </div>
      </div>
      <div v-else class="oddcontent">
        <div
          class="oddDiv"
          :style="{
            width: evenWidth,
            height: evenNumberList.length === 0 ? '85%' : '97%',
          }"
        >
          <div
            class="video active"
            style="width: 100%; height: 90%"
            id="ckplayer0"
          ></div>
          <div class="fontspo">{{ oddNumberList.videoName }}</div>
        </div>
        <div class="evenDiv" v-if="evenNumberList.length >= 1">
          <div
            v-for="(item, index) in evenNumberList"
            :key="index"
            :style="{ width: espWidth }"
          >
            <div
              class="video active"
              style="width: 100%; height: 90%"
              :id="'ckplayer' + (index + 1)"
            ></div>
            <el-tooltip
              class="fontspo"
              effect="dark"
              :content="item.videoName"
              placement="top-start"
            >
              <div>{{ item.videoName }}</div>
            </el-tooltip>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
//type=2的情况下用getVedio
//type=1的情况下直接使用new ckplayer
//type=0的情况 getUrl
import { post, get } from "../http";
import backg from "../images/video_bg.jpg";
export default {
  name: "index",
  data() {
    return {
      oddNumberList: [],
      evenNumberList: [],
      oddWidth: "",
      evenWidth: "",
      evenHeight: "",
      espWidth: "",
      isParseNum: true, //用于奇数和偶数的判断
      viewArrays: [],
    };
  },
  computed: {
    detailList() {
      return this.$store.state.detailList;
    },
  },
  methods: {
    ckplayera(e, url) {
      console.log("ckplayerackplayera", `#ckplayer${e}`);
      setTimeout(function () {
        var videoObject = {
          container: `#ckplayer${e}`, // 容器的ID或className
          variable: "player1", // 播放函数名称 与下面一致
          autoplay: true, // 是否自动播放
          live: true, // 是否是直播视频 true = 直播，false =
          //poster: "../images/video_bg.jpg",
          poster: backg, //封面图片
          mobileCkControls: false, // 是否在移动端（包括ios）环境中显示控制
          video: url,
          html5m3u8: true,
          //video: "http://157.122.3.51:83/openUrl/9HJz2so/live.m3u8", // hls地址
        };
        let player1 = new ckplayer(videoObject);
      }, 2);
    },
  },
  mounted() {
    this.$api.sreem.VideoLists(this.$route.query.id, "1").then((res) => {
      this.viewArrays = res.body.videoList;
      console.log(
        "videolist",
        this.viewArrays.length % 2 == 0,
        this.viewArrays
      );
      if (this.viewArrays.length % 2 == 0) {
        this.isParseNum = true;
        this.evenNumberList = this.viewArrays;
        this.evenNumberList.map((res, index) => {
          if (res.type === 0) {
            get(`/videoApi/service/getProjectVideoUrl/${res.cam}`).then(
              (res) => {
                if (res.state.code === 10000) {
                  if (res.body.code === 0) {
                    var url = res.body.data.url;
                    url = url.replace(
                      "api.welink.qq.com:880",
                      "219.135.193.190:8088"
                    );
                    console.log("yyyyyyyyyyyyy", url);
                    this.ckplayera(index, url);
                  }
                }
              }
            );
          } else if (res.type === 1) {
            this.ckplayera(index, res.cam);
          } else if (res.type === 2) {
            let params = {
              cameraIndexCode: res.cam,
              streamType: 0,
              protocol: "hls",
              transmode: 1,
            };
            post("/videoApi/service/getCamerasUrl", params).then((res) => {
              if (res.state.code == 10000) {
                if (res.body.data && res.body.data.url) {
                  let url = res.body.data ? res.body.data.url : "";
                  let targetAddr = "157.122.3.51:83";
                  url = url
                    .replace("192.168.112.204:83", targetAddr)
                    .replace("192.168.112.205:83", targetAddr);
                  this.ckplayera(index, url);
                }
              }
            });
          }
        });
        if (this.viewArrays.length === 1) {
          this.evenWidth = "100%";
          this.evenHeight = "96%";
        } else if (this.viewArrays.length === 2) {
          this.evenWidth = "46%";
          this.evenHeight = "96%";
        } else if (this.viewArrays.length === 3) {
          this.evenWidth = "30%";
          this.evenHeight = "96%";
        } else if (this.viewArrays.length === 4) {
          this.evenWidth = "23%";
          this.evenHeight = "96%";
        } else {
          this.evenWidth = "23%";
          this.evenHeight = "40%";
        }
      } else {
        //奇数的判断
        this.isParseNum = false;
        this.oddNumberList = this.viewArrays[0];
        //判断第一条数据的视频
        if (this.oddNumberList.type === 0) {
          get(
            `/videoApi/service/getProjectVideoUrl/${this.oddNumberList.cam}`
          ).then((res) => {
            if (res.state.code === 10000) {
              if (res.body.code === 0) {
                var url = res.body.data.url;
                url = url.replace(
                  "api.welink.qq.com:880",
                  "219.135.193.190:8088"
                );
                console.log("yyyyyyyyyyyyy", url);
                this.ckplayera(0, url);
              }
            }
          });
        } else if (this.oddNumberList.type === 1) {
          this.ckplayera(0, this.oddNumberList.cam);
        } else if (this.oddNumberList.type === 2) {
          let params = {
            cameraIndexCode: this.oddNumberList.cam,
            streamType: 0,
            protocol: "hls",
            transmode: 1,
          };
          post("/videoApi/service/getCamerasUrl", params).then((res) => {
            if (res.state.code == 10000) {
              if (res.body.data && res.body.data.url) {
                let url = res.body.data ? res.body.data.url : "";
                let targetAddr = "157.122.3.51:83";
                url = url
                  .replace("192.168.112.204:83", targetAddr)
                  .replace("192.168.112.205:83", targetAddr);
                this.ckplayera(0, url);
              }
            }
          });
        }

        //从第二条开始遍历
        this.viewArrays.map((item, indexs) => {
          if (indexs >= 1) {
            this.evenNumberList.push(item);
            if (item.type === 0) {
              get(`/videoApi/service/getProjectVideoUrl/${item.cam}`).then(
                (res) => {
                  console.log("resresres", res, indexs);
                  if (res.state.code === 10000) {
                    if (res.body.code === 0) {
                      var url = res.body.data.url;
                      url = url.replace(
                        "api.welink.qq.com:880",
                        "219.135.193.190:8088"
                      );
                      this.ckplayera(indexs, url);
                    }
                  }
                }
              );
            } else if (item.type === 1) {
              this.ckplayera(indexs, item.cam);
            } else if (item.type === 2) {
              let params = {
                cameraIndexCode: item.cam,
                streamType: 0,
                protocol: "hls",
                transmode: 1,
              };
              post("/videoApi/service/getCamerasUrl", params).then((res) => {
                if (res.state.code == 10000) {
                  if (res.body.data && res.body.data.url) {
                    let url = res.body.data ? res.body.data.url : "";
                    let targetAddr = "157.122.3.51:83";
                    url = url
                      .replace("192.168.112.204:83", targetAddr)
                      .replace("192.168.112.205:83", targetAddr);
                    this.ckplayera(indexs, url);
                  }
                }
              });
            }
          }
        });
        if (this.viewArrays.length === 1) {
          this.evenWidth = "100%";
        } else if (this.viewArrays.length === 3) {
          this.evenWidth = "60%";
          this.espWidth = "100%";
        } else if (this.viewArrays.length === 5) {
          this.evenWidth = "30%";
          this.espWidth = "46%";
        } else if (this.viewArrays.length === 7) {
          this.evenWidth = "30%";
          this.espWidth = "30%";
        }
      }
    });
  },
};
</script>

<style scoped lang="less">
.viewDiv {
  height: 100%;
  & > div {
    height: 100%;
  }
  .viewConnent {
    height: 100%;
    .evencontent {
      height: 100%;
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      padding-bottom: 1%;
      margin-left: -1.5%;
      .viewLists {
        margin-left: 1.5%;
        height: 40%;
      }
    }
    .oddcontent {
      height: 100%;
      display: flex;
      .oddDiv {
        height: 97%;
        margin-left: 1.5%;
      }
      .evenDiv {
        flex: 1;
        display: flex;
        flex-wrap: wrap;
        margin-left: 1.5%;
        margin-top: -1%;
        & > div {
          margin-right: 1.5%;
          margin-top: 1.5%;
          height: 40%;
        }
      }
    }
  }
}
.fontspo {
  text-align: center;
  margin-top: 20px;
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  cursor: pointer;
}
</style>