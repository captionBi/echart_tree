<template>
  <div ref="gantt"></div>
</template>

<script>
import gantt from "../../src/dhtmlxgantt";
// import "dhtmlx-gantt";

export default {
  name: "gantt",
  props: {
    tasks: {
      type: Object,
      default() {
        return { data: [], links: [] };
      },
    },
  },
  computed: {
    ganttType() {
      return this.$store.state.ganttType;
    },
  },
  watch: {
    ganttType(news, old) {
      this.relodType(news);
    },
  },
  mounted: function () {
    gantt.config.layout = {
      css: "gantt_container",
      cols: [
        {
          width: 400,
          min_width: 300,
          rows: [
            {
              view: "grid",
              scrollX: "gridScroll",
              scrollable: true,
              scrollY: "scrollVer",
            },
            { view: "scrollbar", id: "gridScroll", group: "horizontal" },
          ],
        },
        { resizer: true, width: 1 },
        {
          rows: [
            { view: "timeline", scrollX: "scrollHor", scrollY: "scrollVer" },
            { view: "scrollbar", id: "scrollHor", group: "horizontal" },
          ],
        },
        { view: "scrollbar", id: "scrollVer" },
      ],
    };
    gantt.plugins({
      marker: true, //是否添加当前时间
      tooltip: true, //是否添加进度条的提示
    });
    gantt.config.date_format = "%Y-%m-%d %H:%i:%s"; //  设置日期格式
    gantt.config.readonly = true; // 设置只读，不可修改
    gantt.config.duration_unit = "month"; // minute, day, month 设置持续时间单位
    gantt.config.task_height = 36; //设置进度条的高度
    //添加一条进度条
    gantt.addTaskLayer(function draw_planned(task) {
      if (task.actualStartDate && task.actualEndDate) {
        var sizes = gantt.getTaskPosition(
          task,
          task.actualStartDate,
          task.actualEndDate
        );
        var el = document.createElement("div");
        el.className = "baseline";
        el.style.left = sizes.left + "px";
        el.style.width = sizes.width + "px";
        el.style.height = 16 + "px";
        // el.style.background = "#ffd180";
        // el.style.position = "absolute";
        el.style.top = sizes.top + gantt.config.task_height + 16 + "px";
        return el;
      }
      return false;
    });
    gantt.config.tooltip_offset_y = 20; //设置工具提示位置的垂直偏移
    gantt.templates.tooltip_text = function (start, end, task) {
      console.log("TaskTaskTask", task);
      return `
        <div class="tisclass" style="heigth:200px;font-size:32px;top:10px">
          <div>
            <div>项目名称:</div>
            <div>${task.taskName}</div>
          </div>
          <div>
            <div>存在问题:</div>
            <div>${task.item}</div>
          </div>
        </div>
      `;
    };
    //计划进度时间的转换
    gantt.attachEvent("onTaskLoading", function (task) {
      task.planned_start = gantt.date.parseDate(task.planned_start, "xml_date");
      task.planned_end = gantt.date.parseDate(task.planned_end, "xml_date");
      return true;
    });
    //实际进度时间的转换
    gantt.attachEvent("onTaskLoading", function (task) {
      task.actualStartDate = gantt.date.parseDate(
        task.actualStartDate,
        "xml_date"
      );
      task.actualEndDate = gantt.date.parseDate(task.actualEndDate, "xml_date");
      return true;
    });
    // 日期列显示
    gantt.config.min_column_width = 80;
    gantt.config.row_height = 80; //设置表格行的默认高度
    gantt.config.scale_height = 80 * 2; // 时间刻度的高度和网格标题
    // 定义时间刻度的配置设置
    var dateToYear = gantt.date.date_to_str("%Y");
    var dateToMonth = gantt.date.date_to_str("%m");
    gantt.config.scales = [
      {
        unit: "year",
        step: 1,
        format: function (date) {
          return `${dateToYear(date)}年`;
        },
      },
      {
        unit: "month",
        step: 1,
        format: function (date) {
          return `${dateToMonth(date)}月`;
        },
      },
    ];
    // 添加现在的垂直线条
    setTimeout(() => {
      var dateToToday = gantt.date.date_to_str(gantt.config.task_date);
      var today = new Date();
      gantt.addMarker({
        start_date: new Date(),
        css: "today",
        text: "现在",
        title: dateToToday(today),
      });
    }, 500);

    gantt.config.min_grid_column_width = 180; //左侧表格列的最小宽度
    // gantt.config.autosize_min_width = 800;
    // 表头整体宽度
    // gantt.config.autofit = true;
    // gantt.config.grid_width = 500;
    // 表头配置显示列   //name:绑定数据的名称  align：对其方式  label显示在表头的名称
    gantt.config.columns = [
      // {
      //   name: "index",
      //   align: "center",
      //   label: "序号",
      //   width: "30",
      //   resize: true,
      // },
      {
        name: "taskName",
        label: "任务名称",
        align: "left",
        resize: true,
        tree: true,
        width: 500,
        // width: "*",
      },
      // {
      //   name: "item",
      //   align: "center",
      //   label: "长度或项",
      //   resize: true,
      // },
      {
        name: "planStartDate",
        align: "center",
        label: "计划开始",
        resize: true,
        width: 180,
      },
      {
        name: "planEndDate",
        align: "center",
        label: "计划完工",
        resize: true,
        width: 180,
      },
      {
        name: "actualStartDate",
        align: "center",
        label: "实际开始",
        resize: true,
        width: 180,
      },
      {
        name: "actualEndDate",
        align: "center",
        label: "实际完工",
        resize: true,
        width: 180,
      },
      {
        name: "planDays",
        align: "center",
        label: "计工工期",
        resize: true,
        width: 120,
      },
    ];
    gantt.init(this.$refs.gantt);
    gantt.parse(this.$props.tasks);
  },
  methods: {
    chanlNum(num) {
      let timeNum;
      console.log("ganttType", this.ganttType);
      if (String(this.ganttType) === "1") {
        timeNum = Number(num) / 30;
      } else if (String(this.ganttType) === "2") {
        timeNum = Number(num) / 7;
      } else {
        timeNum = Number(num);
      }
      let s = timeNum + "";
      console.log("timeNumtimeNumtimeNum", s);
      if (s.indexOf(".") != -1) {
        return s.substring(0, s.indexOf(".") + 2);
      } else {
        return s;
      }
    },
    updateSelect() {
      this.tasks.data.forEach((item, key) => {
        this.$set(item, "start_date", item.planStartDate); // 开始时间字段必须是start_date
        this.$set(item, "index", key + 1);
        this.$set(item, "progress", 1); // 进度字段
        this.$set(item, "duration", this.chanlNum(item.planDays)); // 几个空格字段
        this.$set(item, "text", item.taskName); // 右侧进度上部分文字
      });
      this.tasks.data.forEach((item, key) => {
        if (item.predecessors != "") {
          this.tasks.links.push({
            id: item.predecessors,
            source: item.predecessors,
            target: item.id,
            type: 0,
          });
        }
      });
      this.$nextTick(() => {
        gantt.clearAll();
        setTimeout(() => {
          var dateToToday = gantt.date.date_to_str(gantt.config.task_date);
          var today = new Date();
          gantt.addMarker({
            start_date: new Date(),
            css: "today",
            text: "现在",
            title: dateToToday(today),
          });
        }, 500);
        gantt.parse(this.tasks);
        gantt.render(); // 重新刷新gantt图
      });
    },
    relodType(type) {
      this.updateSelect();
      if ("1" == type) {
        //月
        var dateToYear = gantt.date.date_to_str("%Y");
        var dateToMonth = gantt.date.date_to_str("%m");
        gantt.config.duration_unit = "month";
        gantt.config.scale_unit = "year";
        gantt.config.date_scale = "%Y";
        gantt.config.subscales = [
          {
            unit: "month",
            step: 1,
            date: "%F",
            format: function (date) {
              return `${dateToMonth(date)}月`;
            },
          },
        ];
        gantt.clearAll();
        setTimeout(() => {
          var dateToToday = gantt.date.date_to_str(gantt.config.task_date);
          var today = new Date();
          gantt.addMarker({
            start_date: new Date(),
            css: "today",
            text: "现在",
            title: dateToToday(today),
          });
        }, 500);
        gantt.config.min_column_width = 80; //设置表格行的默认宽度
        gantt.config.row_height = 80; //设置表格行的默认高度
        gantt.config.scale_height = 80 * 2; // 时间刻度的高度和网格标题
        gantt.parse(this.tasks);
        gantt.render();
      } else if ("3" == type) {
        //日
        var dateToYear = gantt.date.date_to_str("%Y");
        var dateToMonth = gantt.date.date_to_str("%m");
        var dateToDay = gantt.date.date_to_str("%j");
        gantt.config.duration_unit = "day";
        gantt.config.scale_unit = "month";
        gantt.config.date_scale = "%Y";
        gantt.config.subscales = [
          {
            unit: "month",
            step: 1,
            format: function (date) {
              return `${dateToMonth(date)}月`;
            },
          },
          {
            unit: "day",
            step: 1,
            date: "%j",
            format: function (date) {
              return `${dateToDay(date)}`;
            },
          },
        ];
        gantt.clearAll();
        setTimeout(() => {
          var dateToToday = gantt.date.date_to_str(gantt.config.task_date);
          var today = new Date();
          gantt.addMarker({
            start_date: new Date(),
            css: "today",
            text: "现在",
            title: dateToToday(today),
          });
        }, 500);
        gantt.config.min_column_width = 80; //设置表格行的默认宽度
        gantt.config.row_height = 80; //设置表格行的默认高度
        gantt.config.scale_height = 80 * 2; // 时间刻度的高度和网格标题
        gantt.parse(this.tasks);
        gantt.render();
      } else if ("2" == type) {
        //周
        var dateToYear = gantt.date.date_to_str("%Y");
        var dateToMonth = gantt.date.date_to_str("%m");
        var dateToDay = gantt.date.date_to_str("%j");
        gantt.config.scale_unit = "month";
        gantt.config.date_scale = "%Y";
        gantt.config.duration_unit = "week";
        gantt.config.step = 1;
        gantt.config.subscales = [
          {
            unit: "month",
            step: 1,
            format: function (date) {
              return `${dateToMonth(date)}月`;
            },
          },
          {
            unit: "week",
            step: 1,
            date: "%j",
            format: function (date) {
              return `${dateToDay(date)}`;
            },
          },
        ];
        gantt.clearAll();
        setTimeout(() => {
          var dateToToday = gantt.date.date_to_str(gantt.config.task_date);
          var today = new Date();
          gantt.addMarker({
            start_date: new Date(),
            css: "today",
            text: "现在",
            title: dateToToday(today),
          });
        }, 500);
        gantt.config.min_column_width = 80; //设置表格行的默认宽度
        gantt.config.row_height = 80; //设置表格行的默认高度
        gantt.config.scale_height = 80 * 2; // 时间刻度的高度和网格标题
        gantt.parse(this.tasks);
        gantt.render();
      }
    },
    reload() {
      gantt.clearAll();
      gantt.addTaskLayer(function draw_planned(task) {
        if (task.actualStartDate && task.actualEndDate) {
          var sizes = gantt.getTaskPosition(
            task,
            task.actualStartDate,
            task.actualEndDate
          );
          var el = document.createElement("div");
          el.className = "baseline";
          el.style.left = sizes.left + "px";
          el.style.width = sizes.width + "px";
          el.style.height = 16 + "px";
          el.style.background = "red";
          el.style.position = "absolute";
          el.style.top = sizes.top + gantt.config.task_height + 16 + "px";
          return el;
        }
        return false;
      });
      //计划进度时间的转换
      gantt.attachEvent("onTaskLoading", function (task) {
        task.planned_start = gantt.date.parseDate(
          task.planned_start,
          "xml_date"
        );
        task.planned_end = gantt.date.parseDate(task.planned_end, "xml_date");
        return true;
      });
      //实际进度时间的转换
      gantt.attachEvent("onTaskLoading", function (task) {
        task.actualStartDate = gantt.date.parseDate(
          task.actualStartDate,
          "xml_date"
        );
        task.actualEndDate = gantt.date.parseDate(
          task.actualEndDate,
          "xml_date"
        );
        return true;
      });
      gantt.parse(this.$props.tasks);
      gantt.render();
    },
  },
};
</script>
<style scoped lang="less">
@import "~dhtmlx-gantt/codebase/skins/dhtmlxgantt_contrast_black.css";

.gantt_grid_scale,
.gantt_task_scale {
  font-size: 16px;
}
.gantt_cell {
  font-size: 16px;
}
.gantt_task_content {
  font-size: 16px;
}
.baseline {
  position: absolute;
  border-radius: 2px;
  opacity: 0.6;
  margin-top: -7px;
  height: 16px;
  background: #ffd180;
  border: 1px solid rgb(255, 153, 0);
}
.tisclass {
  & > div {
    font-size: 40px;
    display: flex;
    & > div:nth-child(2) {
      margin-left: 30px;
    }
  }
}
</style>