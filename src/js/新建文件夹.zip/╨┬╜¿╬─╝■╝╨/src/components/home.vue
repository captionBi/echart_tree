<template>
  <div class="homedDiv">
    <div class="oneDiv">
      <div>
        <div>
          <img src="../images/4icon@2x.png" alt />
        </div>
        <div>
          <span>项目概览</span>
        </div>
      </div>
      <el-tooltip
        class="zmbtis"
        effect="dark"
        :content="detailList.zmb"
        placement="top-start"
      >
        <div>{{ detailList.zmb }}</div>
      </el-tooltip>
    </div>
    <div class="oneDiv">
      <div>
        <div>
          <img src="../images/4icon@2x.png" alt />
        </div>
        <div>
          <span>投资进度统计</span>
        </div>
      </div>
      <div class="moneyDiv">
        <div class="seecont">
          <div>总投资额</div>
          <div>
            {{ detailList.ztz }}
            <span>亿元</span>
          </div>
          <div class="allMoney">
            <div
              :style="{
                width: `${
                  (detailList.tzwc / detailList.ztz) * 100 >= 100
                    ? 100
                    : (detailList.tzwc / detailList.ztz) * 100
                }%`,
              }"
            ></div>
            <!-- <div
              :style="{
                width: `${
                  (detailList.njtz / detailList.ztz) * 100 >= 100
                    ? 100
                    : (detailList.njtz / detailList.ztz) * 100
                }%`,
              }"
            ></div> -->
            <div></div>
            <div class="quanTic">
              <div>
                <span>实际投资:</span> <span>{{ detailList.tzwc }}</span> 亿
              </div>
              <div>
                <span>占比: </span
                ><span>{{
                  Number(((detailList.tzwc / detailList.ztz) * 100).toFixed(1))
                }}</span>
                %
              </div>
            </div>
          </div>
        </div>
        <div class="numdata">
          <div>
            <div>年度实际投资</div>
            <div>
              {{ detailList.ndtz }}
              <span>亿元</span>
            </div>
            <div>
              完成
              <span style="color: #45bcf5; font-weight: 600">{{
                detailList.ndtzwcbl
              }}</span>
            </div>
          </div>
          <div>
            <div>年度计划投资</div>
            <div>
              {{ detailList.ndjhtz }}
              <span>亿元</span>
            </div>
            <div>
              占比
              <span style="color: #45bcf5; font-weight: 600">{{
                detailList.ndjhtzwcbl
              }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="oneDiv">
      <div>
        <div>
          <img src="../images/4icon@2x.png" alt />
        </div>
        <div>
          <span>工程进度统计</span>
        </div>
      </div>
      <div
        class="quanquans"
        v-if="
          Number(detailList.jhgt) +
            Number(detailList.yjt) +
            Number(detailList.hygz) +
            Number(detailList.yqy) >=
          1
        "
      >
        <div class="onequan">
          <div class="fonsquan">
            <div>设计进度</div>
            <div>
              <el-progress
                :stroke-width="20"
                :width="180"
                type="circle"
                color="#70ad47"
                :percentage="
                  detailList.yjt === 0 && detailList.jhgt === 0
                    ? 100
                    : (detailList.yjt / detailList.jhgt) * 100 >= 100
                    ? 100
                    : Number(
                        ((detailList.yjt / detailList.jhgt) * 100).toFixed(1)
                      )
                "
              ></el-progress>
            </div>
          </div>
          <div class="quanbottom">
            <div class="firses">
              <div></div>
              <div>计划供图: {{ detailList.jhgt }}张</div>
            </div>
            <div class="sonken">
              <div></div>
              <div>已交图: {{ detailList.yjt }}张</div>
            </div>
          </div>
        </div>
        <div class="onequan">
          <div class="fonsquan">
            <div>采购进度</div>
            <div>
              <el-progress
                :stroke-width="20"
                :width="180"
                type="circle"
                color="#b679e6"
                :percentage="
                  detailList.yqy === 0 && detailList.hygz === 0
                    ? 100
                    : (detailList.yqy / detailList.hygz) * 100 >= 100
                    ? 100
                    : Number(
                        ((detailList.yqy / detailList.hygz) * 100).toFixed(1)
                      )
                "
              ></el-progress>
            </div>
          </div>
          <div class="quanbottom">
            <div class="firses">
              <div></div>
              <div>合约规划: {{ detailList.hygz }}亿</div>
            </div>
            <div class="sonken">
              <div></div>
              <div>已签约: {{ detailList.yqy }}亿</div>
            </div>
          </div>
        </div>
        <div class="onequan">
          <div class="fonsquan">
            <div>施工进度</div>
            <div>
              <el-progress
                :stroke-width="20"
                :width="180"
                type="circle"
                color="#01dfe0"
                :percentage="
                  (detailList.tzwc / detailList.ztz) * 100 >= 100
                    ? 100
                    : Number(
                        ((detailList.tzwc / detailList.ztz) * 100).toFixed(1)
                      )
                "
              ></el-progress>
            </div>
          </div>
          <div class="quanbottom">
            <div class="firses">
              <div></div>
              <div>施工总投资: {{ detailList.ztz }}亿</div>
            </div>
            <div class="sonken">
              <div></div>
              <div>投资完成: {{ detailList.tzwc }}亿</div>
            </div>
          </div>
        </div>
      </div>
      <div class="noneDataClass" v-else>
        <div class="alllines">
          <div class="lineDiv">
            <div
              :style="{
                width: `${
                  Number(
                    ((detailList.tzwc / detailList.ztz) * 100).toFixed(1)
                  ) + '%'
                }`,
              }"
            ></div>
          </div>
        </div>
        <div class="fontsDiv">
          <div>
            <div>施工总投资</div>
            <div>{{ detailList.ztz }} <span>亿元</span></div>
          </div>
          <div>
            <div>投资完成</div>
            <div>{{ detailList.tzwc }} <span>亿元</span></div>
          </div>
        </div>
      </div>
    </div>
    <div class="oneDiv">
      <div>
        <div>
          <img src="../images/4icon@2x.png" alt />
        </div>
        <div>
          <span>标段/工点进度统计</span>
        </div>
      </div>
      <div
        class="dingdingline"
        :class="plansList.length >= 10 ? 'scollDiv' : ''"
      >
        <div class="tisding">
          <div><img :src="okp" alt="" /></div>
          <div style="margin: 0 20px">正常</div>
          <div><img :src="finp" alt="" /></div>
          <div style="margin: 0 20px">完成</div>
          <div><img :src="jinp" alt="" /></div>
          <div style="margin: 0 20px">预警（≤10%）</div>
          <div><img :src="orps" alt="" /></div>
          <div style="margin: 0 20px">滞后（>10%）</div>
        </div>
        <div class="dingdings" v-for="(item, index) in plansList" :key="index">
          <div @click="seePic(item)">
            <!-- 1滞后 2已完成 3 预警 0正常 -->
            <img
              :src="
                item.bdStatus === 1
                  ? orps
                  : item.bdStatus === 2
                  ? finp
                  : item.bdStatus === 3
                  ? jinp
                  : okp
              "
              alt
            />
            <!-- <div class="finsss">{{ item.bdName }}</div> -->
            <el-tooltip
              effect="dark"
              :content="item.bdName"
              placement="top-start"
              class="finsss"
            >
              <div>{{ item.bdName }}</div>
            </el-tooltip>
          </div>
        </div>
      </div>
    </div>
    <div class="floatData" v-if="picNum === 1">
      <div class="imgclose">
        <img @click="outPic" src="../images/close.png" alt="" />
      </div>
      <div>
        <div>
          <div>标段负责人:</div>
          <div>{{ showboxPro.bdManagerName }}</div>
        </div>
        <div>
          <div>问题原因:</div>
          <div>
            <pre>{{ showboxPro.causeProblem }}</pre>
          </div>
        </div>
        <div>
          <div>问题对策:</div>
          <div>
            <pre>{{ showboxPro.problemsCountermeasures }}</pre>
          </div>
        </div>
        <div>
          <div>微信二维码:</div>
          <div><img :src="showboxPro.userCode" alt="" /></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import okp from "../images/10icon@2x.png";
import finp from "../images/6icon@2x.png";
import jinp from "../images/8icon@2x.png";
import orps from "../images/7icon@2x.png";
export default {
  name: "homeDiv",
  data() {
    return {
      showboxPro: {
        bdManagerName: "",
        userCode: "",
        causeProblem: "",
        problemsCountermeasures: "",
      },
      picNum: 0,
      okp: okp,
      finp: finp,
      jinp: jinp,
      orps: orps,
    };
  },
  computed: {
    plansList() {
      // console.log("aaaaaaa", this.$store.state.operCommBids);
      return this.$store.state.operCommBids;
    },
    imagesList() {
      return this.$store.state.imagesList;
    },
    detailList() {
      console.log("rrrrrr", this.$store.state.detailList);
      return this.$store.state.detailList;
    },
  },
  methods: {
    seePic(item) {
      console.log("aaaaaaa", item);
      this.showboxPro = item;
      this.picNum = 1;
    },
    outPic() {
      this.picNum = 0;
    },
  },
  mounted() {},
};
</script>

<style scoped lang="less">
.homedDiv {
  position: relative;
  .oneDiv {
    display: flex;
    margin-top: 20px;
    & > div:nth-child(1) {
      height: 120px;
      width: 250px;
      margin-right: 20px;
      display: flex;
      align-items: center;
      div {
        img {
          width: 80px;
          height: 90px;
          display: block;
          margin-right: 20px;
        }
        span {
          font-size: 32px;
        }
      }
    }
    & > div:nth-child(2) {
      flex: 1;
    }
    .zmbtis {
      font-size: 42px;
      text-overflow: -o-ellipsis-lastline;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      cursor: pointer;
      height: 118px;
    }
    .moneyDiv {
      display: flex;
      .seecont {
        flex: 2;
        display: flex;
        align-items: center;
        margin-top: 20px;
        & > div:nth-child(1) {
          margin-right: 20px;
        }
        & > div:nth-child(2) {
          color: yellow;
          font-weight: 600;
          width: 135px;
          position: relative;
          span {
            font-size: 24px;
            color: white;
            position: absolute;
            right: -50px;
            bottom: 0;
          }
        }
        .allMoney {
          margin-left: 60px;
          background: white;
          width: 400px;
          height: 20px;
          border-radius: 16px;
          position: relative;
          & > div:nth-child(1) {
            background: #91d5ff;
            height: 20px;
            position: absolute;
            left: 0;
            top: 0;
            border-radius: 16px;
          }
          & > div:nth-child(2) {
            background: #198bf7;
            height: 20px;
            position: absolute;
            left: 0;
            top: 0;
            border-radius: 16px;
          }
          .quanTic {
            display: none;
            padding: 20px;
            background: #0a1e37;
            border-radius: 16px;
            color: white;
            position: absolute;
            top: -180px;
            left: 0;
            width: 600px;
            & > div:nth-child(2) {
              margin-top: 20px;
            }
            div {
              display: flex;
              span:nth-child(1) {
                width: 280px;
                text-align: right;
              }
              span:nth-child(2) {
                color: #d1fa00;
                margin-left: 20px;
                margin-right: 10px;
              }
            }
          }
          &:hover .quanTic {
            display: block;
          }
        }
      }
      .numdata {
        flex: 2;
        & > div {
          display: flex;
          height: 70px;
          & > div:nth-child(1) {
            width: 270px;
            text-align: right;
          }
          & > div:nth-child(2) {
            color: yellow;
            font-weight: 600;
            position: relative;
            width: 150px;
            text-align: right;
            span {
              font-size: 24px;
              color: white;
              position: absolute;
              right: -60px;
              bottom: 20px;
            }
          }
          & > div:nth-child(3) {
            margin-left: 80px;
          }
        }
      }
    }
    .quanquans {
      display: flex;
      .onequan {
        flex: 1;
        .fonsquan {
          display: flex;
          align-items: center;
          & > div:nth-child(1) {
            width: 50px;
            font-size: 28px;
            text-align: center;
          }
        }
        .quanbottom {
          margin-top: 10px;
          .firses {
            margin-top: 10px;
          }
          .sonken {
            margin-top: 10px;
          }
          & > div {
            display: flex;
            align-items: center;
            & > div:nth-child(1) {
              width: 30px;
              height: 30px;
              background: red;
              margin-right: 20px;
            }
            & > div:nth-child(2) {
              font-size: 28px;
            }
          }
        }
      }
      & > div:nth-child(1) {
        .firses > div:nth-child(1) {
          background: #2f5597;
        }
        .sonken > div:nth-child(1) {
          background: #70ad47;
        }
      }
      & > div:nth-child(2) {
        .firses > div:nth-child(1) {
          background: #2f5597;
        }
        .sonken > div:nth-child(1) {
          background: #b679e6;
        }
      }
      & > div:nth-child(3) {
        .firses > div:nth-child(1) {
          background: #2f5597;
        }
        .sonken > div:nth-child(1) {
          background: #01dfe0;
        }
      }
    }
    .dingdingline {
      display: flex;
      padding-top: 60px;
      position: relative;
      .tisding {
        position: absolute;
        display: flex;
        align-items: center;
        right: 10px;
        top: 10px;
        font-size: 30px;
        img {
          width: 40px;
          height: 50px;
        }
      }
      & > div {
        margin-right: 20px;
        img {
          width: 60px;
          height: 70px;
        }
        div {
          text-align: center;
        }
      }
    }
    .dingdings {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      // overflow-x: scroll;
      height: 170px;
      position: relative;
      .finsss {
        max-width: 160px;
        font-size: 36px;
        height: 50px;
        text-overflow: -o-ellipsis-lastline;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
      }
    }
  }
}
.floatData {
  background: #0a1e37;
  color: white;
  padding: 20px 20px 40px 20px;
  width: 1500px;
  height: 720px;
  position: absolute;
  top: -90px;
  left: 6%;
  flex-direction: column;
  .imgclose {
    img {
      width: 40px;
      height: 40px;
      cursor: pointer;
    }
  }
  & > div:nth-child(1) {
    text-align: right;
    height: 90px;
    i {
      font-size: 90px;
    }
  }
  & > div:nth-child(2) {
    margin: 40px 0;
    font-size: 42px;
    height: 530px;
    overflow-y: scroll;
    & > div {
      margin-top: 20px;
      display: flex;
      img {
        width: 250px;
        height: 250px;
      }
      & > div:nth-child(1) {
        width: 250px;
      }
      & > div:nth-child(2) {
        flex: 1;
        margin-left: 20px;
        pre {
          white-space: pre-wrap;
          word-wrap: break-word;
          // line-height: 44px;
        }
      }
    }
  }
}
.scollDiv {
  overflow-x: scroll;
}
.noneDataClass {
  display: flex;
  align-items: center;
  .alllines {
    flex: 2;
    .lineDiv {
      background: white;
      width: 96%;
      height: 20px;
      border-radius: 16px;
      position: relative;
      & > div {
        background: #91d5ff;
        height: 20px;
        position: absolute;
        left: 0;
        top: 0;
        border-radius: 16px;
      }
    }
  }

  .fontsDiv {
    flex: 2;
    & > div {
      display: flex;
      & > div:nth-child(1) {
        width: 270px;
        text-align: right;
      }
      & > div:nth-child(2) {
        color: #fefe00;
        font-weight: 600;
        width: 150px;
        text-align: right;
        position: relative;
        span {
          font-size: 24px;
          color: white;
          position: absolute;
          right: -60px;
          bottom: 0;
        }
      }
    }
  }
}
</style>