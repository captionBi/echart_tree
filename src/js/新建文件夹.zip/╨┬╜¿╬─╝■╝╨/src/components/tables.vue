<template>
  <div
    class="tablesDiv"
    :class="screenNum === 1 ? 'boxBigTablesDiv' : ''"
    style="height: 100%"
  >
    <gantt
      ref="ganttchart"
      class="left-container"
      :tasks="tasks"
      style="height: 90%"
    ></gantt>
  </div>
</template>

<script>
import Gantt from "./gantt.vue";
import { get } from "../http";

export default {
  name: "app",
  components: { Gantt },
  data() {
    return {
      tasks: {
        data: [],
        links: [
          // links为任务之间连接的线
          // {id: 1, source: 1, target: 2, type: '0'}//source根源 target目标 也就是从id为1的指向id为2的
          //type:'0'是从1任务完成到2任务开始，type:'1'是1任务开始到2任务开始，
          //type:'2'是从1任务完成到2任务完成，type:'3'是从1任务开始到2任务完成
        ],
      },
    };
  },
  mounted(e) {
    this.$store.commit("setGanttTimeSelect", 1);
    this.init();
  },
  computed: {
    screenNum() {
      return this.$store.state.screenNum;
    },
    ganttType() {
      return this.$store.state.ganttType;
    },
  },
  methods: {
    chanlNum(num) {
      let timeNum;
      console.log("ganttType", this.ganttType);
      if (String(this.ganttType) === "1") {
        timeNum = Number(num) / 30;
      } else if (String(this.ganttType) === "2") {
        timeNum = Number(num) / 7;
      } else {
        timeNum = Number(num);
      }
      let s = timeNum + "";

      if (s.indexOf(".") != -1) {
        return s.substring(0, s.indexOf(".") + 2);
      } else {
        return s;
      }
    },
    init() {
      this.tasks.links = [];
      get(`/api/service/getGanttByProjectId/${this.$route.query.id}`).then(
        (res) => {
          if (res.state.code === 10000) {
            this.tasks.data = res.body.dataList;
            this.tasks.data.forEach((item, key) => {
              this.$set(item, "start_date", item.planStartDate); // 开始时间字段必须是start_date
              this.$set(item, "index", key + 1);
              this.$set(item, "progress", 1); // 进度字段
              this.$set(item, "duration", this.chanlNum(item.planDays)); // 几个空格字段
              this.$set(item, "end_date", item.planEndDate); // 几个空格字段
              this.$set(item, "text", item.taskName); // 右侧进度上部分文字
            });
            this.tasks.data.forEach((item, key) => {
              if (item.predecessors != "") {
                this.tasks.links.push({
                  id: item.predecessors,
                  source: item.predecessors,
                  target: item.id,
                  type: 0,
                });
              }
            });
            this.$nextTick(() => {
              this.$refs.ganttchart.reload(); // 重新刷新gantt图
            });
          } else {
            this.tasks.data = [];
            this.$message.error(res.body.message);
          }
        }
      );
    },
  },
};
</script>
<style scoped lang="less">
.boxBigTablesDiv {
  transition: all 2000ms;
  -o-transition: all 2000ms; /*兼容parsto内核*/
  -moz-transition: all 2000ms; /*兼容gecko内核*/
  -webkit-transition: all 2000ms; /*兼容webkit内核*/
  height: 100% !important;
  width: 100% !important;
  position: fixed !important;
  top: 0 !important;
  left: 0 !important;
  z-index: 10;
  .left-container {
    height: 100% !important;
    width: 100% !important;
  }
}
</style>>