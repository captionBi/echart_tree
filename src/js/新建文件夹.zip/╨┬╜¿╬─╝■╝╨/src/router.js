import VueRouter from 'vue-router';
import Vue from 'vue';
Vue.use(VueRouter)
//路由配置

const router = new VueRouter({
  routes: [
    {
      path: '/index',
      meta: {
        title: '指挥平台'
      },
      component: (resolve) => require(['./views/index.vue'], resolve)
    },
    {
      path: '/second',
      name: 'second',
      meta: {
        title: '配置工程'
      },
      component: (resolve) => require(['./views/second.vue'], resolve),
      children: [{
        path: 'views',
        name: 'views',
        meta: {
          title: '配置工程'
        },
        component: (resolve) => require(['./components/view.vue'], resolve)
      }, {
        path: 'home',
        name: 'home',
        meta: {
          title: '配置工程'
        },
        component: (resolve) => require(['./components/home.vue'], resolve)
      }, {
        path: 'tables',
        name: 'tables',
        meta: {
          title: '配置工程'
        },
        component: (resolve) => require(['./components/tables.vue'], resolve)
      }],
    },
    {
      path: '/',
      redirect: '/index'
    }
  ]
});

//跳转后设置scroll为原点
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);
});
//跳转前设置title
router.beforeEach((to, from, next) => {
  window.document.title = to.meta.title;
  next();
});

//商品列表路由配置
export default router;
